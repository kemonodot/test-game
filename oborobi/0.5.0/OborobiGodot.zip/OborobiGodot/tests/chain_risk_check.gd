extends SceneTree
## Density is not a reward. Exercise real telegraphs, swipes and counter arrivals.
const Core = preload("res://scripts/combat.gd")
const Geometry = preload("res://scripts/arena_geometry.gd")
var checks = 0
var failures = 0

func _initialize(): call_deferred("test")

func check(ok, description):
	checks += 1
	if ok: print("PASS ",description)
	else:
		failures += 1
		push_error("FAIL "+description)

func quiet(giant = false):
	var run = Core.new(427)
	run.start(giant)
	run.spawn_clock = 999
	run.sword_clock = 999
	run.fire_clock = 999
	run.boss.summon_clock = 999
	return run

func advance(run, seconds, movement = Vector2.ZERO):
	for _i in range(int(ceil(seconds*60))):
		run.tick_visual(1.0/60)
		run.step(1.0/60,movement)
		run.sounds.clear()

func warning():
	var run = quiet(true)
	advance(run,2.1)
	return run

func earned():
	var run = warning()
	run.grapple.fire(run,Vector2.LEFT)
	advance(run,1.2)
	var anchor = run.boss.anchors[run.boss.open_anchor]
	run.grapple.fire(run,Geometry.ground(anchor.p-run.player).normalized())
	advance(run,.9)
	return run

func test():
	var run = quiet()
	run.player = Vector2(300,205)
	for x in range(9):
		for y in range(7):
			var e = run.spawn_enemy(0,Vector2(330+x*15,177+y*9))
			e.hp = 1000
			e.speed = 0
	run.velocity = Vector2(500,0)
	run.grapple.state = "flying"
	run._move_player(.35,run.stats())
	check(run.grapple.energy == 0 and run.grapple.near_passes == 0,"a genuine dash through 63 densely packed enemies earns NO energy")
	check(run.grapple.rush_hits > 3,"the density regression actually traverses and attacks enemy bodies")
	run = quiet()
	var guardian = run.spawn_enemy(1,Vector2(450,205))
	guardian.hp = 1000
	guardian.speed = 0
	run.grapple.fire(run,Vector2.RIGHT)
	advance(run,.9)
	check(run.grapple.enemy_catches == 1 and run.grapple.energy == 0,"an ordinary guardian arrival alone earns no energy")
	run = quiet()
	for _i in range(3):
		run.grapple.fire(run,Vector2.LEFT)
		advance(run,.6)
	check(run.grapple.energy == 0,"empty wall chains earn no energy")
	run = warning()
	check(run.boss.state == "windup" and run.boss.contains(run.player),"the real boss aims a visible warning at the starting player")
	run.grapple.fire(run,Vector2.LEFT)
	advance(run,1.2)
	check(run.hp == 100 and run.grapple.energy == 1 and run.boss.dodges == 1,"starting inside the warning and chain-escaping the impact earns one flame")
	check(run.boss.counter_ready and run.boss.state == "open","a successful dodge opens a timed counter opportunity")
	var before = run.boss.actor.hp
	var anchor = run.boss.anchors[run.boss.open_anchor]
	run.grapple.fire(run,Geometry.ground(anchor.p-run.player).normalized())
	advance(run,.9)
	check(run.grapple.energy == 3 and run.boss.counters == 1 and run.grapple.arrival_rewards == 1,"actual return-chain arrival completes the wager and fills all three flames")
	check(before-run.boss.actor.hp >= 299 and run.souls_taken == 3,"the timed counter deals substantial boss damage and awards real collectible XP")
	run.boss.chain_arrival(run,anchor)
	check(run.boss.counters == 1 and run.grapple.arrival_rewards == 1,"repeated arrival cannot farm the same attack's counter reward")
	check(run.stats().sword_damage == 26 and run.stats().fire_damage == 20,"earned flames do not permanently multiply passive weapons")
	run.grapple.fire(run,Vector2.LEFT)
	advance(run,.20)
	check(run.grapple.energy == 0 and run.grapple.bursts == 1,"a following connected chain spends the earned full gauge on one golden rush")
	check(not run.grapple.cuts.is_empty() and run.grapple.cuts.size() <= 24,"the golden rush has an actual bounded swept wake")
	advance(run,.9)
	check(run.grapple.burst_left == 0 and run.grapple.cuts.is_empty(),"the golden attack and wake expire")

	run = warning()
	run.grapple.fire(run,Vector2.UP)
	advance(run,1.2)
	check(run.hp <= 80 and run.grapple.energy == 0,"hooking inward and remaining in the warning takes damage instead of rewarding proximity")
	run = warning()
	run.player = Vector2(260,275)
	advance(run,1.2,Vector2.LEFT)
	check(run.hp == 100 and run.grapple.energy == 0,"walking out of the same warning is safe but earns no chain flame")
	run = warning()
	run.player = Vector2(90,205)
	run.grapple.fire(run,Vector2.DOWN)
	advance(run,1.2)
	check(run.grapple.energy == 0 and run.boss.evade.is_empty(),"firing outside the marked danger cannot farm a dodge reward")
	run = warning()
	run.grapple.fire(run,Vector2.LEFT)
	advance(run,.16)
	run.grapple.fire(run,Vector2.LEFT)
	advance(run,1.2)
	check(run.grapple.energy == 1 and run.boss.dodges == 1,"several swipes during one warning still grant only one dodge reward")
	run = warning()
	run.grapple.fire(run,Vector2.LEFT)
	run.hurt_player(1,Vector2.RIGHT,true)
	run.ultimates.cast(run,"flame")
	advance(run,2)
	check(run.hp == 100 and run.grapple.energy == 0 and not run.boss.counter_ready,"healing after a hit cannot conceal that the dodge attempt failed")

	run = quiet()
	run.player = Vector2(350,205)
	guardian = run.spawn_enemy(1,Vector2(300,205))
	guardian.hp = 1000
	guardian.speed = 0
	guardian.attack_clock = 0
	advance(run,.02)
	check(guardian.windup > 0,"normal guardian attacks also have a genuine warning")
	run.grapple.fire(run,Vector2.RIGHT)
	advance(run,1.2)
	check(guardian.counter_ready and run.grapple.energy == 1 and run.hp == 100,"a guardian's marked attack can be chain-dodged for a flame")
	run.grapple.fire(run,Geometry.ground(guardian.p-run.player).normalized())
	advance(run,.9)
	check(run.grapple.energy == 3 and not guardian.counter_ready,"a guardian return chain consumes its one earned counter ticket")

	run = earned()
	run.invulnerable = .16
	run.hurt_player(8,Vector2.RIGHT,true)
	check(run.hp == 92 and run.grapple.energy == 0 and run.grapple.energy_lost == 3,"marked attacks pierce brief dash-contact protection and remove all stored flames")
	check(run.hurt_cooldown == .78,"actual damage still grants a normal recovery window")
	run = earned()
	run.grapple.cancel(run)
	run.boss.clock = 999
	advance(run,7.2)
	check(run.grapple.energy == 0 and run.grapple.loss_reason == "鎖が途切れた","the gauge expires after seven seconds without another connection")
	run = earned()
	var flame_count = run.grapple.energy
	var left = run.grapple.energy_left
	run.xp = run.xp_needed
	run.level_up()
	advance(run,2)
	check(run.grapple.energy == flame_count and run.grapple.energy_left == left,"upgrade choices pause both the stored reward and its expiry timer")
	run.choose(run.offers[0])
	check(run.phase == "playing" and run.grapple.energy == flame_count,"a valid card resumes with the earned flames intact")

	print("CHAIN RISK CHECKS ",checks-failures,"/",checks," passed")
	quit(1 if failures else 0)
