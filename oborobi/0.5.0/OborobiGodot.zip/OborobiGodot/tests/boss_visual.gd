extends SceneTree
## Native rendering and actual simulation/input; still captures, never video.
const Scene = preload("res://main.tscn")
const Bot = preload("res://tests/boss_bot.gd")
var game
var bot = Bot.new()
var frame_times = []
var previous_frame = 0

func _initialize():
	root.size = Vector2i(1280,720)
	call_deferred("inspect")

func frame(with_bot = false):
	if game.run.phase == "upgrade": game.select_upgrade(game.run.offers[0])
	if with_bot: bot.act(game.run,1.0/60)
	game._process(1.0/60)
	await process_frame
	var now = Time.get_ticks_usec()
	if previous_frame > 0: frame_times.append((now-previous_frame)/1000.0)
	previous_frame = now

func swipe(direction):
	var event = InputEventScreenTouch.new()
	event.index = 0
	event.position = root.get_screen_transform()*Vector2(150,500)
	event.pressed = true
	Input.parse_input_event(event)
	await process_frame
	var drag = InputEventScreenDrag.new()
	drag.index = 0
	drag.position = root.get_screen_transform()*(Vector2(150,500)+direction.normalized()*65)
	Input.parse_input_event(drag)
	await process_frame
	event.pressed = false
	Input.parse_input_event(event)
	await process_frame

func rite(id):
	var event = InputEventScreenTouch.new()
	event.index = 0
	event.position = root.get_screen_transform()*game.hud.ultimate_buttons[id].get_global_rect().get_center()
	event.pressed = true
	Input.parse_input_event(event)
	await process_frame
	event.pressed = false
	Input.parse_input_event(event)
	await process_frame

func inspect():
	game = Scene.instantiate()
	root.add_child(game)
	await process_frame
	await process_frame
	game.set_process(false)
	game.hud.update_hud()
	await game._save_shot("20-boss-intro")
	game.start_run(true)
	for _i in range(139): await frame()
	assert(game.run.boss.state == "windup")
	game.hud.update_hud()
	await game._save_shot("21-boss-warning")
	print("PASS native giant and real attack warning rendered")
	await swipe(Vector2.LEFT)
	for _i in range(100):
		await frame()
		if game.run.boss.state == "open": break
	assert(game.run.grapple.energy == 1 and game.run.hp == 100)
	game.hud.update_hud()
	await game._save_shot("22-boss-chain-evade")
	var anchor = game.run.boss.anchors[game.run.boss.open_anchor]
	await swipe(anchor.p-game.run.player)
	for _i in range(90):
		await frame()
		if game.run.boss.counters == 1: break
	assert(game.run.grapple.energy == 3 and game.run.boss.counters == 1)
	game.hud.update_hud()
	await game._save_shot("23-boss-return-chain")
	print("PASS real native swipes escape a warning and return to its lit ring")
	for id in ["chain","flame","blade"]:
		# Ordinary attendants arranged for seeing breakup VFX. No changed HP,
		# weapon power, boss health, player invulnerability, or XP thresholds.
		for p in [Vector2(170,223),Vector2(480,183),Vector2(498,290),Vector2(118,279),Vector2(362,126),Vector2(548,230)]:
			game.run.spawn_enemy(0,p)
		await rite(id)
		assert(game.run.ultimates.casts[id] == 1)
		for i in range(43):
			await frame()
			if i in [15,34]:
				game.hud.update_hud()
				await game._save_shot("%02d-%s-rite-%s" % [24+["chain","flame","blade"].find(id),id,"start" if i == 15 else "fade"])
	print("PASS all three manual rites rendered at early and late motion phases")
	var captured = {}
	for _i in range(240*60):
		await frame(true)
		if game.run.grapple.burst_left > .25 and game.run.grapple.burst_left < .48 and not captured.has("gold"):
			captured.gold = true
			await game._save_shot("27-boss-golden-rush")
		if game.run.phase == "upgrade" and not captured.has("upgrade"):
			captured.upgrade = true
			await game._save_shot("28-boss-upgrade")
		if game.run.boss.state == "defeated" and game.run.boss.death_left < .9 and not captured.has("breakup"):
			captured.breakup = true
			await game._save_shot("29-boss-breakup")
		if game.run.phase in ["won","lost"]: break
	assert(game.run.phase == "won" and game.run.boss.counters >= 3)
	game.hud.update_hud()
	await game._save_shot("30-boss-clear")
	frame_times.sort()
	var report = {"phase":game.run.phase,"seconds":snappedf(game.run.time,.01),"hp":game.run.hp,"level":game.run.level,
		"dodges":game.run.boss.dodges,"counters":game.run.boss.counters,"bursts":game.run.grapple.bursts,
		"manual_casts":game.run.ultimates.casts,"peak_enemies":game.run.peak_enemies,"peak_particles":game.run.peak_particles,
		"frame_p95_ms":frame_times[int(frame_times.size()*.95)],"renderer":RenderingServer.get_video_adapter_name()}
	var output = FileAccess.open("res://captures/boss-runtime.json",FileAccess.WRITE)
	output.store_string(JSON.stringify(report,"\t"))
	output.close()
	print("NATIVE BOSS RUN ",JSON.stringify(report))
	game.queue_free()
	await process_frame
	await create_timer(.20).timeout
	quit()
