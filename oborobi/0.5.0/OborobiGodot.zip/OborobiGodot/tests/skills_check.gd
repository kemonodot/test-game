extends SceneTree
const Core = preload("res://scripts/combat.gd")
const Arts = preload("res://scripts/skills.gd")
const Geometry = preload("res://scripts/arena_geometry.gd")
var checks = 0
var failures = 0

func _initialize():
	call_deferred("test")

func check(ok, description):
	checks += 1
	if ok: print("PASS ",description)
	else:
		failures += 1
		push_error("FAIL "+description)

func quiet():
	var run = Core.new(1729)
	run.start(false)
	run.spawn_clock = 999
	run.sword_clock = 999
	run.fire_clock = 999
	return run

func enemy(run, at):
	var e = run.spawn_enemy(0,at)
	e.hp = 1000
	e.speed = 0
	return e

func test():
	for id in Arts.IDS:
		var run = quiet()
		var baseline = run.stats()
		run.phase = "upgrade"
		run.offers = [id]
		check(run.choose(id) and run.stats() == baseline,"unlocking "+id+" adds an attack without changing base stats")
	var run = quiet()
	run.xp = run.xp_needed
	run.level_up()
	check(run.offers.size() == 3 and run.offers.all(func(id): return Arts.IDS.has(id)),"the first level-up presents three different new attack patterns")
	for id in Arts.IDS: run.upgrades[id] = 1
	run.phase = "playing"
	run.level_up()
	check(run.offers.all(func(id): return not Arts.IDS.has(id)),"one-time skills cannot be offered twice")

	run = quiet()
	var e = enemy(run,run.player+Vector2(40,0))
	run.skills.step(run,.5)
	check(e.hp == 1000 and run.skills.effects.is_empty() and run.skills.burns.is_empty(),"locked skills neither damage enemies nor create effects")

	run = quiet()
	run.upgrades.chain_lightning = 1
	for i in range(4): enemy(run,run.player+Vector2(50+i*25,4*(i%2)))
	run.skills.step(run,.3)
	check(run.skills.hits.chain_lightning == 3 and run.skills.effects[0].points.size() == 4,"lightning hits three distinct enemies and draws every jump")
	check(run.enemies.filter(func(foe): return foe.hp < 1000).size() == 3,"lightning damages exactly the three displayed targets")
	run = quiet()
	run.player = Vector2(219,185)
	e = enemy(run,Vector2(219,135))
	run.upgrades.chain_lightning = 1
	run.skills.step(run,.3)
	check(e.hp == 1000 and run.skills.effects.is_empty(),"lightning cannot acquire through masonry")

	run = quiet()
	run.upgrades.cinder_trail = 1
	e = enemy(run,run.player)
	run.velocity = Vector2(400,0)
	run.skills.step(run,.04)
	check(run.skills.burns.size() == 1 and e.hp < 1000,"fast movement leaves a real damaging blue flame patch")
	var after_burn = e.hp
	run.skills.step(run,.04)
	check(e.hp == after_burn,"burn damage has a cooldown rather than firing every frame")
	run.skills.tick_visual(1)
	check(run.skills.burns.is_empty(),"flame patches expire instead of filling the battlefield")
	for i in range(160):
		run.time += .04
		run.skills.step(run,.04)
		run.skills.tick_visual(.04)
	check(run.skills.burns.size() <= Arts.MAX_BURNS,"flame patches respect the mobile effect budget")

	run = quiet()
	run.upgrades.orbit_blades = 1
	e = enemy(run,run.player+Vector2(40,0))
	run.skills.step(run,.016)
	check(run.skills.blade_positions(run).size() == 3 and e.hp < 1000,"three orbiting blades are actual weapons and hit along their path")
	var after_orbit = e.hp
	run.skills.step(run,.016)
	check(e.hp == after_orbit,"orbiting blades do not damage the same enemy every frame")
	run = quiet()
	run.player = Vector2(219,179)
	run.upgrades.orbit_blades = 1
	run.skills.orbit_angle = -PI/2
	e = enemy(run,Vector2(219,142))
	run.skills.step(run,.016)
	check(e.hp == 1000,"an orbiting blade cannot damage an enemy on the other side of a wall")

	run = quiet()
	run.upgrades.petal_wave = 1
	e = enemy(run,run.player+Vector2(65,0))
	run.skills.petals(run)
	run.skills.step(run,.01)
	check(e.hp == 1000,"a distant enemy is not hit before the petal wave reaches it")
	run.skills.tick_visual(.35)
	run.skills.step(run,.01)
	check(e.hp == 969 and run.skills.hits.petal_wave == 1,"the expanding flower wave damages when its visible radius reaches an enemy")
	run.skills.step(run,.01)
	check(e.hp == 969,"each flower wave hits an enemy once")
	run = quiet()
	run.player = Vector2(219,185)
	e = enemy(run,Vector2(219,135))
	run.upgrades.petal_wave = 1
	run.skills.petals(run)
	run.skills.tick_visual(.40)
	run.skills.step(run,.01)
	check(e.hp == 1000,"flower waves cannot cut through the wall")
	for i in range(80): run.skills.petals(run)
	check(run.skills.effects.size() <= Arts.MAX_EFFECTS,"burst effects have a fixed upper bound")
	var casts_before = run.skills.casts.duplicate()
	run.phase = "upgrade"
	run.step(5,Vector2.ZERO)
	check(run.skills.casts == casts_before and e.hp == 1000,"upgrade selection pauses new attacks and damage")
	print("SKILL CHECKS ",checks-failures,"/",checks," passed")
	quit(1 if failures else 0)
