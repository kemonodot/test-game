extends SceneTree
const Core = preload("res://scripts/combat.gd")
const Geometry = preload("res://scripts/arena_geometry.gd")
const Bot = preload("res://tests/boss_bot.gd")
var checks = 0
var failures = 0

func _initialize(): call_deferred("test")
func check(ok, description):
	checks += 1
	if ok: print("PASS ",description)
	else:
		failures += 1
		push_error("FAIL "+description)

func quiet():
	var run = Core.new(92)
	run.start()
	run.sword_clock = 999
	run.fire_clock = 999
	run.boss.clock = 999
	run.boss.summon_clock = 999
	return run

func advance(run, seconds):
	for _i in range(int(ceil(seconds*60))):
		run.tick_visual(1.0/60)
		run.step(1.0/60,Vector2.ZERO)
		run.sounds.clear()

func peak_pull(haste):
	var run = quiet()
	if haste: run.ultimates.cast(run,"chain")
	run.grapple.fire(run,Vector2.RIGHT)
	var peak = 0.0
	for _i in range(24):
		run.step(1.0/60,Vector2.ZERO)
		peak = maxf(peak,Geometry.ground(run.velocity).length())
	return peak

func test():
	var run = quiet()
	check(run.stage == "boss" and run.boss.active() and run.enemies.size() == 1,"a new run starts directly against one giant")
	check(run.boss.anchors.size() == 3 and run.boss.actor.max_hp == Core.Giant.HEALTH,"the giant has its own substantial health and three physical chain rings")
	var target = run.grapple.acquire(run,Geometry.ground(run.boss.anchors[2].p-run.player).normalized())
	check(target.kind == "boss" and target.anchor.id == 2,"swipe aim assist can select a boss ring")
	run.grapple.fire(run,Geometry.ground(target.p-run.player).normalized())
	advance(run,.7)
	check(run.grapple.enemy_catches == 1 and run.boss.actor.hp < Core.Giant.HEALTH and run.grapple.energy == 0,"a real chain arrival attacks the giant without farming a flame")
	run = quiet()
	run.time = 179.999
	advance(run,.04)
	check(run.phase == "playing" and run.time > 180,"elapsed survival time never clears a living boss")
	run = quiet()
	for _i in range(5):
		run.boss.summon_clock = 0
		advance(run,.04)
	check(run.enemies.size() == 9,"attendants stop at eight instead of becoming a horde")

	run = quiet()
	var before = run.boss.actor.hp
	run._hurt_enemy(run.boss.actor,100,Vector2.RIGHT,"sword",false)
	var armored = before-run.boss.actor.hp
	run.boss.state = "open"
	before = run.boss.actor.hp
	run._hurt_enemy(run.boss.actor,100,Vector2.RIGHT,"sword",false)
	check(armored == 24 and before-run.boss.actor.hp == 100,"the opening matters: passive damage is reduced while the giant is guarded")
	check(peak_pull(true) > peak_pull(false)*1.35,"chain ultimate substantially increases real reel-in speed, not only a label")
	run = quiet()
	var original = run.stats()
	check(run.ultimates.cast(run,"chain") and run.ultimates.haste_left == 5,"chain rite grants five seconds of high mobility")
	check(run.stats().speed > original.speed*1.7 and run.stats().sword_damage == original.sword_damage,"chain rite adds escape mobility without increasing passive sword power")
	var effects = run.ultimates.effects.size()
	check(not run.ultimates.cast(run,"chain") and run.ultimates.effects.size() == effects,"a cooldown rejects repeated presses without duplicate effects")
	check(run.ultimates.cast(run,"flame") and run.ultimates.cast(run,"blade"),"the three rites have independent readiness")
	advance(run,5.3)
	check(run.ultimates.haste_left == 0 and run.ultimates.quench_left == 0 and run.ultimates.fracture_left == 0,"all three temporary utilities expire")
	check(run.ultimates.effects.is_empty(),"the wide VFX disappear rather than becoming a permanent screen cover")

	run = quiet()
	run.hurt_player(50,Vector2.RIGHT)
	run.ultimates.cast(run,"flame")
	check(run.hp == 78 and run.ultimates.healed == 28,"flame rite restores actual lost HP")
	var e = run.spawn_enemy(0,run.player)
	e.hp = 1000
	e.speed = 0
	advance(run,1.4)
	check(run.hp == 78 and e.hp < 1000,"flame suppresses attendant contact attacks while its burn deals damage")
	run = quiet()
	run.boss.clock = 2
	run.ultimates.cast(run,"flame")
	advance(run,.5)
	check(run.boss.clock > 1.67,"flame slows the giant's actual attack countdown")
	run.boss.windup(run)
	run.boss.clock = .001
	advance(run,.06)
	check(run.hp == 90,"an unavoidable marked hit is halved by flame's suppression")

	run = quiet()
	run.ultimates.cast(run,"blade")
	check(run.ultimates.fracture_left == 5 and run.boss.anchors.all(func(a): return run.boss.is_open(a.id,run)),"blade breaks the guard and opens all three rings for follow-up")
	before = run.boss.actor.hp
	run._hurt_enemy(run.boss.actor,100,Vector2.RIGHT,"sword",false)
	check(before-run.boss.actor.hp == 135,"blade's follow-up really defeats the guarded damage reduction")
	check(run.hp == 100 and run.ultimates.haste_left == 0 and run.ultimates.quench_left == 0,"blade's utility is distinct from healing and mobility")

	run = quiet()
	run.player = Vector2(219,185)
	e = run.spawn_enemy(1,Vector2(219,124))
	run.ultimates.cast(run,"blade")
	check(not e.alive and run.boss.actor.hp < Core.Giant.HEALTH,"screen-wide rites reach enemies beyond masonry while normal attacks remain blocked")
	check(run.particles.size() <= Core.MAX_PARTICLES and run.ultimates.effects.size() <= 3,"manual rites obey the shared particle and effect budgets")
	var remaining = run.ultimates.cooldown.blade
	run.xp = run.xp_needed
	run.level_up()
	advance(run,2)
	check(run.ultimates.cooldown.blade == remaining and not run.ultimates.cast(run,"chain"),"an upgrade freezes cooldowns and rejects manual casting")
	check(not run.ultimates.cast(run,"unknown"),"unknown rites cannot execute")

	run = quiet()
	run._hurt_enemy(run.boss.actor,50000,Vector2.RIGHT,"sword",true)
	check(run.boss.state == "defeated" and run.phase == "playing" and run.particles.size() >= 80,"giant defeat first runs a substantial breakup sequence")
	advance(run,1.5)
	check(run.phase == "won" and run.grapple.state == "idle","only the giant's defeat sequence leads to clear")

	var reports = []
	for seed_value in [7319,23,81]:
		run = Core.new(seed_value)
		run.start()
		var bot = Bot.new()
		for _i in range(60*300):
			run.tick_visual(1.0/60)
			var move = bot.act(run,1.0/60)
			run.step(1.0/60,move)
			run.sounds.clear()
			if run.phase in ["won","lost"]: break
		check(run.phase == "won" and run.boss.counters >= 2 and run.grapple.catches > 5,"complete normal-HP boss fight clears by chain counters, seed "+str(seed_value))
		check(run.peak_enemies <= 9 and run.peak_particles <= Core.MAX_PARTICLES and run.level >= 2,"complete fight keeps attendant/particle caps and grows from earned XP, seed "+str(seed_value))
		reports.append({"seed":seed_value,"result":run.phase,"seconds":snappedf(run.time,.01),"hp":snappedf(run.hp,.01),"boss_hp":run.boss.actor.hp,"level":run.level,"kills":run.kills,"dodges":run.boss.dodges,"counters":run.boss.counters,"bursts":run.grapple.bursts,"manual_casts":run.ultimates.casts,"peak_enemies":run.peak_enemies,"peak_particles":run.peak_particles})
	print("BOSS RUNS ",JSON.stringify(reports))
	print("BOSS CHECKS ",checks-failures,"/",checks," passed")
	quit(1 if failures else 0)
