extends RefCounted
## Player actions with normal HP, spawns, cooldowns and XP; no balance claim.
const Geometry = preload("res://scripts/arena_geometry.gd")
var shot_clock = 0.0
var course = 0
var escaped_attack = -1
var approached_attack = -1

func act(run, dt):
	if run.phase == "upgrade":
		var priorities = ["orbit_blades","cinder_trail","chain_lightning","petal_wave","edge","reach","cadence","ember","barrage","ward","mending","stride","pierce","magnet"]
		if run.hp < run.max_hp*.6: priorities = ["ward","mending"]+priorities
		for id in priorities:
			if run.offers.has(id):
				run.choose(id)
				break
	if run.phase != "playing": return Vector2.ZERO
	shot_clock -= dt
	if run.hp < run.max_hp*.7: run.ultimates.cast(run,"flame")
	if run.stage == "waves":
		if run.enemies.size() > 25: run.ultimates.cast(run,"blade")
		var destinations = [Vector2(95,292),Vector2(551,292),Vector2(551,116),Vector2(95,116)]
		if shot_clock <= 0:
			if Geometry.ground(destinations[course%4]-run.player).length() < 68: course += 1
			run.grapple.fire(run,Geometry.ground(destinations[course%4]-run.player).normalized())
			shot_clock = 1.0
		return Vector2.ZERO
	var boss = run.boss
	if not boss.active(): return Vector2.ZERO
	if boss.state == "windup" and boss.contains(run.player) and escaped_attack != boss.attack_id:
		if run.ultimates.cooldown.chain <= 0: run.ultimates.cast(run,"chain")
		var best_direction = Vector2.ZERO
		var best_score = INF
		for i in range(48):
			var direction = Vector2.from_angle(i*TAU/48)
			var target = run.grapple.acquire(run,direction)
			if target.kind == "miss": continue
			var stop = 21 if target.kind == "boss" else (27 if target.kind == "enemy" else 10)
			var destination = target.p-Geometry.project(Geometry.ground(target.p-run.player).normalized()*stop)
			if boss.contains(destination) or Geometry.segment_circle(run.player,destination,boss.actor.p,41) >= 0: continue
			var distance = Geometry.ground(destination-run.player).length()
			if distance < 40: continue
			if distance < best_score:
				best_score = distance
				best_direction = direction
		if best_direction != Vector2.ZERO and run.grapple.fire(run,best_direction):
			escaped_attack = boss.attack_id
			shot_clock = .24
	elif boss.state == "open":
		run.ultimates.cast(run,"blade")
		if shot_clock <= 0 and approached_attack != boss.attack_id:
			var anchor = boss.anchors[boss.open_anchor]
			var direction = Geometry.ground(anchor.p-run.player).normalized()
			var blocked = Geometry.segment_circle(run.player,anchor.p,boss.actor.p,40) >= 0 or not Geometry.clear_line(run.player,anchor.p)
			if blocked:
				var waypoint = boss.actor.p+Vector2(-104 if run.player.x < boss.actor.p.x else 104,62)
				direction = Geometry.ground(waypoint-run.player).normalized()
			if Geometry.ground(anchor.p-run.player).length() > 24 and run.grapple.fire(run,direction): shot_clock = .40
			if boss.counter_used: approached_attack = boss.attack_id
	return Vector2.ZERO
