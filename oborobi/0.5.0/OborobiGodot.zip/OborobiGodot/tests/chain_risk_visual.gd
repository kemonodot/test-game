extends "res://tests/boss_visual.gd"
## The revised risk loop is exercised by the current boss capture driver.
