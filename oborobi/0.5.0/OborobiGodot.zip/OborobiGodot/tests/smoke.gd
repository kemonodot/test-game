extends SceneTree
## Real GDScript simulation plus the actual scene, input and card controls.
const Core = preload("res://scripts/combat.gd")
const Scene = preload("res://main.tscn")
var checks = 0
var failed = 0

func _initialize():
	# Headless windows otherwise default to 64x64 physical pixels. Synthetic
	# screen events use physical coordinates, just like a real touch screen.
	root.size = Vector2i(1280,720)
	call_deferred("run_checks")

func check(condition, description):
	checks += 1
	if condition:
		print("PASS ",description)
	else:
		failed += 1
		push_error("FAIL "+description)

func advance(run, seconds, movement = Vector2.ZERO):
	for i in range(int(seconds*60)):
		run.tick_visual(1.0/60)
		run.step(1.0/60,movement)

func run_checks():
	var run = Core.new(4)
	run.start(false)
	var start = run.player
	advance(run,.4,Vector2.RIGHT)
	check(run.player.x > start.x+20,"free movement responds immediately")
	advance(run,8,Vector2.RIGHT)
	check(run.player.x <= Core.FLOOR.end.x,"player remains in the shrine boundary")
	run = Core.new(5)
	run.start(false)
	run.spawn_clock = 999
	var chaser = run.spawn_enemy(1,run.player+Vector2(90,0))
	var original_distance = chaser.p.distance_to(run.player)
	advance(run,.5)
	check(chaser.p.distance_to(run.player) < original_distance,"heavy enemy pursues the player")
	run = Core.new(6)
	run.start(false)
	run.spawn_clock = 999
	run.spawn_enemy(0,run.player+Vector2(27,0))
	run.sword_attack()
	check(run.kills == 1 and run.sword_hits == 1 and run.slashes.size() == 1,"automatic sword deals directional damage and creates a slash")
	check(run.particles.size() >= 15 and run.souls.size() == 1,"enemy shatters into colored debris and drops a soul")
	var normal_particles = run.particles.duplicate(true)
	var average_normal = 0.0
	for p in normal_particles:
		if p.body: average_normal += p.v.length()
	advance(run,.7)
	check(run.particles.is_empty(),"debris disappears quickly instead of accumulating")
	check(run.xp >= 1 and run.souls_taken == 1,"nearby experience is attracted and absorbed")
	run = Core.new(6)
	run.start(false)
	run.upgrades.edge = 3
	run.spawn_enemy(0,run.player+Vector2(27,0))
	run.sword_attack()
	var average_heavy = 0.0
	for p in run.particles:
		if p.body: average_heavy += p.v.length()
	check(run.heavy_shatters == 1 and average_heavy > average_normal*1.5,"powerful attacks produce more energetic body fragments")
	run = Core.new(7)
	run.start(false)
	run.spawn_clock = 999
	run.sword_clock = 999
	run.spawn_enemy(0,run.player+Vector2(135,0))
	run.fire_attack()
	advance(run,1.1)
	check(run.fire_hits > 0,"blue soul fire reaches a distant pursuing enemy")
	run = Core.new(8)
	run.start(false)
	run.xp = 9
	run.step(1.0/60,Vector2.ZERO)
	check(run.phase == "upgrade" and run.offers.size() == 3 and run.offers[0] != run.offers[1] and run.offers[0] != run.offers[2] and run.offers[1] != run.offers[2],"level up offers three different upgrades")
	var stopped_time = run.time
	advance(run,2)
	check(run.time == stopped_time,"upgrade selection pauses the combat clock")
	check(not run.choose("not-an-offer"),"unoffered upgrades cannot be selected")
	check(run.choose(run.offers[0]) and run.phase == "playing","choosing a valid card resumes combat")
	run = Core.new(9)
	run.start(false)
	for _i in range(180): run.spawn_enemy(0,Vector2(30,30))
	check(run.enemies.size() == Core.MAX_ENEMIES,"enemy count is bounded for mobile performance")
	for e in run.enemies: run._hurt_enemy(e,1000,Vector2.RIGHT,"sword",true)
	check(run.particles.size() <= Core.MAX_PARTICLES,"mass kills obey the particle budget")
	run = Core.new(10)
	run.start(false)
	run.hurt_player(1000,Vector2.RIGHT)
	check(run.phase == "dying" and run.particles.size() >= 30,"player death has a visible shattering sequence")
	run.tick_visual(1.2)
	check(run.phase == "lost","death sequence leads to game over")

	# Complete normal-HP boss fights live in boss_check.gd; this checks scene wiring.
	run = Core.new(11)
	run.start()
	check(run.boss.active() and run.boss_only and run.stage == "boss", "default run enters the giant fight immediately")

	var game = Scene.instantiate()
	root.add_child(game)
	await process_frame
	game.set_process(false)
	game.start_run()
	var touch = InputEventScreenTouch.new()
	touch.index = 0
	touch.position = root.get_screen_transform()*Vector2(150,500)
	touch.pressed = true
	Input.parse_input_event(touch)
	await process_frame
	var drag = InputEventScreenDrag.new()
	drag.index = 0
	drag.position = root.get_screen_transform()*Vector2(211,500)
	Input.parse_input_event(drag)
	await process_frame
	check(game.stick_active and game.aim_input.x > 50 and game.run.grapple.shots == 1,"actual touch swipe fires before lifting the finger")
	touch.pressed = false
	Input.parse_input_event(touch)
	await process_frame
	check(not game.stick_active and game.aim_input == Vector2.ZERO and game.run.grapple.shots == 1,"lifting after a swipe does not fire a second chain")
	game.toggle_pause()
	check(game.paused and game.hud.current_panel == "paused","pause opens the actual pause overlay")
	game.toggle_pause()
	check(not game.paused and game.hud.current_panel == "","resume closes the overlay")
	game.run.xp = 9
	game._process(1.0/60)
	check(game.hud.choice_buttons.size() == 3,"the real scene builds three tappable cards")
	var selected_id = game.hud.choice_buttons[0].get_meta("upgrade_id")
	game.hud.choice_buttons[0].pressed.emit()
	check(game.run.count(selected_id) == 1 and game.run.phase == "playing","actual card signal applies an upgrade")
	game.run.time = 179.999
	game._process(1.0/60)
	check(game.run.phase == "playing" and game.run.boss.active(), "the real scene never clears merely because three minutes elapsed")
	game.run._hurt_enemy(game.run.boss.actor,50000,Vector2.UP,"sword",true)
	for _i in range(90): game._process(1.0/60)
	check(game.run.phase == "won" and game.hud.current_panel == "won", "the real scene shows clear only after the giant breaks apart")

	game.start_run()
	check(game.run.time == 0 and game.run.hp == 100 and game.run.level == 1 and game.run.kills == 0 and game.run.upgrades.is_empty(),"retry fully resets the run")
	check(game.run.boss.actor.hp == Core.Giant.HEALTH and game.run.ultimates.cooldown.values().all(func(value): return value == 0), "retry restores the giant and all three manual rites")
	game.queue_free()
	await process_frame
	await process_frame
	await create_timer(.12).timeout
	print("TEST SUMMARY ",checks-failed,"/",checks," passed")
	quit(1 if failed > 0 else 0)
