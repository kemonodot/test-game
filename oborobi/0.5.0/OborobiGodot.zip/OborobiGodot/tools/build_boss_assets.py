"""Original 128px oni, at native pixel resolution, and short procedural cues.

No photo/reference pixels, runtime dependencies, filters, or resized sprites.
Regenerate with Python + Pillow; the shipped PNG/WAV files run directly in Godot.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import math
import random
import struct
import wave

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / 'assets/art'
AUDIO = ROOT / 'assets/audio'
INK, SHADOW, ROBE = '#0b121f', '#242334', '#3d3547'
BONE, BONE_DARK, GOLD = '#d2c19a', '#8b796e', '#c59e68'
RED, COLD = '#b35d62', '#7cc9d6'


def oni(frame):
    im = Image.new('RGBA', (128, 128))
    d = ImageDraw.Draw(im)
    bob = [0, -2, 1, 5][frame]
    # Split hakama and stone-claw feet. Cloth uses stepped, unfiltered edges.
    d.polygon([(38, 77), (88, 77), (100, 110), (85, 119), (69, 110),
               (62, 118), (39, 117), (26, 108)], fill=INK)
    d.polygon([(42, 78), (58, 86), (53, 114), (38, 112), (33, 104)], fill=ROBE)
    d.polygon([(68, 85), (85, 79), (94, 108), (82, 115), (73, 110)], fill='#493b4c')
    for x in [42, 48, 76, 84]:
        d.line([(x, 85), (x - 4 if x < 60 else x + 5, 108)], fill='#67515b', width=1)
    for x in [35, 79]:
        d.polygon([(x, 113), (x+15, 113), (x+19, 121), (x-4, 121), (x-5, 118)], fill='#171c2b')
        for j in range(3):
            d.polygon([(x+j*6-3, 117), (x+j*6, 115), (x+j*6+3, 120), (x+j*6-4, 120)], fill=BONE_DARK)
            d.line((x+j*6-1, 117, x+j*6+1, 117), fill=BONE)

    # Long folded arms flank the body, with enormous bony hands at floor level.
    lift = [0, -6, 3, 2][frame]
    for side in [-1, 1]:
        def mirror(points):
            return [(64+side*x, y) for x, y in points]
        d.polygon(mirror([(19, 41+bob), (31, 40+bob), (44, 59+lift),
                          (51, 86+lift), (58, 96+lift), (55, 105+lift),
                          (39, 99+lift), (29, 79+lift), (15, 61+bob)]), fill=INK)
        d.polygon(mirror([(26, 44+bob), (33, 46+bob), (42, 65+lift),
                          (43, 84+lift), (38, 87+lift), (28, 67+bob), (21, 53+bob)]), fill='#4c414f')
        d.line(mirror([(31, 47+bob), (40, 66+lift), (41, 81+lift)]), fill='#8a6869', width=2)
        d.line(mirror([(25, 61+bob), (32, 78+lift), (37, 88+lift)]), fill='#252536', width=3)
        d.polygon(mirror([(42, 83+lift), (51, 85+lift), (59, 93+lift),
                          (59, 104+lift), (55, 108+lift), (47, 106+lift), (39, 95+lift)]), fill=BONE_DARK)
        d.polygon(mirror([(44, 85+lift), (50, 87+lift), (56, 94+lift),
                          (56, 98+lift), (49, 97+lift), (41, 91+lift)]), fill=BONE)
        for finger in range(3):
            x, y = 48+finger*4, 96+lift+finger%2
            d.line(mirror([(x, y), (x+1, y+7), (x-1, y+10)]), fill=INK, width=3)
            d.line(mirror([(x, y), (x+1, y+6), (x-1, y+9)]), fill='#b8a88b', width=1)
        # Bronze manacles and sewn paper talismans tie the art to the chain mechanic.
        d.line(mirror([(38, 82+lift), (48, 79+lift)]), fill=INK, width=7)
        d.line(mirror([(38, 82+lift), (48, 79+lift)]), fill=GOLD, width=3)
        for link in range(4):
            x, y = 40+link*3, 87+lift+link*4
            p = mirror([(x, y)])[0]
            d.rectangle((p[0]-2, p[1]-1, p[0]+2, p[1]+1), outline='#b29a77')
        p = mirror([(33, 58+bob)])[0]
        d.rectangle((p[0]-2, p[1], p[0]+2, p[1]+11), fill='#a49e86')
        d.line((p[0], p[1]+2, p[0], p[1]+8), fill='#704650')

    # Layered, frayed shrine vestments, ribs, and a hanging shimenawa knot.
    d.polygon([(43, 37+bob), (83, 37+bob), (91, 69+bob), (86, 92),
               (67, 91), (59, 97), (35, 91), (36, 64+bob)], fill=INK)
    d.polygon([(46, 43+bob), (60, 54+bob), (54, 80), (37, 87), (41, 63+bob)], fill=ROBE)
    d.polygon([(67, 52+bob), (79, 40+bob), (86, 63+bob), (82, 83), (70, 79)], fill='#59434f')
    d.line([(47, 44+bob), (59, 53+bob), (57, 64+bob)], fill='#987272', width=2)
    d.line([(78, 42+bob), (67, 51+bob), (69, 65+bob)], fill='#b08a7b', width=2)
    for rib in range(4):
        y = 51+bob+rib*6
        d.line([(54, y), (61, y+3), (64, y+3), (71, y)], fill=BONE_DARK, width=3)
        d.line([(55, y-1), (61, y+1)], fill='#b09d83', width=1)
    d.polygon([(60, 55+bob), (67, 55+bob), (69, 68+bob), (63, 72+bob), (57, 66+bob)], fill='#163044')
    d.line([(63, 58+bob), (60, 64+bob), (64, 68+bob), (66, 62+bob)], fill=COLD, width=2)
    if frame == 3:
        d.line((62, 59+bob, 65, 67+bob), fill='#e2ddba', width=2)
    for x in range(37, 87, 4):
        y = 74+int(abs(x-63)*.10)
        d.line([(x, y), (x+3, y+3), (x+5, y)], fill='#655447', width=4)
        d.line([(x, y-1), (x+3, y+1), (x+5, y-1)], fill=GOLD, width=2)
    for x in [43, 56, 71, 82]:
        d.line([(x, 79), (x-2, 84), (x+2, 87), (x-1, 91)], fill=BONE, width=3)
        d.point((x, 85), fill='#62545b')
    d.rectangle((60, 75, 68, 88), fill='#99745d')
    d.rectangle((62, 77, 66, 85), fill=GOLD)
    d.rectangle((63, 79, 65, 82), fill='#2b3440')

    # Ragged mane, asymmetric lacquer oni mask, horn facets and two cold eyes.
    d.polygon([(49, 18+bob), (42, 24+bob), (36, 41+bob), (44, 37+bob),
               (43, 49+bob), (51, 42+bob), (59, 45+bob), (80, 41+bob),
               (87, 47+bob), (87, 32+bob), (81, 21+bob), (72, 15+bob)], fill=INK)
    for x, y in [(42, 33), (46, 25), (77, 22), (84, 35)]:
        d.line((x, y+bob, x-2, y+10+bob), fill='#4e404d', width=2)
    for points in [[(49, 24), (40, 16), (43, 5), (48, 11), (54, 22)],
                   [(73, 21), (79, 9), (87, 3), (84, 16), (79, 27)]]:
        d.polygon([(x, y+bob) for x, y in points], fill=INK)
        d.polygon([(x, y+1+bob) for x, y in points[1:]], fill=BONE_DARK)
        d.line([(points[1][0]+1, points[1][1]+bob), (points[-1][0]-1, points[-1][1]+bob)], fill=BONE, width=1)
    d.polygon([(49, 21+bob), (61, 17+bob), (75, 21+bob), (79, 29+bob),
               (75, 40+bob), (65, 48+bob), (53, 43+bob), (46, 31+bob)], fill='#342b38')
    d.polygon([(50, 22+bob), (61, 20+bob), (65, 24+bob), (62, 33+bob),
               (66, 43+bob), (56, 41+bob), (50, 34+bob)], fill='#b29a81')
    d.polygon([(66, 22+bob), (74, 24+bob), (76, 31+bob), (72, 40+bob),
               (67, 42+bob), (63, 33+bob)], fill='#7c4b54')
    d.line([(51, 26+bob), (59, 28+bob)], fill=INK, width=4)
    d.line([(68, 28+bob), (74, 26+bob)], fill=INK, width=4)
    d.line((52, 28+bob, 58, 29+bob), fill='#a9dde0', width=1)
    d.line((68, 29+bob, 73, 28+bob), fill='#eea196', width=1)
    d.point((56, 28+bob), fill='#ebf2d2')
    d.point((70, 28+bob), fill='#ffd2a7')
    d.polygon([(60, 28+bob), (65, 26+bob), (68, 34+bob), (62, 35+bob)], fill=BONE_DARK)
    d.line((62, 30+bob, 63, 32+bob), fill=BONE)
    d.polygon([(54, 36+bob), (69, 36+bob), (72, 39+bob), (63, 43+bob), (55, 40+bob)], fill=INK)
    for x, y in [(55, 36), (60, 37), (67, 36)]:
        d.polygon([(x, y+bob), (x+3, y+bob), (x+1, y+5+bob)], fill=BONE)
    d.line([(55, 23+bob), (58, 25+bob), (56, 32+bob), (59, 34+bob)], fill='#75646a')
    return im


sheet = Image.new('RGBA', (512, 128))
for frame in range(4):
    sheet.paste(oni(frame), (frame*128, 0))
sheet.save(ART / 'boss_oni.png')
flash = Image.new('RGBA', sheet.size)
flash.putdata([(230, 223, 190, a) if a else (0, 0, 0, 0) for _, _, _, a in sheet.getdata()])
flash.save(ART / 'boss_oni_flash.png')


def cue(name, length, kind):
    rng = random.Random(kind*1741)
    rate = 22050
    samples = []
    for i in range(int(rate*length)):
        t = i/rate
        f = t/length
        envelope = min(1, t/.012)*max(0, 1-f)**1.9
        noise = rng.uniform(-1, 1)
        if kind == 0:  # chain: metallic links, quick outward crack, falling bass
            value = .26*math.sin(math.tau*(1800*t-600*t*t)) + .12*noise*math.sin(t*120)**2
            value += .20*math.sin(math.tau*(140*t-50*t*t))
        elif kind == 1:  # blue flame: air wash with a rising cold overtone
            value = .16*noise + .22*math.sin(math.tau*(180*t+110*t*t)) + .06*math.sin(math.tau*990*t)
        elif kind == 2:  # blade: narrow metallic initial cut, a resonant tail
            value = .26*noise*math.exp(-t*18) + .22*math.sin(math.tau*730*t)*math.exp(-t*3)
            value += .15*math.sin(math.tau*92*t)
        elif kind == 3:
            value = .18*math.sin(math.tau*196*t) + .09*math.sin(math.tau*294*t) + .03*noise
        else:
            value = .24*math.sin(math.tau*(85*t-16*t*t)) + .13*noise*math.exp(-t*9)
        samples.append(int(max(-.95, min(.95, value*envelope))*32767))
    with wave.open(str(AUDIO / f'{name}.wav'), 'wb') as out:
        out.setnchannels(1)
        out.setsampwidth(2)
        out.setframerate(rate)
        out.writeframes(struct.pack('<'+'h'*len(samples), *samples))


for name, length, kind in [('ultimate_chain', .52, 0), ('ultimate_flame', .70, 1),
                           ('ultimate_blade', .62, 2), ('boss_warning', .34, 3),
                           ('boss_impact', .50, 4)]:
    cue(name, length, kind)
print('Created original boss atlas, flash atlas, and five sound cues.')
