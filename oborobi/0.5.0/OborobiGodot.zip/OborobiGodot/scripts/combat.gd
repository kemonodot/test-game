extends RefCounted
## Simulation shared by the real scene, capture driver and end-to-end tests.
## Positions are projected floor coordinates. All attacks use the same 0.72 projection.

const DURATION = 180.0
const MAX_ENEMIES = 110
const MAX_PARTICLES = 520
const MAX_SOULS = 160
const FLOOR = Rect2(56, 93, 532, 228)
const Geometry = preload("res://scripts/arena_geometry.gd")
const Chain = preload("res://scripts/grapple.gd")
const Arts = preload("res://scripts/skills.gd")
const Giant = preload("res://scripts/boss.gd")
const Ultimates = preload("res://scripts/ultimates.gd")
const UPGRADES = [
	{"id":"cinder_trail", "name":"残火の轍", "tag":"術 / 炎の軌跡", "desc":"鎖で駆けた道に蒼い炎。\n追ってくる敵を焼く。", "max":1, "icon":"fire"},
	{"id":"chain_lightning", "name":"雷渡り", "tag":"術 / 連鎖雷", "desc":"白い雷が敵から敵へ。\n近くの三体をつないで撃つ。", "max":1, "icon":"fire"},
	{"id":"orbit_blades", "name":"三日月の輪", "tag":"術 / 周回する刃", "desc":"三枚の刃が周囲を巡る。\n移動しながら群れを裂く。", "max":1, "icon":"blade"},
	{"id":"petal_wave", "name":"彼岸の花", "tag":"術 / 花の衝撃波", "desc":"花びらの斬撃が広がる。\n定期的に周囲を薙ぎ払う。", "max":1, "icon":"arc"},
	{"id":"edge", "name":"研ぎ澄ます", "tag":"刀 / 威力", "desc":"一閃の威力 +30%\n硬い鬼面も、刀で砕く。", "max":4, "icon":"blade"},
	{"id":"reach", "name":"月の間合い", "tag":"刀 / 範囲", "desc":"斬撃の間合い +18%\n広い白刃で群れを薙ぐ。", "max":3, "icon":"arc"},
	{"id":"cadence", "name":"居合の呼吸", "tag":"刀 / 速度", "desc":"斬撃の間隔 −13%\n刃を返す、一瞬を削る。", "max":4, "icon":"blade"},
	{"id":"ember", "name":"蒼炎の芯", "tag":"魂火 / 威力", "desc":"魂火の威力 +35%\n遠い影に、冷たい炎を。", "max":4, "icon":"fire"},
	{"id":"barrage", "name":"分かつ魂", "tag":"魂火 / 弾数", "desc":"同時に放つ魂火 +1\n別の敵へ炎を分かつ。", "max":2, "icon":"fire"},
	{"id":"pierce", "name":"貫く燐光", "tag":"魂火 / 貫通", "desc":"魂火の貫通回数 +1\n並ぶ影を、一息に穿つ。", "max":2, "icon":"fire"},
	{"id":"stride", "name":"風渡り", "tag":"鎖 / 移動", "desc":"鎖 +7% / 歩行 +13%\n包囲の隙間を抜ける。", "max":3, "icon":"step"},
	{"id":"magnet", "name":"魂寄せ", "tag":"成長 / 回収", "desc":"魂の吸収範囲 +24\n危険な場所へ踏み込まない。", "max":3, "icon":"soul"},
	{"id":"ward", "name":"守りの結び", "tag":"生存 / 体力", "desc":"最大体力 +20 / 体力回復 +28\n裂けた衣を、結び直す。", "max":3, "icon":"ward"},
	{"id":"mending", "name":"静かな灯", "tag":"生存 / 回復", "desc":"毎秒、体力を0.55回復\n戦いながら息を整える。", "max":3, "icon":"ward"}
]

var rng = RandomNumberGenerator.new()
var phase = "menu"
var time = 0.0
var visual_time = 0.0
var player = Vector2(320, 205)
var velocity = Vector2.ZERO
var grapple = Chain.new()
var skills = Arts.new()
var boss = Giant.new()
var ultimates = Ultimates.new()
var stage = "waves"
var boss_only = false
var facing = Vector2.RIGHT
var hp = 100.0
var max_hp = 100.0
var invulnerable = 0.0
var hurt_cooldown = 0.0
var damage_events = 0
var hitstop = 0.0
var shake = 0.0
var level = 1
var xp = 0
var xp_needed = 9
var kills = 0
var souls_taken = 0
var upgrades = {}
var offers = []
var enemies = []
var bullets = []
var souls = []
var particles = []
var slashes = []
var rings = []
var numbers = []
var stains = []
var sounds = []
var spawn_clock = 0.55
var sword_clock = 0.55
var fire_clock = 1.0
var death_clock = 0.0
var next_id = 1
var grid = {}
var peak_enemies = 0
var peak_particles = 0
var heavy_shatters = 0
var fire_hits = 0
var sword_hits = 0

func _init(seed_value = -1):
	if seed_value >= 0:
		rng.seed = seed_value
	else:
		rng.randomize()

func start(only_boss = true):
	phase = "playing"
	boss_only = only_boss
	if only_boss: begin_boss()

func begin_boss():
	stage = "boss"
	grapple.cancel(self)
	# Keep the encounter readable: the giant brings at most eight attendants.
	enemies.clear()
	bullets.clear()
	stains.clear()
	boss.begin(self)
	if boss_only or ground_vector(player-boss.actor.p).length() < 65:
		player = Vector2(322,291)
		velocity = Vector2.ZERO

func count(id):
	return upgrades.get(id, 0)

func stats():
	return {"speed":85.0*(1.0+.13*count("stride"))*(1.8 if ultimates.haste_left > 0 else 1.0), "sword_damage":26.0*(1.0+.30*count("edge")),
		"reach":49.0*(1.0+.18*count("reach")), "sword_interval":.92*pow(.87,count("cadence")),
		"fire_damage":20.0*(1.0+.35*count("ember")), "fire_count":1+count("barrage"),
		"pierce":count("pierce"), "pickup":43.0+24.0*count("magnet")}

static func ground_vector(vector):
	return Vector2(vector.x, vector.y/.72)

func _sound(name):
	if sounds.size() < 24:
		sounds.append(name)

func step(dt, move):
	if phase != "playing":
		return
	invulnerable = maxf(0, invulnerable-dt)
	hurt_cooldown = maxf(0,hurt_cooldown-dt)
	hitstop = maxf(0, hitstop-dt)
	if hitstop > 0:
		return
	time += dt
	ultimates.step(self,dt)
	var s = stats()
	grapple.advance(self,dt,move)
	_move_player(dt,s)
	if move.length() > .12 and grapple.state != "pulling":
		facing = move.normalized()
	hp = minf(max_hp, hp+.55*count("mending")*dt)
	if stage == "waves": spawn_clock -= dt
	if stage == "waves" and spawn_clock <= 0:
		spawn_clock += maxf(.18, .88-time*.0036)
		var group = 1+int(time/55.0)
		for _i in range(group):
			spawn_enemy()
	_build_grid()
	for e in enemies:
		if not e.alive:
			continue
		if e.kind == 2:
			if towards_boss_body(e) and invulnerable <= 0:
				hurt_player(14,ground_vector(e.p-player).normalized())
			continue
		_guardian_step(e,dt)
		if phase != "playing": return
		e.route_clock -= dt
		if e.route_clock <= 0:
			e.route_clock = .18+float(e.id%3)*.025
			e.waypoint = Geometry.waypoint(e.p,player,7.0 if e.kind == 0 else 9.0)
		var towards = ground_vector(player-e.p)
		var waypoint = e.waypoint if ground_vector(e.waypoint-e.p).length() > 4 else player
		var direction = ground_vector(waypoint-e.p).normalized()
		direction.y *= .72
		var separation = Vector2.ZERO
		var nearby = _near(e.p)
		for other in nearby:
			if other.id == e.id or not other.alive:
				continue
			var diff = e.p-other.p
			var distance_squared = diff.length_squared()
			if distance_squared > .1 and distance_squared < 110:
				separation += diff.normalized()*(1.0-sqrt(distance_squared)/11.0)*28.0
		var suppression = .38 if ultimates.quench_left > 0 else 1.0
		var walking = 0.0 if e.get("windup",0.0) > 0 else e.speed*suppression
		e.p = Geometry.move_slide(e.p,(direction*walking+e.knock+separation.limit_length(28.0))*dt,7.0 if e.kind == 0 else 9.0,false).p
		e.knock = e.knock.move_toward(Vector2.ZERO, 180*dt)
		e.walk += dt*e.speed*.14
		e.direction = _direction(direction)
		if towards.length_squared() < (13 if e.kind == 0 else 16)**2 and invulnerable <= 0 and ultimates.quench_left <= 0:
			hurt_player(8.0 if e.kind == 0 else 13.0, direction)
			if phase != "playing":
				return
	boss.step(self,dt)
	if phase != "playing": return
	_build_grid()
	sword_clock -= dt
	skills.step(self,dt)
	if sword_clock <= 0:
		sword_clock += s.sword_interval
		sword_attack()
	fire_clock -= dt
	if fire_clock <= 0:
		fire_clock += 1.26
		fire_attack()
	for b in bullets:
		b.life -= dt
		var target = nearest(b.p, 95)
		if target != null:
			b.v = b.v.lerp((target.p-b.p).normalized()*164.0, dt*1.7).normalized()*164.0
		var next = b.p+b.v*dt
		var wall_hit = Geometry.first_wall(b.p+Vector2(0,10),next+Vector2(0,10),1.0)
		if wall_hit.hit:
			b.life = -1
			_spark(wall_hit.p-Vector2(0,10),[Color("7dc3ce"),Color("d2e5d3")],3,b.v.normalized(),.5)
			continue
		b.p = next
		b.trail_clock -= dt
		if b.trail_clock <= 0:
			b.trail_clock = .032
			b.trail.push_front(b.p)
			if b.trail.size() > 5: b.trail.pop_back()
		for e in _near(b.p):
			if not e.alive or b.hit.has(e.id): continue
			if ground_vector(b.p-e.p+Vector2(0,8)).length_squared() < (42 if e.kind == 2 else 16)**2:
				b.hit.append(e.id)
				_hurt_enemy(e,s.fire_damage,b.v.normalized(),"fire",false)
				fire_hits += 1
				b.remaining -= 1
				if b.remaining <= 0:
					b.life = -1
					break
	bullets = bullets.filter(func(b): return b.life > 0)
	enemies = enemies.filter(func(e): return e.alive)
	for soul in souls:
		soul.age += dt
		var diff = player-soul.p
		if ground_vector(diff).length() < s.pickup:
			soul.attract = true
		if soul.attract:
			soul.speed = minf(340,soul.speed+650*dt)
			soul.p = soul.p.move_toward(player, soul.speed*dt)
		if soul.p.distance_squared_to(player) < 8**2:
			xp += soul.value
			souls_taken += soul.value
			soul.dead = true
			_spark(player-Vector2(0,10), [Color("a6e5ea"), Color("478fae")], 3, Vector2.UP, .5)
			_sound("pickup")
	souls = souls.filter(func(soul): return not soul.dead)
	if stage == "waves" and time >= DURATION:
		begin_boss()
	elif xp >= xp_needed:
		level_up()
	peak_enemies = maxi(peak_enemies,enemies.size())

func _move_player(dt, s):
	var start = player
	var movement = Geometry.move_slide(player,velocity*dt)
	var finish = movement.p
	var direction = ground_vector(finish-start).normalized()
	var speed = ground_vector(velocity).length()
	var crossing = grapple.state in ["flying","pulling"] or (grapple.drift > 0 and speed > 100)
	var rush = crossing and speed > 100
	var contacts = []
	for e in enemies:
		if not e.alive: continue
		var radius = 13.0 if e.kind == 0 else (39.0 if e.kind == 2 else 16.0)
		# Existing overlap must never prevent moving away from a crowd.
		if ground_vector(start-e.p).length() <= radius and ground_vector(finish-start).dot(ground_vector(start-e.p)) >= 0: continue
		var t = Geometry.segment_circle(start,finish,e.p,radius)
		if t >= 0: contacts.append({"t":t,"enemy":e})
	contacts.sort_custom(func(a,b): return a.t < b.t)
	for contact in contacts:
		var e = contact.enemy
		if rush and not grapple.hit_ids.has(e.id):
			grapple.hit_ids.append(e.id)
			grapple.rush_hits += 1
			if grapple.burst_left > 0:
				grapple.strike_enemy(self,e,direction)
			else:
				_hurt_enemy(e,s.sword_damage*1.20,direction,"sword",true)
				sword_hits += 1
			if slashes.size() < 12:
				slashes.append({"p":start.lerp(finish,contact.t),"angle":direction.angle(),"radius":minf(s.reach,35),"life":.16,"total":.16})
			_sound("slash")
			invulnerable = maxf(invulnerable,.16)
		if crossing and e.kind == 0:
			# The crowd still damages a stopped player, but cannot stop a chain dash.
			invulnerable = maxf(invulnerable,.10)
			continue
		if e.alive:
			finish = start.lerp(finish,maxf(0,contact.t-.002))
			velocity *= .18
			if grapple.state == "pulling": grapple.release(self)
			break
	player = finish
	if crossing:
		grapple.strike_path(self,start,finish,speed)
		grapple.reward_path(self,start,finish,speed)
	if movement.blocked:
		var ground_velocity = ground_vector(velocity)
		for normal in movement.normals:
			var into = ground_velocity.dot(normal)
			if into < 0: ground_velocity -= normal*into
		velocity = Geometry.project(ground_velocity)
		if grapple.state == "pulling":
			_spark(player-Vector2(0,8),[Color("a1c5c5"),Color("d5bf8a")],4,facing,.6)
			grapple.release(self)

func _direction(direction):
	if absf(direction.x) > absf(direction.y):
		return 1 if direction.x >= 0 else 3
	return 0 if direction.y >= 0 else 2

func towards_boss_body(e):
	return ground_vector(player-e.p).length() < 39

func _guardian_step(e, dt):
	if e.kind != 1: return
	e.expose_left = maxf(0,e.expose_left-dt)
	var slow = .66 if ultimates.quench_left > 0 else 1.0
	if e.windup > 0:
		e.windup -= dt*slow
		if e.windup <= 0:
			var inside = ground_vector(player-e.attack_p).length() <= 59
			if not e.evade.is_empty() and e.evade.distance >= 30 and not inside and e.evade.damage == damage_events:
				grapple.charge_event(self,1,"鬼面の予告を鎖で回避")
				e.counter_ready = true
			if inside: hurt_player(16*(.5 if ultimates.quench_left > 0 else 1.0),ground_vector(player-e.attack_p).normalized(),true)
			e.expose_left = 2.8
			e.attack_clock = 4.0
			rings.append({"p":e.attack_p,"life":.3,"total":.3,"size":55.0,"color":Color("b47868")})
	else:
		e.attack_clock -= dt*slow
		if e.attack_clock <= 0 and ground_vector(player-e.p).length() < 95:
			e.windup = 1.0
			e.attack_p = e.p
			e.counter_ready = false
			e.evade = {}

func _build_grid():
	grid.clear()
	for e in enemies:
		if not e.alive: continue
		var cell = Vector2i(floori(e.p.x/24),floori(e.p.y/24))
		if not grid.has(cell): grid[cell] = []
		grid[cell].append(e)

func _near(point):
	var cell = Vector2i(floori(point.x/24),floori(point.y/24))
	var found = []
	for x in range(-1,2):
		for y in range(-1,2):
			found.append_array(grid.get(cell+Vector2i(x,y),[]))
	return found

func spawn_enemy(kind = -1, at = Vector2.INF):
	if enemies.size() >= MAX_ENEMIES:
		return null
	if kind < 0:
		kind = 1 if time > 18 and rng.randf() < minf(.37,.11+time*.0013) else 0
	if at == Vector2.INF:
		var side = rng.randi_range(0,3)
		if side == 0: at = Vector2(rng.randf_range(45,595),80)
		elif side == 1: at = Vector2(608,rng.randf_range(98,324))
		elif side == 2: at = Vector2(rng.randf_range(45,595),335)
		else: at = Vector2(32,rng.randf_range(98,324))
	var health = (23.0 if kind == 0 else 57.0)*(1.0+floorf(time/60)*.13)
	var e = {"id":next_id,"p":at,"kind":kind,"hp":health,"max_hp":health,"alive":true,
		"speed":rng.randf_range(29,38) if kind == 0 else rng.randf_range(20,26),
		"knock":Vector2.ZERO,"flash":0.0,"walk":rng.randf_range(0,8),"direction":0,"route_clock":0.0,"waypoint":player,"skill_until":{},
		"windup":0.0,"attack_clock":2.0+float(next_id%4)*.3,"attack_p":at,"expose_left":0.0,"counter_ready":false,"evade":{}}
	next_id += 1
	enemies.append(e)
	return e

func nearest(at, max_range):
	var best = null
	var distance = max_range*max_range
	for e in enemies:
		if not e.alive: continue
		var ds = ground_vector(e.p-at).length_squared()
		if ds < distance:
			distance = ds
			best = e
	return best

func sword_attack(multiplier = 1.0):
	var s = stats()
	var target = nearest(player,s.reach+22)
	var direction = ground_vector(target.p-player).normalized() if target != null else facing
	var angle = direction.angle()
	slashes.append({"p":player,"angle":angle,"radius":s.reach,"life":.19,"total":.19})
	_sound("slash")
	var finishers = 0
	for e in enemies:
		if not e.alive: continue
		var diff = ground_vector(e.p-player)
		if diff.length() > s.reach+8+(30 if e.kind == 2 else 0) or absf(angle_difference(angle,diff.angle())) > 1.02:
			continue
		if not Geometry.clear_line(player,e.p): continue
		var critical = rng.randf() < .08
		var damage = s.sword_damage*(1.8 if critical else 1.0)*multiplier
		if e.hp <= damage: finishers += 1
		_hurt_enemy(e,damage,diff.normalized(),"sword",critical)
		sword_hits += 1
	if finishers > 0:
		hitstop = .026 if finishers < 4 else .039
		shake = maxf(shake,.7 if finishers < 4 else 1.3)

func fire_attack():
	var s = stats()
	var targets = enemies.filter(func(e): return e.alive)
	targets.sort_custom(func(a,b): return a.p.distance_squared_to(player) < b.p.distance_squared_to(player))
	if targets.is_empty(): return
	for i in range(s.fire_count):
		var target = targets[mini(i,targets.size()-1)]
		var direction = (target.p-player).normalized().rotated((i-(s.fire_count-1)*.5)*.035)
		if bullets.size() >= 24: break
		bullets.append({"p":player-Vector2(0,10),"v":direction*164.0,"life":2.2,"remaining":1+s.pierce,"hit":[],"trail":[],"trail_clock":0.0})
	_sound("fire")

func _hurt_enemy(e, damage, direction, source, strong):
	if not e.alive: return
	if e.kind == 2:
		damage *= boss.damage_scale(self)
		boss.damage_taken += minf(e.hp,damage)
	elif ultimates.fracture_left > 0:
		damage *= 1.35
	e.hp -= damage
	e.flash = .068
	e.knock = direction*(90.0 if e.kind == 0 else (0.0 if e.kind == 2 else 58.0))
	_spark(e.p-Vector2(0,13), [Color("ece5ce"),Color("c9a572")] if source == "sword" else [Color("c5f4ee"),Color("65b8d0")], 4 if source == "sword" else 5,direction,1.0)
	if numbers.size() < 32:
		numbers.append({"p":e.p-Vector2(0,26),"text":str(roundi(damage)),"life":.48,"strong":strong})
	if e.hp > 0: return
	e.hp = 0
	e.alive = false
	kills += 1
	if e.kind == 2:
		boss.defeated(self)
		return
	var force = 2.0 if strong or damage >= e.max_hp*1.35 else 1.0
	if force > 1: heavy_shatters += 1
	var colors = [Color("ae906b"),Color("815449"),Color("3d2d39"),Color("c3a57b")] if e.kind == 0 else [Color("afa89d"),Color("6e6178"),Color("44435c"),Color("b4936b")]
	_spark(e.p-Vector2(0,13), colors, 15 if e.kind == 0 else 24,direction,force,true)
	if stains.size() < 85:
		stains.append({"p":e.p,"kind":e.kind,"seed":rng.randi_range(0,100)})
	drop_soul(e.p,1 if e.kind == 0 else 3)
	_sound("shatter")

func drop_soul(at, value):
	# Merge nearby old souls when the cap is reached; XP is never discarded.
	if souls.size() >= MAX_SOULS:
		souls[0].value += value
	else:
		souls.append({"p":at,"value":value,"attract":false,"speed":45.0,"dead":false,"age":0.0})

func _spark(at, colors, amount, direction, force, body = false):
	for i in range(amount):
		if particles.size() >= MAX_PARTICLES: break
		var angle = rng.randf_range(-PI,PI)
		var spread = Vector2.from_angle(angle)*rng.randf_range(18,60)*force
		if body: spread += direction*36.0*force
		var life = rng.randf_range(.23,.55) if body else rng.randf_range(.09,.22)
		particles.append({"p":at+Vector2(rng.randf_range(-7,7),rng.randf_range(-8,7)),"v":spread,"life":life,"total":life,
			"color":colors[i%colors.size()],"size":rng.randi_range(1,3) if body else 1,"body":body})
	peak_particles = maxi(peak_particles,particles.size())

func tick_visual(dt):
	visual_time += dt
	grapple.tick_visual(dt)
	skills.tick_visual(dt)
	boss.tick_visual(dt)
	ultimates.tick_visual(dt)
	shake = maxf(0,shake-8*dt)
	for e in enemies:
		e.flash = maxf(0,e.flash-dt)
	for p in particles:
		p.life -= dt
		p.p += p.v*dt
		p.v = p.v.move_toward(Vector2.ZERO,45.0*dt)
		if p.body: p.v.y += 55*dt
	particles = particles.filter(func(p): return p.life > 0)
	for slash in slashes: slash.life -= dt
	slashes = slashes.filter(func(slash): return slash.life > 0)
	for ring in rings: ring.life -= dt
	rings = rings.filter(func(ring): return ring.life > 0)
	for n in numbers:
		n.life -= dt
		n.p.y -= 15*dt
	numbers = numbers.filter(func(n): return n.life > 0)
	if phase == "dying":
		death_clock -= dt
		if death_clock <= 0: phase = "lost"

func hurt_player(damage, direction, telegraphed = false):
	if phase != "playing": return
	# Brief crowd-contact protection is NOT protection against marked boss attacks.
	if (hurt_cooldown > 0 if telegraphed else invulnerable > 0): return
	grapple.break_energy(self)
	damage_events += 1
	hp = maxf(0,hp-damage)
	invulnerable = .78
	hurt_cooldown = .78
	player = Geometry.move_slide(player,-Vector2(direction.x,direction.y*.72)*7).p
	shake = 1.2
	_sound("hurt")
	if hp > 0: return
	phase = "dying"
	grapple.cancel(self)
	death_clock = 1.15
	velocity = Vector2.ZERO
	_spark(player-Vector2(0,13),[Color("d9bc82"),Color("78becd"),Color("314763"),Color("e5dfc6")],38,Vector2.UP,2.4,true)
	rings.append({"p":player,"life":.45,"total":.45,"size":40.0,"color":Color("b06a66")})
	_sound("death")

func level_up():
	xp -= xp_needed
	level += 1
	xp_needed = 9+level*5
	hp = minf(max_hp,hp+8)
	phase = "upgrade"
	grapple.cancel(self)
	offers = []
	var pool = []
	for upgrade in UPGRADES:
		if count(upgrade.id) < upgrade.max: pool.append(upgrade.id)
	# Show the new attack patterns early, rather than hiding them in stat cards.
	var arts = pool.filter(func(id): return Arts.IDS.has(id))
	var art_slots = mini(3 if level == 2 else 2,arts.size())
	for i in range(art_slots):
		var index = rng.randi_range(0,arts.size()-1)
		var id = arts[index]
		offers.append(id)
		arts.remove_at(index)
		pool.erase(id)
	# Three different offers; capped upgrades are never offered again.
	for i in range(mini(3-offers.size(),pool.size())):
		var index = rng.randi_range(0,pool.size()-1)
		offers.append(pool[index])
		pool.remove_at(index)
	if offers.is_empty():
		hp = max_hp
		phase = "playing"
	rings.append({"p":player,"life":.48,"total":.48,"size":41.0,"color":Color("c3e4de")})
	_spark(player-Vector2(0,17),[Color("dbefd9"),Color("79c3cb"),Color("c2a26a")],18,Vector2.UP,.8)
	_sound("level")

func choose(id):
	if phase != "upgrade" or not offers.has(id): return false
	upgrades[id] = count(id)+1
	if id == "ward":
		max_hp += 20
		hp = minf(max_hp,hp+28)
	offers.clear()
	phase = "playing"
	return true

func get_upgrade(id):
	for upgrade in UPGRADES:
		if upgrade.id == id: return upgrade
	return {}
