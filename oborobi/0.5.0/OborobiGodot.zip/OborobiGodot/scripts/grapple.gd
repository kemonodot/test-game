extends RefCounted
## One chain. No rigid-body rope simulation or per-link scene nodes.
const Geometry = preload("res://scripts/arena_geometry.gd")
const RANGE = 620.0
const SPEED = 510.0
const SHOT_SPEED = 2100.0
const ASSIST_ANGLE = .32
const ENERGY_MAX = 3
const ENERGY_HOLD = 7.0
const GRAZE_SPEED = 180.0
const GRAZE_RADIUS = 24.0
const BURST_DURATION = .70
const BURST_RADIUS = 32.0
const BURST_DAMAGE = 90.0

var state = "idle"
var target = {}
var tip = Vector2.ZERO
var preview = {}
var aiming = false
var aim_direction = Vector2.RIGHT
var flight = 0.0
var clock = 0.0
var cooldown = 0.0
var drift = 0.0
var trail = []
var trail_clock = 0.0
var hit_ids = []
var shots = 0
var catches = 0
var enemy_catches = 0
var wall_catches = 0
var rush_hits = 0
var releases = 0
var flow = 0
var flow_grace = 0.0
var best_flow = 0
var energy = 0
var energy_left = 0.0
var burst_left = 0.0
var burst_hits = []
var cuts = []
var near_passes = 0
var arrival_rewards = 0
var bursts = 0
var energy_lost = 0
var ready_flash = 0.0
var loss_flash = 0.0
var loss_reason = ""
var gain_reason = ""

func can_anchor(enemy):
	return enemy.alive and enemy.kind == 1 and Geometry.FLOOR.has_point(enemy.p)

func acquire(run, direction):
	var forward = direction.normalized()
	var finish = run.player+Geometry.project(forward*RANGE)
	var wall = Geometry.first_wall(run.player,finish)
	var selection = {"kind":"wall" if wall.hit else "miss","p":wall.p,"enemy":null,"wall":wall.wall}
	var best_score = INF
	for enemy in run.enemies:
		if not can_anchor(enemy): continue
		var diff = Geometry.ground(enemy.p-run.player)
		var distance = diff.length()
		if distance < 23 or distance > RANGE: continue
		var angle = absf(angle_difference(forward.angle(),diff.angle()))
		if angle > ASSIST_ANGLE: continue
		var obstruction = Geometry.first_wall(run.player,enemy.p)
		if obstruction.hit and obstruction.t < .995: continue
		var score = angle*330+distance*.15
		if score < best_score:
			best_score = score
			selection = {"kind":"enemy","p":enemy.p,"enemy":enemy,"wall":-1}
	if run.boss.active():
		for anchor in run.boss.anchors:
			var diff = Geometry.ground(anchor.p-run.player)
			var distance = diff.length()
			if distance < 22 or distance > RANGE: continue
			var angle = absf(angle_difference(forward.angle(),diff.angle()))
			if angle > ASSIST_ANGLE: continue
			if not Geometry.clear_line(run.player,anchor.p): continue
			var score = angle*330+distance*.15-(8 if run.boss.is_open(anchor.id,run) else 0)
			if score < best_score:
				best_score = score
				selection = {"kind":"boss","p":anchor.p,"enemy":run.boss.actor,"anchor":anchor,"wall":-1}
	# Small enemies never catch or interrupt the chain.
	var closest = 1.01
	var shot_end = selection.p
	for enemy in run.enemies:
		if not can_anchor(enemy): continue
		if Geometry.ground(enemy.p-run.player).dot(Geometry.ground(shot_end-run.player)) <= 0: continue
		var t = Geometry.segment_circle(run.player,shot_end,enemy.p,8.0 if enemy.kind == 0 else 10.0)
		if t >= 0 and t < closest:
			closest = t
			selection = {"kind":"enemy","p":enemy.p,"enemy":enemy,"wall":-1}
	return selection

func set_aim(run, direction):
	aiming = true
	aim_direction = direction.normalized()
	preview = acquire(run,aim_direction)

func fire(run, direction):
	if run.phase != "playing" or cooldown > 0: return false
	if state != "idle": release(run)
	target = acquire(run,direction)
	tip = run.player
	flight = 0
	clock = 0
	state = "flying"
	cooldown = .055
	drift = .65
	hit_ids.clear()
	shots += 1
	run.facing = Geometry.ground(target.p-run.player).normalized()
	run.boss.begin_evade(run)
	for enemy in run.enemies:
		if enemy.kind == 1 and enemy.get("windup",0.0) > 0 and enemy.evade.is_empty() and Geometry.ground(run.player-enemy.attack_p).length() <= 59:
			enemy.evade = {"damage":run.damage_events,"distance":0.0}
	run._sound("chain_throw")
	return true

func release(run, preserve_velocity = true):
	if state != "idle": releases += 1
	state = "idle"
	target = {}
	drift = .62 if preserve_velocity else 0.0
	if not preserve_velocity: run.velocity = Vector2.ZERO

func cancel(run):
	aiming = false
	preview = {}
	release(run,false)
	trail.clear()
	flow = 0
	flow_grace = 0
	burst_left = 0
	# Pausing or choosing an upgrade preserves earned energy and its timer.
	if run.phase in ["dying","lost","won"]:
		energy = 0
		energy_left = 0

func charge(run, enemy, arrival = false):
	# Arrival only counts after THIS guardian's marked attack was chain-dodged.
	if not arrival or not can_anchor(enemy) or not enemy.get("counter_ready",false) or enemy.get("expose_left",0.0) <= 0: return false
	enemy.counter_ready = false
	return charge_event(run,2,"返し鎖が成功")

func charge_event(run, amount, reason):
	if run.phase != "playing" or burst_left > 0 or energy >= ENERGY_MAX: return false
	energy = mini(ENERGY_MAX,energy+amount)
	energy_left = ENERGY_HOLD
	loss_flash = 0
	gain_reason = reason
	if amount == 2: arrival_rewards += 1
	else: near_passes += 1
	run._spark(run.player-Vector2(0,13),[Color("e9c486"),Color("a57650")],4,run.facing,.6)
	if energy == ENERGY_MAX:
		ready_flash = .6
		run._sound("chain_ready")
	return true

func break_energy(run, reason = "被弾で消失"):
	if energy > 0 or burst_left > 0:
		energy_lost += energy
		loss_reason = reason
		loss_flash = .75
		run._spark(run.player-Vector2(0,12),[Color("b46a64"),Color("c79a68")],6,Vector2.UP,.65)
	energy = 0
	energy_left = 0
	burst_left = 0
	ready_flash = 0
	flow = 0
	flow_grace = 0

func reward_path(run, start, finish, speed):
	# Proximity to enemies is deliberately irrelevant, including dense swarms.
	if speed < 100 or start.distance_squared_to(finish) < .01: return
	run.boss.observe_path(start,finish)
	for enemy in run.enemies:
		if enemy.alive and enemy.kind == 1 and enemy.get("windup",0.0) > 0 and not enemy.evade.is_empty():
			enemy.evade.distance += Geometry.ground(finish-start).length()

func strike_enemy(run, enemy, direction):
	if burst_hits.has(enemy.id): return
	burst_hits.append(enemy.id)
	run._hurt_enemy(enemy,240.0 if enemy.kind == 2 else BURST_DAMAGE,direction,"chain" if enemy.kind == 2 else "sword",true)
	run.sword_hits += 1

func strike_path(run, start, finish, speed):
	if burst_left <= 0 or speed < 100 or start.distance_squared_to(finish) < .01: return
	var direction = Geometry.ground(finish-start).normalized()
	cuts.append({"a":start,"b":finish,"life":.26,"total":.26})
	if cuts.size() > 24: cuts.pop_front()
	for enemy in run.enemies:
		if not enemy.alive or burst_hits.has(enemy.id): continue
		var t = Geometry.segment_circle(start,finish,enemy.p,BURST_RADIUS+(30 if enemy.kind == 2 else 0))
		if t >= 0 and not Geometry.first_wall(start.lerp(finish,t),enemy.p).hit:
			strike_enemy(run,enemy,direction)

func tick_visual(dt):
	ready_flash = maxf(0,ready_flash-dt)
	loss_flash = maxf(0,loss_flash-dt)
	for cut in cuts: cut.life -= dt
	cuts = cuts.filter(func(cut): return cut.life > 0)

func advance(run, dt, movement):
	burst_left = maxf(0,burst_left-dt)
	if energy > 0:
		energy_left = maxf(0,energy_left-dt)
		if energy_left <= 0: break_energy(run,"鎖が途切れた")
	cooldown = maxf(0,cooldown-dt)
	drift = maxf(0,drift-dt)
	flow_grace = maxf(0,flow_grace-dt)
	if flow_grace <= 0: flow = 0
	clock += dt
	if aiming: preview = acquire(run,aim_direction)
	if state in ["flying","pulling"]:
		if target.kind in ["enemy","boss"]:
			if not target.enemy.alive:
				release(run)
			else:
				target.p = target.anchor.p if target.kind == "boss" else target.enemy.p
		var obstruction = Geometry.first_wall(run.player,target.p) if state != "idle" else {}
		if state != "idle" and obstruction.hit and obstruction.t < .995:
			# A moving anchor crossed behind masonry. Never pull through the wall.
			release(run)
	if state == "flying":
		var old_tip = tip
		flight += SHOT_SPEED*dt
		var offset = Geometry.ground(target.p-run.player)
		tip = run.player+Geometry.project(offset.normalized()*minf(offset.length(),flight))
		var wall = Geometry.first_wall(old_tip,tip)
		var closest = wall.t if wall.hit else 1.01
		var intercepted = null
		var intercepted_anchor = null
		for enemy in run.enemies:
			if not can_anchor(enemy): continue
			var t = Geometry.segment_circle(old_tip,tip,enemy.p,8.0 if enemy.kind == 0 else 10.0)
			if t >= 0 and t <= closest:
				closest = t
				intercepted = enemy
		if run.boss.active():
			for anchor in run.boss.anchors:
				var t = Geometry.segment_circle(old_tip,tip,anchor.p,7.0)
				if t >= 0 and t < closest:
					closest = t
					intercepted_anchor = anchor
					intercepted = null
		if intercepted_anchor != null:
			target = {"kind":"boss","p":intercepted_anchor.p,"enemy":run.boss.actor,"anchor":intercepted_anchor,"wall":-1}
			_attach(run,offset.normalized())
		elif intercepted != null:
			target = {"kind":"enemy","p":intercepted.p,"enemy":intercepted,"wall":-1}
			_attach(run,offset.normalized())
		elif wall.hit:
			target = {"kind":"wall","p":wall.p,"enemy":null,"wall":wall.wall}
			_attach(run,offset.normalized())
		elif flight >= offset.length():
			if target.kind == "miss": release(run)
			else: _attach(run,offset.normalized())
	if state == "pulling":
		tip = target.p
		var diff = Geometry.ground(target.p-run.player)
		var stop = 27.0 if target.kind == "enemy" else (21.0 if target.kind == "boss" else 10.0)
		if diff.length() <= stop+3 or clock > 2.2:
			if target.kind == "enemy":
				if diff.length() <= stop+3: charge(run,target.enemy,true)
				run.facing = diff.normalized()
				run.sword_attack(1.35)
				run.sword_clock = run.stats().sword_interval
				run.invulnerable = maxf(run.invulnerable,.16)
			elif target.kind == "boss" and diff.length() <= stop+3:
				run.boss.chain_arrival(run,target.anchor)
			run.velocity *= .65
			release(run)
		else:
			var maximum = SPEED*(1+.07*run.count("stride"))*(1.7 if run.ultimates.haste_left > 0 else 1.0)
			var braking = 4200.0 if run.ultimates.haste_left > 0 else 1600.0
			var speed = minf(maximum,maxf(110,sqrt(2*braking*maxf(0,diff.length()-stop))))
			var velocity = Geometry.ground(run.velocity).move_toward(diff.normalized()*speed,(4100 if run.ultimates.haste_left > 0 else 2700)*dt)
			run.velocity = Geometry.project(velocity)
			run.facing = diff.normalized()
	if state != "pulling":
		var desired = movement.limit_length()*run.stats().speed
		var slowing = 150.0 if state == "flying" else (310.0 if run.ultimates.haste_left > 0 and drift > 0 else (520.0 if drift > 0 else 640.0))
		run.velocity = Geometry.project(Geometry.ground(run.velocity).move_toward(desired,slowing*dt))
	trail_clock -= dt
	if Geometry.ground(run.velocity).length() > 145 and trail_clock <= 0:
		trail_clock = .025
		trail.append({"p":run.player,"life":.20,"direction":run.facing})
		if trail.size() > 9: trail.pop_front()
	for point in trail: point.life -= dt
	trail = trail.filter(func(point): return point.life > 0)

func _attach(run, direction):
	state = "pulling"
	clock = 0
	tip = target.p
	catches += 1
	flow = mini(6,flow+1) if flow_grace > 0 else 1
	flow_grace = 1.35
	best_flow = maxi(best_flow,flow)
	if energy >= ENERGY_MAX:
		energy = 0
		energy_left = 0
		burst_left = BURST_DURATION
		burst_hits.clear()
		bursts += 1
		ready_flash = 0
		run._sound("chain_burst")
		run._spark(run.player-Vector2(0,12),[Color("ffe1a0"),Color("f9efcf"),Color("b7885c")],12,direction,1.2)
	elif energy > 0:
		energy_left = ENERGY_HOLD
	if target.kind in ["enemy","boss"]: enemy_catches += 1
	else: wall_catches += 1
	run._sound("chain_lock")
	run._spark(target.p-Vector2(0,10),[Color("eef0d9"),Color("83cdd9")],7,direction,.7)
