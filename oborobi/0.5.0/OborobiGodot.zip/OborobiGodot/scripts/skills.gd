extends RefCounted
## New attacks, not stat multipliers. All effects share one Canvas renderer.
const Geometry = preload("res://scripts/arena_geometry.gd")
const IDS = ["cinder_trail","chain_lightning","orbit_blades","petal_wave"]
const MAX_BURNS = 28
const MAX_EFFECTS = 18

var burns = []
var effects = []
var orbit_angle = 0.0
var previous_blades = []
var trail_clock = 0.0
var burn_clock = 0.0
var lightning_clock = .25
var petal_clock = .35
var hits = {"cinder_trail":0,"chain_lightning":0,"orbit_blades":0,"petal_wave":0}
var casts = {"cinder_trail":0,"chain_lightning":0,"orbit_blades":0,"petal_wave":0}
var serial = 0

func active_count(run):
	var amount = 0
	for id in IDS:
		if run.count(id) > 0: amount += 1
	return amount

func blade_positions(run):
	var points = []
	for i in range(3):
		points.append(run.player+Geometry.project(Vector2.from_angle(orbit_angle+i*TAU/3)*40))
	return points

func _effect(effect):
	if effects.size() >= MAX_EFFECTS: effects.pop_front()
	effects.append(effect)

func _visible_target(run, at, distance, used):
	var target = null
	var closest = distance*distance
	for enemy in run.enemies:
		if not enemy.alive or used.has(enemy.id): continue
		var ds = Geometry.ground(enemy.p-at).length_squared()
		if ds < closest and Geometry.clear_line(at,enemy.p):
			closest = ds
			target = enemy
	return target

func _damage(run, enemy, amount, id, origin):
	var direction = Geometry.ground(enemy.p-origin).normalized()
	run._hurt_enemy(enemy,amount,direction,"sword" if id == "orbit_blades" or id == "petal_wave" else "fire",false)
	hits[id] += 1

func lightning(run):
	var points = [run.player]
	var used = []
	var origin = run.player
	for i in range(3):
		var enemy = _visible_target(run,origin,145 if i == 0 else 85,used)
		if enemy == null: break
		used.append(enemy.id)
		points.append(enemy.p)
		_damage(run,enemy,22,"chain_lightning",origin)
		origin = enemy.p
	if points.size() > 1:
		serial += 1
		_effect({"kind":"lightning","points":points,"life":.24,"total":.24,"seed":serial})
		casts.chain_lightning += 1
		run._sound("fire")

func petals(run):
	serial += 1
	_effect({"kind":"petals","p":run.player,"life":.56,"total":.56,"hit":[],"seed":serial})
	casts.petal_wave += 1
	run._sound("slash")

func step(run, dt):
	if run.phase != "playing": return
	if run.count("cinder_trail") > 0:
		trail_clock -= dt
		if Geometry.ground(run.velocity).length() > 145 and trail_clock <= 0:
			trail_clock = .035
			serial += 1
			if burns.size() >= MAX_BURNS: burns.pop_front()
			burns.append({"p":run.player,"life":.78,"total":.78,"seed":serial})
			casts.cinder_trail += 1
		burn_clock -= dt
		if burn_clock <= 0:
			burn_clock = .12
			for enemy in run.enemies:
				if not enemy.alive or enemy.skill_until.get("burn",-1.0) > run.time: continue
				for burn in burns:
					var radius = 47 if enemy.kind == 2 else 17
					if Geometry.ground(burn.p-enemy.p).length_squared() < radius*radius and Geometry.clear_line(burn.p,enemy.p):
						enemy.skill_until.burn = run.time+.18
						_damage(run,enemy,8,"cinder_trail",burn.p)
						break
	if run.count("chain_lightning") > 0:
		lightning_clock -= dt
		if lightning_clock <= 0:
			lightning_clock = 1.25
			lightning(run)
	if run.count("orbit_blades") > 0:
		orbit_angle = fmod(orbit_angle+dt*3.7,TAU)
		var points = blade_positions(run)
		if previous_blades.is_empty(): previous_blades = points.duplicate()
		for enemy in run.enemies:
			if not enemy.alive or enemy.skill_until.get("orbit",-1.0) > run.time: continue
			if not Geometry.clear_line(run.player,enemy.p): continue
			for i in range(3):
				if Geometry.segment_circle(previous_blades[i],points[i],enemy.p,43 if enemy.kind == 2 else 13) >= 0:
					enemy.skill_until.orbit = run.time+.48
					_damage(run,enemy,19,"orbit_blades",run.player)
					casts.orbit_blades += 1
					break
		previous_blades = points
	if run.count("petal_wave") > 0:
		petal_clock -= dt
		if petal_clock <= 0:
			petal_clock = 2.5
			petals(run)
	for effect in effects:
		if effect.kind != "petals": continue
		var radius = 12+82*(1-effect.life/effect.total)
		for enemy in run.enemies:
			if not enemy.alive or effect.hit.has(enemy.id): continue
			if Geometry.ground(enemy.p-effect.p).length() <= radius+6+(30 if enemy.kind == 2 else 0) and Geometry.clear_line(effect.p,enemy.p):
				effect.hit.append(enemy.id)
				_damage(run,enemy,31,"petal_wave",effect.p)

func tick_visual(dt):
	for burn in burns: burn.life -= dt
	burns = burns.filter(func(burn): return burn.life > 0)
	for effect in effects: effect.life -= dt
	effects = effects.filter(func(effect): return effect.life > 0)
