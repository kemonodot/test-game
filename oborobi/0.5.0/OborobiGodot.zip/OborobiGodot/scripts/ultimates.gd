extends RefCounted
## Manual, independent cooldowns. Every art has a different tactical purpose.
const IDS = ["chain","flame","blade"]
const COOLDOWNS = {"chain":20.0,"flame":26.0,"blade":30.0}
const NAMES = {"chain":"天鎖解放","flame":"蒼炎還魂","blade":"天断ち"}
const Geometry = preload("res://scripts/arena_geometry.gd")

var cooldown = {"chain":0.0,"flame":0.0,"blade":0.0}
var casts = {"chain":0,"flame":0,"blade":0}
var haste_left = 0.0
var quench_left = 0.0
var fracture_left = 0.0
var effects = []
var burn_clock = 0.0
var healed = 0.0

func cast(run, id):
	if run.phase != "playing" or not IDS.has(id) or cooldown[id] > 0: return false
	if run.boss.state == "defeated": return false
	cooldown[id] = COOLDOWNS[id]
	casts[id] += 1
	if id == "chain":
		haste_left = 5.0
		run.grapple.cooldown = 0
		run._sound("ultimate_chain")
	elif id == "flame":
		quench_left = 5.0
		burn_clock = .4
		var before = run.hp
		run.hp = minf(run.max_hp,run.hp+28)
		healed += run.hp-before
		run._sound("ultimate_flame")
	else:
		fracture_left = 5.0
		run._sound("ultimate_blade")
	var targets = []
	# Screen-wide rites intentionally cross the two short masonry obstacles.
	for enemy in run.enemies:
		if not enemy.alive: continue
		targets.append(enemy.p)
		var amount = {"chain":85.0,"flame":100.0,"blade":200.0}[id]
		if id == "blade" and enemy.kind == 2: amount = 650.0
		run._hurt_enemy(enemy,amount,Geometry.ground(enemy.p-run.player).normalized(),"ultimate",true)
	if effects.size() >= 3: effects.pop_front()
	effects.append({"kind":id,"p":run.player,"targets":targets.slice(0,18),"life":1.05,"total":1.05})
	run.shake = maxf(run.shake,.75)
	run.hitstop = maxf(run.hitstop,.032)
	return true

func step(run, dt):
	for id in IDS: cooldown[id] = maxf(0,cooldown[id]-dt)
	haste_left = maxf(0,haste_left-dt)
	quench_left = maxf(0,quench_left-dt)
	fracture_left = maxf(0,fracture_left-dt)
	if quench_left > 0:
		burn_clock -= dt
		if burn_clock <= 0:
			burn_clock += .4
			for enemy in run.enemies:
				if enemy.alive: run._hurt_enemy(enemy,12.0,Vector2.UP,"fire",false)

func tick_visual(dt):
	for effect in effects: effect.life -= dt
	effects = effects.filter(func(effect): return effect.life > 0)
