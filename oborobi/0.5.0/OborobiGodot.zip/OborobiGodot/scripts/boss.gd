extends RefCounted
## A single large body, three chain rings, and deliberately timed counter windows.
const Geometry = preload("res://scripts/arena_geometry.gd")
const HEALTH = 12000.0
const NAMES = ["薙ぎ払い", "鎖の貫き", "踏み砕き"]

var actor = {}
var anchors = []
var state = "absent"
var clock = 0.0
var attack_id = 0
var pattern = 0
var warning = {}
var evade = {}
var counter_ready = false
var counter_used = false
var open_anchor = 0
var death_left = 0.0
var summon_clock = 13.0
var impacts = []
var dodges = 0
var counters = 0
var chain_damage = 0.0
var damage_taken = 0.0
var enraged = false
var announcement = 0.0

func begin(run):
	if state != "absent": return
	actor = {"id":-1,"p":Vector2(324,213),"kind":2,"hp":HEALTH,"max_hp":HEALTH,"alive":true,
		"speed":0.0,"knock":Vector2.ZERO,"flash":0.0,"walk":0.0,"direction":0,"skill_until":{}}
	run.enemies.append(actor)
	for i in range(3):
		anchors.append({"id":i,"p":actor.p,"hit_at":-99.0})
	update_anchors()
	state = "rest"
	clock = 2.0
	announcement = 2.6
	run._sound("boss_warning")

func active():
	return not actor.is_empty() and actor.alive

func update_anchors():
	if actor.is_empty(): return
	var offsets = [Vector2(-65,0),Vector2(65,0),Vector2(0,47)]
	for i in range(anchors.size()): anchors[i].p = actor.p+offsets[i]

func is_open(index, run):
	return active() and ((state == "open" and index == open_anchor) or run.ultimates.fracture_left > 0)

func contains(point):
	if warning.is_empty() or not Geometry.FLOOR.has_point(point): return false
	var diff = Geometry.ground(point-warning.p)
	if warning.kind == "circle": return diff.length() <= warning.radius+5
	if warning.kind == "line":
		var along = diff.dot(warning.direction)
		return along >= -8 and along <= warning.radius+5 and absf(diff.cross(warning.direction)) <= warning.half+5
	return diff.length() <= warning.radius+5 and (diff.length() < 28 or absf(angle_difference(warning.direction.angle(),diff.angle())) <= warning.half+.035)

func windup(run):
	attack_id += 1
	pattern = (attack_id-1)%3
	# The opening is on the player's side of the large body. A short swipe can
	# reach it without demanding a precise detour through the giant's collider.
	open_anchor = 0 if run.player.x < actor.p.x-24 else (1 if run.player.x > actor.p.x+24 else 2)
	counter_ready = false
	counter_used = false
	evade = {}
	var direction = Geometry.ground(run.player-actor.p).normalized()
	if direction == Vector2.ZERO: direction = Vector2.DOWN
	if pattern == 0:
		warning = {"kind":"fan","p":actor.p,"direction":direction,"radius":210.0,"half":.77,"id":attack_id}
	elif pattern == 1:
		warning = {"kind":"line","p":actor.p,"direction":direction,"radius":450.0,"half":27.0,"id":attack_id}
	else:
		warning = {"kind":"circle","p":run.player,"direction":direction,"radius":82.0,"half":0.0,"id":attack_id}
	state = "windup"
	clock = .90 if enraged else 1.15
	run._sound("boss_warning")

func begin_evade(run):
	# The player must START a chain in the marked danger. Passing a crowd or
	# firing outside the warning grants nothing. Each attack produces one ticket.
	if state != "windup" or not contains(run.player) or not evade.is_empty(): return
	evade = {"id":attack_id,"damage":run.damage_events,"distance":0.0}

func observe_path(start, finish):
	if state == "windup" and not evade.is_empty():
		evade.distance += Geometry.ground(finish-start).length()

func impact(run):
	var inside = contains(run.player)
	if not evade.is_empty() and evade.id == attack_id and evade.distance >= 36 and not inside and evade.damage == run.damage_events:
		if run.grapple.charge_event(run,1,"予告攻撃を鎖で回避"):
			dodges += 1
		counter_ready = true
		# Reaching the lit ring during the following opening completes the wager.
	if inside:
		var damage = 24.0 if pattern == 2 else 20.0
		if run.ultimates.quench_left > 0: damage *= .5
		run.hurt_player(damage,warning.direction,true)
	impacts.append({"warning":warning.duplicate(),"life":.40,"total":.40})
	if impacts.size() > 3: impacts.pop_front()
	state = "open"
	clock = 2.8 if enraged else 3.2
	run.shake = maxf(run.shake,.8)
	run._sound("boss_impact")

func chain_arrival(run, anchor):
	if not active() or run.time-anchor.hit_at < .75: return
	anchor.hit_at = run.time
	var opened = is_open(anchor.id,run)
	var damage = 200.0 if opened else 70.0
	if opened and state == "open" and anchor.id == open_anchor and counter_ready and not counter_used:
		counter_used = true
		counter_ready = false
		counters += 1
		damage += 100.0
		run.grapple.charge_event(run,2,"返し鎖が成功")
		# A deliberate counter also grows the build; random proximity does not.
		run.drop_soul(anchor.p,3)
	var before = actor.hp
	run._hurt_enemy(actor,damage,Geometry.ground(actor.p-run.player).normalized(),"chain",true)
	chain_damage += maxf(0,before-actor.hp)
	run.rings.append({"p":anchor.p,"life":.32,"total":.32,"size":34.0,"color":Color("f4c885") if opened else Color("81bac7")})
	run._sound("chain_burst" if opened else "chain_lock")
	run.invulnerable = maxf(run.invulnerable,.16)

func damage_scale(run):
	if run.ultimates.fracture_left > 0: return 1.35
	return 1.0 if state == "open" else .24

func defeated(run):
	state = "defeated"
	death_left = 1.3
	warning = {}
	evade = {}
	counter_ready = false
	run.grapple.release(run)
	for enemy in run.enemies:
		if enemy.kind != 2: enemy.alive = false
	run.bullets.clear()
	run._spark(actor.p-Vector2(0,54),[Color("c7b68e"),Color("936859"),Color("6a4554"),Color("64bacc")],80,Vector2.UP,2.5,true)
	run.rings.append({"p":actor.p,"life":1.0,"total":1.0,"size":190.0,"color":Color("d8c58e")})
	run.shake = 1.4
	run._sound("boss_impact")

func step(run, dt):
	if state == "absent": return
	if state == "defeated":
		death_left -= dt
		if death_left <= 0:
			run.phase = "won"
			run.grapple.cancel(run)
		return
	if not active(): return
	enraged = actor.hp <= actor.max_hp*.5
	update_anchors()
	# Flame creates breathing room by slowing the actual attack countdown.
	clock -= dt*(.66 if run.ultimates.quench_left > 0 and state in ["rest","windup"] else 1.0)
	if clock <= 0:
		if state == "rest": windup(run)
		elif state == "windup": impact(run)
		elif state == "open":
			state = "rest"
			clock = .70 if enraged else 1.05
			warning = {}
			counter_ready = false
			evade = {}
	summon_clock -= dt
	if summon_clock <= 0:
		summon_clock = 13.0 if enraged else 18.0
		var minors = run.enemies.filter(func(e): return e.alive and e.kind != 2).size()
		for i in range(mini(4,8-minors)):
			run.spawn_enemy(0,Vector2(85 if i%2 else 558,110+i*53))

func tick_visual(dt):
	announcement = maxf(0,announcement-dt)
	for effect in impacts: effect.life -= dt
	impacts = impacts.filter(func(effect): return effect.life > 0)
