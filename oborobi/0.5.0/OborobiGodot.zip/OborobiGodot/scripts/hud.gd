extends Control

const FONT = preload("res://assets/fonts/OborobiUI.otf")
const FIRE = preload("res://assets/art/soul_fire.png")
const RONIN = preload("res://assets/art/ronin.png")
const GOLD = Color("d1b78a")
const WHITE = Color("e1e0d7")
const MUTED = Color("93999e")
const BLUE = Color("8ac2d0")

var driver
var run
var modal: Control
var hp_text: Label
var timer_text: Label
var kills_text: Label
var level_text: Label
var weapon_text: Label
var xp_text: Label
var chapter_text: Label
var chain_text: Label
var arts_text: Label
var energy_text: Label
var boss_text: Label
var pause_button: Button
var sound_button: Button
var choice_buttons = []
var current_panel = ""
var ultimate_buttons = {}
var ultimate_notes = {}
const ULT_RECTS = {"chain":Rect2(765,571,151,110),"flame":Rect2(926,571,151,110),"blade":Rect2(1087,571,151,110)}

func setup(owner_game):
	driver = owner_game
	run = driver.run
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme_asset = Theme.new()
	theme_asset.default_font = FONT
	theme_asset.default_font_size = 22
	theme = theme_asset
	hp_text = label("100 / 100",20,Rect2(350,25,160,32),WHITE)
	timer_text = label("03:00",34,Rect2(540,18,200,50),GOLD,HORIZONTAL_ALIGNMENT_CENTER)
	kills_text = label("討伐  000",19,Rect2(969,56,190,32),WHITE,HORIZONTAL_ALIGNMENT_RIGHT)
	level_text = label("Lv. 1",26,Rect2(999,18,160,38),GOLD,HORIZONTAL_ALIGNMENT_RIGHT)
	weapon_text = label("一閃 I     魂火 I",17,Rect2(94,57,350,30),BLUE)
	xp_text = label("灯  0 / 9",17,Rect2(1010,670,230,30),MUTED,HORIZONTAL_ALIGNMENT_RIGHT)
	chapter_text = label("第一刻 / 影が集う",16,Rect2(470,70,340,32),MUTED,HORIZONTAL_ALIGNMENT_CENTER)
	chain_text = label("スワイプで鎖移動 / タップで解除",17,Rect2(22,622,720,34),BLUE)
	arts_text = label("術：未修得",16,Rect2(22,658,300,34),GOLD)
	energy_text = label("予告を鎖で避ける → 金の環へ",17,Rect2(95,99,408,28),GOLD)
	boss_text = label("骸 綱 / 鎖を喰らう鬼",24,Rect2(527,18,455,35),GOLD,HORIZONTAL_ALIGNMENT_CENTER)
	boss_text.hide()
	for id in ["chain","flame","blade"]:
		var control = button("",ULT_RECTS[id],driver.cast_ultimate.bind(id))
		control.add_theme_font_size_override("font_size",22)
		var accent = GOLD if id == "chain" else (BLUE if id == "flame" else WHITE)
		control.add_theme_stylebox_override("normal",style(Color("151d29"),accent))
		control.add_theme_stylebox_override("disabled",style(Color("111923"),Color("4d5560")))
		control.add_theme_color_override("font_disabled_color",MUTED)
		control.set_meta("ultimate_id",id)
		ultimate_buttons[id] = control
		ultimate_notes[id] = label("",16,Rect2(6,72,139,28),BLUE,HORIZONTAL_ALIGNMENT_CENTER,control)
		control.hide()
	pause_button = button("II",Rect2(1172,12,92,84),driver.toggle_pause)
	sound_button = button("音",Rect2(1172,106,92,74),driver.toggle_sound)
	var portrait = AtlasTexture.new()
	portrait.atlas = RONIN
	portrait.region = Rect2(0,0,32,32)
	var face = TextureRect.new()
	face.texture = portrait
	face.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	face.position = Vector2(22,19)
	face.size = Vector2(58,58)
	face.mouse_filter = MOUSE_FILTER_IGNORE
	add_child(face)
	modal = Control.new()
	modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal.mouse_filter = MOUSE_FILTER_IGNORE
	add_child(modal)
	show_intro()

func ultimate_at(point):
	if current_panel != "" or run.phase != "playing": return ""
	for id in ULT_RECTS:
		if ULT_RECTS[id].has_point(point): return id
	return ""

func style(fill, border):
	var box = StyleBoxFlat.new()
	box.bg_color = fill
	box.border_color = border
	box.set_border_width_all(1)
	box.content_margin_left = 16
	box.content_margin_right = 16
	box.content_margin_top = 8
	box.content_margin_bottom = 8
	return box

func label(text_value, font_size, rect, color = WHITE, align = HORIZONTAL_ALIGNMENT_LEFT, parent = null):
	var control = Label.new()
	control.text = text_value
	control.position = rect.position
	control.size = rect.size
	control.add_theme_font_size_override("font_size",font_size)
	control.add_theme_color_override("font_color",color)
	control.add_theme_color_override("font_outline_color",Color("101621"))
	control.add_theme_constant_override("outline_size",2)
	control.horizontal_alignment = align
	control.mouse_filter = MOUSE_FILTER_IGNORE
	(parent if parent != null else self).add_child(control)
	return control

func button(text_value, rect, callback, parent = null):
	var control = Button.new()
	control.text = text_value
	control.position = rect.position
	control.size = rect.size
	control.add_theme_stylebox_override("normal",style(Color("151d29"),Color("77654e")))
	control.add_theme_stylebox_override("hover",style(Color("25313e"),GOLD))
	control.add_theme_stylebox_override("pressed",style(Color("314353"),BLUE))
	control.add_theme_stylebox_override("focus",style(Color(0,0,0,0),BLUE))
	control.add_theme_color_override("font_color",WHITE)
	control.pressed.connect(callback)
	(parent if parent != null else self).add_child(control)
	return control

func panel(rect, color):
	var control = Panel.new()
	control.position = rect.position
	control.size = rect.size
	control.add_theme_stylebox_override("panel",style(color,Color("695b4d")))
	control.mouse_filter = MOUSE_FILTER_IGNORE
	modal.add_child(control)
	return control

func clear_panel():
	choice_buttons.clear()
	for child in modal.get_children():
		# A button can be clearing its own panel from inside a GUI signal. Keep
		# it in the tree until deferred deletion, so Godot can finish that event.
		child.hide()
		child.queue_free()
	current_panel = ""

func dim(opacity = .68):
	var shade = ColorRect.new()
	shade.color = Color(.025,.037,.062,opacity)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = MOUSE_FILTER_STOP
	modal.add_child(shade)

func show_intro():
	clear_panel()
	current_panel = "menu"
	panel(Rect2(74,190,453,386),Color(.045,.069,.107,.94))
	label("OBOROBI / GIANT & THREE RITES 0.5",14,Rect2(108,213,400,30),GOLD,0,modal)
	label("朧 火",56,Rect2(105,268,330,90),WHITE,0,modal)
	label("予告を避け、金の環へ。",24,Rect2(110,361,350,42),GOLD,0,modal)
	label("巨大な鬼へ、返し鎖。\n鎖・炎・刀の大技は右下から。",20,Rect2(110,407,366,64),WHITE,0,modal)
	button("巨鬼に挑む",Rect2(108,499,382,54),driver.start_run,modal)
	label("進みたい方向へスワイプ。すぐ次の鎖へ。",20,Rect2(76,618,770,40),WHITE,0,modal)
	label("予告の中から鎖で回避＋1 / 直後の返し鎖＋2 → 鎖葬。",17,Rect2(76,657,1020,32),MUTED,0,modal)
	label("予告の中から避けて、鎖火を得る。被弾で失う。",17,Rect2(558,511,710,34),GOLD,0,modal)

func show_choices():
	clear_panel()
	current_panel = "upgrade"
	dim(.67)
	label("灯 を 継 ぐ",38,Rect2(290,137,700,60),GOLD,HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("LEVEL %02d  /  ひとつ選ぶと戦闘を再開" % run.level,18,Rect2(290,204,700,38),WHITE,HORIZONTAL_ALIGNMENT_CENTER,modal)
	for i in range(run.offers.size()):
		var id = run.offers[i]
		var upgrade = run.get_upgrade(id)
		var rect = Rect2(141+i*339,276,320,285)
		var card = button("",rect,driver.select_upgrade.bind(id),modal)
		card.set_meta("upgrade_id",id)
		choice_buttons.append(card)
		var color = BLUE if upgrade.tag.begins_with("魂火") or upgrade.tag.begins_with("術") else GOLD
		label(upgrade.tag,17,Rect2(23,20,275,31),color,0,card)
		label(upgrade.name,29,Rect2(22,72,280,58),WHITE,0,card)
		label(upgrade.desc,20,Rect2(23,143,277,75),MUTED,0,card)
		label("新しい術を修得" if upgrade.tag.begins_with("術") else "%d / %d  →  %d / %d" % [run.count(id),upgrade.max,run.count(id)+1,upgrade.max],17,Rect2(23,235,274,30),color,0,card)
		card.focus_mode = Control.FOCUS_ALL
	label("強化中は時間が止まります。",16,Rect2(390,589,500,40),MUTED,HORIZONTAL_ALIGNMENT_CENTER,modal)
	if not choice_buttons.is_empty(): choice_buttons[0].grab_focus()

func show_pause():
	clear_panel()
	current_panel = "paused"
	dim(.60)
	panel(Rect2(410,228,460,254),Color("121d2a"))
	label("ひと息",37,Rect2(450,254,380,62),GOLD,HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("画面を離れている間も、戦闘は停止します。",17,Rect2(420,333,440,40),MUTED,HORIZONTAL_ALIGNMENT_CENTER,modal)
	button("戦闘へ戻る",Rect2(450,398,380,60),driver.toggle_pause,modal).grab_focus()

func show_result():
	clear_panel()
	current_panel = run.phase
	dim(.72)
	panel(Rect2(379,149,522,427),Color("121b28"))
	var cleared = run.phase == "won"
	label("DAWN / CLEAR" if cleared else "FALLEN / RETRY",16,Rect2(430,174,420,32),BLUE if cleared else Color("cb8b79"),HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("巨 鬼 討 伐" if cleared else "落 命",43,Rect2(430,224,420,70),GOLD,HORIZONTAL_ALIGNMENT_CENTER,modal)
	var seconds = int(run.time)
	label("生存  %02d:%02d     /     Lv. %d" % [seconds/60,seconds%60,run.level],23,Rect2(427,319,426,45),WHITE,HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("討伐  %d 体       回収した魂  %d" % [run.kills,run.souls_taken],21,Rect2(427,369,426,45),MUTED,HORIZONTAL_ALIGNMENT_CENTER,modal)
	var sword = run.count("edge")+run.count("reach")+run.count("cadence")
	var fire = run.count("ember")+run.count("barrage")+run.count("pierce")
	label("鎖 %d 射 / 最大 %d 連鎖" % [run.grapple.shots,run.grapple.best_flow],18,Rect2(425,416,430,35),BLUE,HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("鎖回避 %d / 返し鎖 %d / 鎖葬 %d" % [run.grapple.near_passes,run.grapple.arrival_rewards,run.grapple.bursts],17,Rect2(425,452,430,28),GOLD,HORIZONTAL_ALIGNMENT_CENTER,modal)
	button("もう一度、挑む",Rect2(426,488,428,62),driver.start_run.bind(run.boss_only),modal).grab_focus()

func update_hud():
	run = driver.run
	hp_text.text = "%d / %d" % [ceil(run.hp),run.max_hp]
	var remaining = maxi(0,int(ceil(180-run.time)))
	timer_text.text = "%02d:%02d" % [remaining/60,remaining%60]
	if run.phase == "menu":
		timer_text.text = "GIANT TRIAL"
		timer_text.add_theme_font_size_override("font_size",24)
	timer_text.visible = run.stage != "boss"
	boss_text.visible = run.stage == "boss" and current_panel == ""
	kills_text.text = "討伐  %03d" % run.kills
	level_text.text = "Lv. %d" % run.level
	xp_text.text = "灯  %d / %d" % [run.xp,run.xp_needed]
	weapon_text.text = "一閃 %d   魂火 %d   術 %d/4" % [1+run.count("edge")+run.count("reach")+run.count("cadence"),1+run.count("ember")+run.count("barrage")+run.count("pierce"),run.skills.active_count(run)]
	var names = []
	for pair in [["cinder_trail","残火"],["chain_lightning","雷"],["orbit_blades","月輪"],["petal_wave","彼岸"]]:
		if run.count(pair[0]) > 0: names.append(pair[1])
	arts_text.text = "術："+("・".join(names) if not names.is_empty() else "未修得")
	arts_text.visible = current_panel == "" and run.phase == "playing"
	energy_text.visible = current_panel == "" and run.phase == "playing"
	var chain = run.grapple
	if chain.burst_left > 0:
		energy_text.text = "鎖 葬  /  金色の刃で突破"
		energy_text.modulate = Color("ffe4a0")
	elif chain.energy == chain.ENERGY_MAX:
		energy_text.text = "鎖葬 準備完了 / 次の鎖へ  %.1f秒" % chain.energy_left
		energy_text.modulate = GOLD if chain.energy_left > 1 else Color("d49185")
	elif chain.loss_flash > 0:
		energy_text.text = "鎖火  0 / 3  ・ "+chain.loss_reason
		energy_text.modulate = Color("d49185")
	elif chain.energy > 0:
		energy_text.text = "鎖火  %d / 3  ・ 次の鎖へ  %.1f秒" % [chain.energy,chain.energy_left]
		energy_text.modulate = GOLD if chain.energy_left > 1 else Color("d49185")
	else:
		energy_text.text = "予告を鎖で回避＋1 → 返し鎖＋2"
		energy_text.modulate = MUTED
	var chapter = mini(3,1+int(run.time/60))
	chapter_text.text = ["第一刻 / 影が集う","第二刻 / 鬼面が迫る","第三刻 / 夜明けは近い"][chapter-1]
	if run.phase == "menu": chapter_text.text = "巨鬼を、鎖で討つ"
	chapter_text.modulate.a = .85 if fmod(run.time,60) < 7 else .40
	if run.stage == "boss":
		chapter_text.position = Vector2(527,81)
		chapter_text.size = Vector2(455,32)
		chapter_text.modulate.a = 1.0
		if run.boss.state == "windup": chapter_text.text = run.boss.NAMES[run.boss.pattern]+" / 鎖で予告の外へ"
		elif run.boss.state == "open": chapter_text.text = ("返し鎖！ " if run.boss.counter_ready else "金の環へ ")+"%.1f秒" % run.boss.clock
		elif run.boss.state == "defeated": chapter_text.text = "巨鬼を封じた"
		else: chapter_text.text = "怒り / 次の予告に備える" if run.boss.enraged else "青い環は常に鎖を掛けられる"
	else:
		chapter_text.position = Vector2(470,70)
		chapter_text.size = Vector2(340,32)
	for id in ultimate_buttons:
		var control = ultimate_buttons[id]
		control.visible = current_panel == "" and run.phase == "playing"
		control.disabled = driver.paused or run.phase != "playing" or run.ultimates.cooldown[id] > 0 or run.boss.state == "defeated"
		var title = {"chain":"鎖 / 天鎖解放","flame":"炎 / 蒼炎還魂","blade":"刀 / 天断ち"}[id]
		var left = run.ultimates.cooldown[id]
		control.text = title+"\n"+("発動" if left <= 0 else "%02d秒" % ceil(left))+"\n "
		var active = {"chain":run.ultimates.haste_left,"flame":run.ultimates.quench_left,"blade":run.ultimates.fracture_left}[id]
		var utility = {"chain":"高速移動","flame":"回復・抑制","blade":"防御崩し"}[id]
		if active > 0: utility = {"chain":"高速","flame":"抑制","blade":"防御崩し"}[id]+" %.1f秒" % active
		ultimate_notes[id].text = utility
		ultimate_notes[id].modulate = GOLD if active > 0 else BLUE
	sound_button.text = "音" if not driver.muted else "静"
	pause_button.disabled = run.phase != "playing"
	chain_text.visible = current_panel == "" and run.phase == "playing"
	if run.grapple.state == "flying": chain_text.text = "鎖を射出 / 次のスワイプへ"
	elif run.grapple.state == "pulling": chain_text.text = "高速移動 / スワイプで次の鎖へ"
	elif run.grapple.drift > 0 and run.velocity.length() > 25: chain_text.text = "慣性で滑走 / 次のスワイプへ"
	else: chain_text.text = "スワイプで鎖移動 / タップで解除"
	if run.grapple.flow >= 2:
		chain_text.text = "%d連鎖 / " % run.grapple.flow+chain_text.text
	chain_text.modulate = GOLD if run.grapple.flow >= 3 else WHITE
	queue_redraw()

func _draw():
	if driver == null: return
	run = driver.run
	# Separate small panels preserve the torii lintel and the distant composition.
	draw_rect(Rect2(0,0,518,94 if current_panel != "" else 147),Color(.035,.052,.082,.89))
	draw_rect(Rect2(520,8,472 if run.stage == "boss" else 233,110 if run.stage == "boss" else 82),Color(.035,.052,.082,.73))
	draw_rect(Rect2(998,0,282,101),Color(.035,.052,.082,.78))
	draw_line(Vector2(18,92),Vector2(500,92),Color("76624d"),1)
	draw_rect(Rect2(18,16,67,67),Color("142336"))
	draw_rect(Rect2(18,16,67,67),Color("b19465"),false,1)
	draw_rect(Rect2(95,29,239,19),Color("302a32"))
	draw_rect(Rect2(97,31,235*clampf(run.hp/run.max_hp,0,1),15),Color("963f43"))
	draw_rect(Rect2(97,31,235*clampf(run.hp/run.max_hp,0,1),3),Color("c17465"))
	draw_rect(Rect2(95,29,239,19),Color("ac9269"),false,1)
	if run.boss.active() and current_panel == "":
		var fraction = clampf(run.boss.actor.hp/run.boss.actor.max_hp,0,1)
		draw_rect(Rect2(533,60,444,12),Color("322633"))
		draw_rect(Rect2(535,62,440*fraction,8),Color("a96365") if not run.boss.enraged else Color("c78364"))
		draw_rect(Rect2(535,62,440*fraction,2),Color("dfb38d"))
		for i in range(1,8): draw_line(Vector2(533+i*55.5,60),Vector2(533+i*55.5,72),Color("59444b"),1)
	draw_rect(Rect2(0,708,1280,12),Color("172536"))
	draw_rect(Rect2(0,710,1280*clampf(float(run.xp)/run.xp_needed,0,1),8),Color("5293ab"))
	draw_rect(Rect2(0,709,1280*clampf(float(run.xp)/run.xp_needed,0,1),1),Color("a7d9da"))
	if current_panel == "" and run.phase == "playing":
		for i in range(run.grapple.ENERGY_MAX):
			var color = Color("d7b578") if i < run.grapple.energy or run.grapple.burst_left > 0 else Color("303945")
			if run.grapple.ready_flash > 0 and run.grapple.energy == run.grapple.ENERGY_MAX: color = Color("f5e1af")
			draw_rect(Rect2(95+i*80,132,74,7),color)
		if run.grapple.energy > 0:
			draw_rect(Rect2(347,132,146*clampf(run.grapple.energy_left/run.grapple.ENERGY_HOLD,0,1),3),Color("987457"))
		_draw_stick()

func _draw_stick():
	if not driver.stick_active or driver.aim_input.length() < 5: return
	var origin = driver.stick_origin
	var direction = driver.aim_input.normalized()
	var center = origin+driver.aim_input.limit_length(72)
	var side = direction.orthogonal()
	var color = Color(.68,.86,.87,.78)
	draw_line(origin,center,color,2,false)
	draw_polyline(PackedVector2Array([center-direction*10+side*6,center,center-direction*10-side*6]),color,2,false)
