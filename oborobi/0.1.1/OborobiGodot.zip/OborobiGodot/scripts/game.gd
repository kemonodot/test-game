extends Control

const Core = preload("res://scripts/combat.gd")
const Field = preload("res://scripts/battlefield.gd")
const Hud = preload("res://scripts/hud.gd")
const SOUND_FILES = {"slash":preload("res://assets/audio/slash.wav"),"shatter":preload("res://assets/audio/shatter.wav"),
	"fire":preload("res://assets/audio/fire.wav"),"pickup":preload("res://assets/audio/pickup.wav"),
	"level":preload("res://assets/audio/level.wav"),"hurt":preload("res://assets/audio/hurt.wav"),"death":preload("res://assets/audio/death.wav")}

var run = Core.new()
var field
var hud
var paused = false
var muted = false
var stick_active = false
var stick_origin = Vector2.ZERO
var stick_pos = Vector2.ZERO
var touch_index = -1
var move_input = Vector2.ZERO
var voices = []
var ambient: AudioStreamPlayer
var audio_gate = {}
var audio_rng = RandomNumberGenerator.new()
var hud_clock = 0.0
var demo = false
var capture = false
var demo_choice_wait = 0.0
var shots = {}
var wall_clock = 0.0
var update_us = []
var last_phase = ""
var closing = false

func _ready():
	audio_rng.seed = 3117
	_register_input()
	var container = SubViewportContainer.new()
	container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	container.stretch = true
	container.stretch_shrink = 2
	container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	container.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(container)
	var viewport = SubViewport.new()
	viewport.size = Vector2i(640,360)
	viewport.disable_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	viewport.snap_2d_transforms_to_pixel = true
	viewport.snap_2d_vertices_to_pixel = true
	container.add_child(viewport)
	field = Field.new()
	field.run = run
	viewport.add_child(field)
	hud = Hud.new()
	add_child(hud)
	hud.setup(self)
	for i in range(6):
		var voice = AudioStreamPlayer.new()
		voice.volume_db = -12
		add_child(voice)
		voices.append(voice)
	ambient = AudioStreamPlayer.new()
	var drone = preload("res://assets/audio/ambient.wav").duplicate()
	drone.loop_mode = AudioStreamWAV.LOOP_FORWARD
	drone.loop_end = int(16*22050)
	ambient.stream = drone
	ambient.volume_db = -16
	add_child(ambient)
	ambient.play()
	get_window().focus_exited.connect(_focus_lost)
	get_tree().set_auto_accept_quit(false)
	get_tree().set_quit_on_go_back(false)
	get_window().close_requested.connect(_quit_cleanly)
	var args = OS.get_cmdline_user_args()
	demo = args.has("--demo")
	capture = args.has("--capture")
	if demo: start_run()
	if args.has("--arena"):
		hud.clear_panel()
		capture = true

func _register_input():
	var keys = {"move_left":[KEY_A,KEY_LEFT],"move_right":[KEY_D,KEY_RIGHT],"move_up":[KEY_W,KEY_UP],"move_down":[KEY_S,KEY_DOWN]}
	for action in keys:
		if not InputMap.has_action(action): InputMap.add_action(action)
		for key in keys[action]:
			var event = InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action,event)

func _exit_tree():
	# Stop playback explicitly before shutdown, including the headless test driver.
	_stop_audio()

func _stop_audio():
	for voice in voices:
		voice.stop()
		voice.stream = null
	if is_instance_valid(ambient):
		ambient.stop()
		ambient.stream = null

func _quit_cleanly():
	if closing: return
	closing = true
	paused = true
	run.sounds.clear()
	_stop_audio()
	# Give the audio mixer one short interval to release playback references.
	await get_tree().create_timer(.12).timeout
	get_tree().quit()

func start_run():
	run = Core.new(7319 if demo else -1)
	run.start()
	field.run = run
	hud.run = run
	hud.clear_panel()
	paused = false
	release_stick()
	last_phase = "playing"
	hud.update_hud()

func select_upgrade(id):
	if run.choose(id):
		hud.clear_panel()
		last_phase = "playing"
		demo_choice_wait = 0.0
		release_stick()

func toggle_pause():
	if run.phase != "playing": return
	paused = not paused
	release_stick()
	if paused: hud.show_pause()
	else: hud.clear_panel()

func toggle_sound():
	muted = not muted
	AudioServer.set_bus_mute(0,muted)
	hud.update_hud()

func _focus_lost():
	if run.phase == "playing" and not paused and not demo:
		toggle_pause()

func _notification(what):
	if what == NOTIFICATION_APPLICATION_PAUSED:
		_focus_lost()
		release_stick()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if run.phase == "playing":
			toggle_pause()
		elif run.phase in ["menu", "won", "lost"]:
			_quit_cleanly()

func release_stick():
	stick_active = false
	touch_index = -1
	move_input = Vector2.ZERO
	run.velocity = Vector2.ZERO

func _input(event):
	# Claim movement before the SubViewport's GUI forwarding. Modal states and
	# the compact header keep their own input; only empty battlefield starts a stick.
	if run.phase == "playing" and not paused and not stick_active:
		if event is InputEventScreenTouch and event.pressed:
			_begin_stick(event.position,event.index)
		elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			_begin_stick(event.position,-2)
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode in [KEY_ESCAPE,KEY_P]:
		toggle_pause()
		get_viewport().set_input_as_handled()
	if event is InputEventScreenTouch and not event.pressed and event.index == touch_index:
		release_stick()
	if event is InputEventScreenDrag and stick_active and event.index == touch_index:
		_move_stick(event.position)
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed and touch_index == -2:
		release_stick()
	if event is InputEventMouseMotion and stick_active and touch_index == -2:
		_move_stick(event.position)

func _unhandled_input(event):
	if run.phase != "playing" or paused: return
	if event is InputEventScreenTouch and event.pressed and not stick_active:
		_begin_stick(event.position,event.index)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_begin_stick(event.position,-2)

func _begin_stick(at,index):
	if at.y < 110 or at.y > 705: return
	if at.x >= 1160 and at.y < 192: return
	stick_active = true
	touch_index = index
	stick_origin = at
	stick_pos = at
	move_input = Vector2.ZERO
	get_viewport().set_input_as_handled()

func _move_stick(at):
	var diff = (at-stick_origin).limit_length(65)
	stick_pos = stick_origin+diff
	move_input = diff/65.0 if diff.length() > 7 else Vector2.ZERO

func _process(dt):
	var before = Time.get_ticks_usec()
	wall_clock += dt
	var move = move_input if stick_active else Input.get_vector("move_left","move_right","move_up","move_down")
	if demo:
		move = _demo_move()
		if run.phase == "upgrade":
			demo_choice_wait += dt
			if demo_choice_wait > 1.15:
				var priorities = ["reach","edge","barrage","cadence","ward","ember","mending","pierce","stride","magnet"]
				if run.hp < run.max_hp*.55: priorities = ["ward","mending"]+priorities
				for id in priorities:
					if run.offers.has(id):
						# Activate the actual card, the same signal as a player tap.
						for card in hud.choice_buttons:
							if card.get_meta("upgrade_id") == id:
								card.pressed.emit()
								break
						break
	if not paused:
		run.tick_visual(minf(dt,.05))
		run.step(minf(dt,.05),move)
	if last_phase != run.phase:
		last_phase = run.phase
		release_stick()
		if run.phase == "upgrade": hud.show_choices()
		elif run.phase in ["won","lost"]: hud.show_result()
	_play_sounds()
	hud_clock -= dt
	if hud_clock <= 0:
		hud_clock = .08
		hud.update_hud()
	if capture: _capture_schedule()
	if update_us.size() < 15000: update_us.append(Time.get_ticks_usec()-before)

func _play_sounds():
	for name in run.sounds:
		if wall_clock-audio_gate.get(name,-1) < (.07 if name in ["shatter","pickup"] else .025): continue
		audio_gate[name] = wall_clock
		for voice in voices:
			if not voice.playing:
				voice.stream = SOUND_FILES[name]
				voice.pitch_scale = audio_rng.randf_range(.94,1.06) if name not in ["level","death"] else 1.0
				voice.play()
				break
	run.sounds.clear()

func _demo_move():
	var destination = Vector2(320+sin(run.time*.11)*151,205+cos(run.time*.17)*73)
	var movement = Core.ground_vector(destination-run.player).normalized()
	for e in run.enemies:
		if not e.alive: continue
		var diff = Core.ground_vector(run.player-e.p)
		if diff.length() < 32:
			movement += diff.normalized()*(1.0-diff.length()/32)*2.2
	return movement.limit_length()

func _capture_schedule():
	if wall_clock > .4 and not shots.has("01-arena"):
		shots["01-arena"] = true
		_save_shot.call_deferred("01-arena")
	if run.time >= 20 and not shots.has("02-combat") and not run.slashes.is_empty():
		shots["02-combat"] = true
		_save_shot.call_deferred("02-combat")
	if run.time > 35 and run.particles.size() >= 18 and not shots.has("03-shatter"):
		shots["03-shatter"] = true
		_save_shot.call_deferred("03-shatter")
	if run.phase == "upgrade" and not shots.has("04-upgrade"):
		shots["04-upgrade"] = true
		_save_shot.call_deferred("04-upgrade")
	if run.phase in ["won","lost"] and not shots.has("05-result"):
		shots["05-result"] = true
		_save_shot.call_deferred("05-result")
		_save_metrics()

func _save_shot(name):
	await RenderingServer.frame_post_draw
	var pixels = get_viewport().get_texture().get_image()
	if pixels != null:
		var error = pixels.save_png("res://captures/%s.png" % name)
		print("CAPTURE ",name," ",pixels.get_size()," result=",error)

func _save_metrics():
	var ordered = update_us.duplicate()
	ordered.sort()
	var report = {"phase":run.phase,"survival":run.time,"level":run.level,"kills":run.kills,"souls":run.souls_taken,
		"peak_enemies":run.peak_enemies,"peak_particles":run.peak_particles,"heavy_shatters":run.heavy_shatters,
		"sword_hits":run.sword_hits,"fire_hits":run.fire_hits,"upgrades":run.upgrades,
		"update_p95_ms":ordered[int(ordered.size()*.95)]/1000.0 if not ordered.is_empty() else 0,
		"display_driver":DisplayServer.get_name(),"renderer":RenderingServer.get_video_adapter_name()}
	var file = FileAccess.open("res://captures/runtime.json",FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(report,"\t"))
	print("RUN REPORT ",JSON.stringify(report))
