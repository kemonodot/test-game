extends Node2D
## Everything in this viewport is 640x360, nearest-filtered and pixel-snapped.
## Enemies/projectiles/particles are data, not hundreds of scene-tree nodes.

const ARENA = preload("res://assets/art/arena.png")
const RONIN = preload("res://assets/art/ronin.png")
const RONIN_FLASH = preload("res://assets/art/ronin_flash.png")
const ASHIGARU = preload("res://assets/art/ashigaru.png")
const ASHIGARU_FLASH = preload("res://assets/art/ashigaru_flash.png")
const GUARDIAN = preload("res://assets/art/guardian.png")
const GUARDIAN_FLASH = preload("res://assets/art/guardian_flash.png")
const FIRE = preload("res://assets/art/soul_fire.png")
const DIGITS = ["111101101101111","010110010010111","111001111100111","111001111001111","101101111001001","111100111001111","111100111101111","111001001001001","111101111101111","111101111001111"]

var run

func _process(_dt):
	if run == null: return
	position = Vector2(sin(run.visual_time*103),cos(run.visual_time*87))*run.shake
	position = position.round()
	queue_redraw()

func _draw():
	if run == null: return
	draw_texture(ARENA,Vector2.ZERO)
	for lamp in [Vector2(83,177),Vector2(393,81),Vector2(547,154),Vector2(565,287)]:
		if int(run.visual_time*6+lamp.x)%3 == 0:
			draw_rect(Rect2(lamp+Vector2(-2,0),Vector2(2,4)),Color("ffe0a0"))
	for stain in run.stains:
		var c = Color("4f303b") if stain.kind == 0 else Color("3a3545")
		var seed_value = stain.seed
		for i in range(5):
			var offset = Vector2((seed_value+i*7)%17-8,(seed_value+i*3)%7-3)
			draw_rect(Rect2((stain.p+offset).round(),Vector2(2+(i%3),1)),c)
	for soul in run.souls:
		var p = (soul.p-Vector2(0,3+sin(soul.age*4)*1.2)).round()
		draw_rect(Rect2(p+Vector2(-3,-1),Vector2(7,3)),Color("1e3a55"))
		draw_rect(Rect2(p+Vector2(-1,-3),Vector2(3,7)),Color("477f9e"))
		draw_rect(Rect2(p+Vector2(-2,-1),Vector2(5,3)),Color("65b2c4"))
		draw_rect(Rect2(p,Vector2.ONE),Color("cef1e5"))
		if soul.value >= 3:
			draw_rect(Rect2(p+Vector2(-1,-5),Vector2(2,1)),Color("b6e9df"))
	for ring in run.rings:
		var progress = 1-ring.life/ring.total
		var radius = 6+ring.size*progress
		for i in range(24):
			if progress > .6 and i%2 == 0: continue
			var p = ring.p+Vector2(cos(i*TAU/24)*radius,sin(i*TAU/24)*radius*.72)
			var color = ring.color
			color.a = minf(1,ring.life/ring.total*1.7)
			draw_rect(Rect2(p.round(),Vector2(2,1)),color)
	var actors = []
	for e in run.enemies:
		if e.alive: actors.append({"p":e.p,"e":e,"hero":false})
	if run.phase not in ["dying","lost"]:
		actors.append({"p":run.player,"hero":true})
	actors.sort_custom(func(a,b): return a.p.y < b.p.y)
	for actor in actors:
		var p = actor.p.round()
		# Pixelated contact shadow, with feet exactly at actor.p.
		draw_rect(Rect2(p+Vector2(-10,-2),Vector2(20,3)),Color(0.04,.07,.11,.65))
		draw_rect(Rect2(p+Vector2(-7,-3),Vector2(14,5)),Color(0.04,.07,.11,.55))
		var texture
		var frame = 0
		var direction = 0
		if actor.hero:
			direction = run._direction(run.facing)
			frame = int(run.time*9)%4 if run.velocity.length_squared() > 10 else 0
			texture = RONIN_FLASH if run.invulnerable > .67 else RONIN
			if run.invulnerable > 0 and int(run.visual_time*16)%3 == 0: continue
			# A very small four-point marker makes the dark coat easy to locate.
			for offset in [Vector2(-12,0),Vector2(12,0),Vector2(0,4)]:
				draw_rect(Rect2(p+offset,Vector2(2,1)),Color("79b5bb"))
		else:
			var e = actor.e
			direction = e.direction
			frame = int(e.walk)%4
			if e.kind == 0: texture = ASHIGARU_FLASH if e.flash > 0 else ASHIGARU
			else: texture = GUARDIAN_FLASH if e.flash > 0 else GUARDIAN
		draw_texture_rect_region(texture,Rect2(p-Vector2(16,29),Vector2(32,32)),Rect2(frame*32,direction*32,32,32))
	for slash in run.slashes:
		_draw_slash(slash)
	for b in run.bullets:
		for i in range(b.trail.size()):
			var c = Color("67bad0") if i < 2 else Color("285777")
			c.a = .9-i*.13
			draw_rect(Rect2((b.trail[i]+Vector2(-1,-2)).round(),Vector2(3 if i < 2 else 2,2)),c)
		var frame = int(run.visual_time*12)%4
		draw_texture_rect_region(FIRE,Rect2(b.p.round()-Vector2(8,12),Vector2(16,16)),Rect2(frame*16,0,16,16))
	for p in run.particles:
		var c = p.color
		var fraction = p.life/p.total
		c.a = 1.0 if fraction > .35 else (0.66 if fraction > .15 else .3)
		var size_px = p.size if fraction > .25 else 1
		draw_rect(Rect2(p.p.round(),Vector2(size_px,size_px)),c)
	for n in run.numbers:
		_draw_number(n)
	# A handful of square petals at the borders; never a particle curtain.
	for i in range(12):
		var x = fmod(i*53.0+run.visual_time*(3+i%3),640)
		var y = 57+sin(run.visual_time*.65+i*2.1)*6 if i%2 == 0 else 334+sin(run.visual_time*.5+i)*5
		draw_rect(Rect2(Vector2(x,y).round(),Vector2(2,1)),Color("91556a"))

func _draw_slash(slash):
	var progress = 1-slash.life/slash.total
	var start = slash.angle-1.04+maxf(0,progress-.55)*1.5
	var end = slash.angle-1.04+2.08*minf(1,progress*3.6)
	if end <= start: return
	var radius = slash.radius
	var width = 7.0+radius*.045
	var ribbon = PackedVector2Array()
	for i in range(25):
		var angle = lerpf(start,end,i/24.0)
		var middle = (slash.p+Vector2(cos(angle)*(radius-width*.5),sin(angle)*(radius-width*.5)*.72)-Vector2(0,10)).round()
		if ribbon.is_empty() or ribbon[-1] != middle: ribbon.append(middle)
	# Thick pixel-snapped strips avoid degenerate concave polygons at the first
	# and final frames of the slash. The white boundary is the real attack range.
	if ribbon.size() >= 2:
		draw_polyline(ribbon,Color("284868") if progress < .65 else Color("20394f"),width,false)
	var previous = Vector2.ZERO
	for i in range(37):
		var angle = lerpf(start,end,i/36.0)
		var point = (slash.p+Vector2(cos(angle)*radius,sin(angle)*radius*.72)-Vector2(0,10)).round()
		if i > 0:
			draw_line(previous,point,Color("63acc8"),3,false)
			draw_line(previous,point,Color("e1edda") if progress < .68 else Color("88b8c5"),1,false)
		previous = point
	var tip = (slash.p+Vector2(cos(end)*radius,sin(end)*radius*.72)-Vector2(0,10)).round()
	var tip_back = (slash.p+Vector2(cos(end)*(radius-12),sin(end)*(radius-12)*.72)-Vector2(0,10)).round()
	draw_line(tip_back,tip,Color("f8efd2"),2,false)

func _draw_number(n):
	var origin = n.p.round()-Vector2(n.text.length()*2,0)
	var color = Color("ead6a3") if n.strong else Color("e0ddd0")
	color.a = minf(1,n.life*4)
	for i in range(n.text.length()):
		var digit = int(n.text[i])
		for y in range(5):
			for x in range(3):
				if DIGITS[digit][y*3+x] == "1":
					var at = origin+Vector2(i*4+x,y)
					draw_rect(Rect2(at+Vector2(1,1),Vector2.ONE),Color("151c2a"))
					draw_rect(Rect2(at,Vector2.ONE),color)
