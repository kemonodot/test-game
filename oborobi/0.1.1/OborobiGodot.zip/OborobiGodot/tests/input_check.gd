extends SceneTree
const Scene = preload("res://main.tscn")

class Probe extends Node:
	func _input(event):
		if event is InputEventScreenTouch or event is InputEventScreenDrag:
			print("INPUT DISPATCH ",event.as_text())

func _initialize():
	root.size = Vector2i(1280,720)
	call_deferred("test")

func test():
	var game = Scene.instantiate()
	root.add_child(game)
	root.add_child(Probe.new())
	await process_frame
	await process_frame
	game.set_process(false)
	var menu_button = game.hud.modal.get_children().filter(func(node): return node is Button)[0]
	await tap(menu_button.get_global_rect().get_center())
	assert(game.run.phase == "playing", "A real touch must activate the start button")
	print("PASS touch starts the game through the real GUI button")
	print("INPUT CONTEXT root=",root.size," game=",game.size," enabled=",game.is_processing_input())
	print("SCREEN TRANSFORM ",root.get_screen_transform())
	var touch = InputEventScreenTouch.new()
	touch.index = 0
	touch.position = root.get_screen_transform()*Vector2(150,500)
	touch.pressed = true
	Input.parse_input_event(touch)
	await process_frame
	await process_frame
	print("GLOBAL touch active=",game.stick_active)
	var drag = InputEventScreenDrag.new()
	drag.index = 0
	drag.position = root.get_screen_transform()*Vector2(215,500)
	Input.parse_input_event(drag)
	await process_frame
	await process_frame
	print("GLOBAL drag move=",game.move_input)
	touch.pressed = false
	Input.parse_input_event(touch)
	await process_frame
	await process_frame
	game.release_stick()
	touch.pressed = true
	touch.position = Vector2(150,500)
	drag.position = Vector2(215,500)
	root.push_input(touch,true)
	root.push_input(drag,true)
	print("VIEWPORT touch active=",game.stick_active," move=",game.move_input)
	touch.pressed = false
	root.push_input(touch,true)
	print("VIEWPORT release=",game.stick_active)
	await tap(game.hud.pause_button.get_global_rect().get_center())
	assert(game.paused, "A real touch must activate pause")
	print("PASS touch pauses the game through the real GUI button")
	var resume = game.hud.modal.get_children().filter(func(node): return node is Button)[0]
	await tap(resume.get_global_rect().get_center())
	assert(not game.paused, "A real touch must resume")
	game._begin_stick(Vector2(150,500),0)
	game._move_stick(Vector2(215,500))
	game.notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	assert(game.paused and not game.stick_active and game.move_input == Vector2.ZERO, "Android Back must pause and release movement")
	game.notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	assert(not game.paused, "Android Back must resume a paused run")
	print("PASS Android Back pauses/resumes without quitting the run")
	game._begin_stick(Vector2(150,500),0)
	game.notification(Node.NOTIFICATION_APPLICATION_PAUSED)
	assert(game.paused and not game.stick_active, "App backgrounding must pause and release the finger")
	game.notification(Node.NOTIFICATION_APPLICATION_RESUMED)
	assert(game.paused, "Returning to the app must wait for the player to resume")
	resume = game.hud.modal.get_children().filter(func(node): return node is Button and node.visible)[0]
	await tap(resume.get_global_rect().get_center())
	assert(not game.paused, "Touch resumes after backgrounding")
	print("PASS app background/resume preserves a safe paused state")
	game.run.xp = 9
	game._process(1.0/60)
	var card = game.hud.choice_buttons[1]
	var id = card.get_meta("upgrade_id")
	game.notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)
	assert(game.run.phase == "upgrade", "Android Back must preserve an upgrade choice")
	await tap(card.get_global_rect().get_center())
	assert(game.run.phase == "playing" and game.run.count(id) == 1, "A real touch must select the card")
	print("PASS touch selects an upgrade through the real GUI card")
	game.queue_free()
	await process_frame
	await create_timer(.12).timeout
	quit()

func tap(logical_position):
	var event = InputEventScreenTouch.new()
	event.index = 0
	event.position = root.get_screen_transform()*logical_position
	event.pressed = true
	Input.parse_input_event(event)
	await process_frame
	await process_frame
	event.pressed = false
	Input.parse_input_event(event)
	await process_frame
	await process_frame
