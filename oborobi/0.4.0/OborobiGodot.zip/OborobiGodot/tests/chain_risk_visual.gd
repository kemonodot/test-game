extends SceneTree
## Actual native rendering at several motion phases; screenshots only, no video.
const Scene = preload("res://main.tscn")

func _initialize():
	root.size = Vector2i(1280,720)
	call_deferred("inspect")

func inspect():
	var game = Scene.instantiate()
	root.add_child(game)
	await process_frame
	await process_frame
	game.set_process(false)
	game.hud.update_hud()
	await game._save_shot("14-chain-risk-intro")
	game.start_run()
	game.run.player = Vector2(235,215)
	game.run.time = 50
	game.run.spawn_clock = 999
	game.run.sword_clock = 999
	game.run.fire_clock = 999
	# Controlled arrangement, ordinary enemy HP and attack values. Only the XP
	# threshold is raised to keep a card overlay out of these rendering samples.
	game.run.xp_needed = 999
	for x in [278,305,335]:
		var enemy = game.run.spawn_enemy(0,Vector2(x,230))
		enemy.speed = 0
	game._begin_stick(Vector2(180,550),0)
	game._move_stick(Vector2(222,550))
	game._finish_aim()
	for _i in range(90):
		game._process(1.0/60)
		await process_frame
		if game.run.grapple.energy == 3: break
	assert(game.run.grapple.energy == 3)
	game.hud.update_hud()
	await game._save_shot("15-chain-energy-ready")
	var positions = [Vector2(351,218),Vector2(368,235),Vector2(392,197),Vector2(420,232),Vector2(457,219),Vector2(488,215),Vector2(515,243),Vector2(430,266),Vector2(389,268),Vector2(304,282),Vector2(279,260),Vector2(263,186),Vector2(448,165)]
	for i in range(positions.size()):
		var enemy = game.run.spawn_enemy(1 if i in [5,8,12] else 0,positions[i])
		enemy.speed = 0
	game._begin_stick(Vector2(180,550),0)
	game._move_stick(Vector2(222,550))
	game._finish_aim()
	var started = false
	var motion_frames = 0
	for _i in range(120):
		game._process(1.0/60)
		await process_frame
		if game.run.grapple.burst_left > 0: started = true
		if started:
			motion_frames += 1
			if motion_frames in [5,13,23]:
				game.hud.update_hud()
				await game._save_shot("%02d-chain-burst-%s" % [16+[5,13,23].find(motion_frames),["start","middle","end"][[5,13,23].find(motion_frames)]])
			if motion_frames >= 40: break
	assert(game.run.grapple.bursts == 1)
	assert(game.run.kills >= 4 and game.run.heavy_shatters >= 4)
	print("PASS real swipe-earned gauge and golden strike rendered across motion phases")
	print("CHAIN VISUAL ",JSON.stringify({"energy":game.run.grapple.energy,"near_passes":game.run.grapple.near_passes,"bursts":game.run.grapple.bursts,"kills":game.run.kills,"heavy_shatters":game.run.heavy_shatters,"particles":game.run.peak_particles}))
	# Enter the card overlay with a valid XP balance in this controlled sample.
	game.run.xp = game.run.xp_needed
	game.run.level_up()
	game.hud.show_choices()
	game.hud.update_hud()
	await game._save_shot("19-chain-risk-upgrade")
	# The capture runner owns the scene: free it before stopping the audio mixer.
	# This avoids retaining a WAV playback across SceneTree test-driver shutdown.
	game.queue_free()
	await process_frame
	await create_timer(.20).timeout
	quit()
