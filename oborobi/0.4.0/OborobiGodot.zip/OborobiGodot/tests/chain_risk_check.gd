extends SceneTree
## Exercise the shared simulation: rewards require movement past real enemies.
const Core = preload("res://scripts/combat.gd")
const Geometry = preload("res://scripts/arena_geometry.gd")
var checks = 0
var failures = 0

func _initialize():
	call_deferred("test")

func check(condition, description):
	checks += 1
	if condition: print("PASS ",description)
	else:
		failures += 1
		push_error("FAIL "+description)

func quiet_run():
	var run = Core.new(427)
	run.start()
	run.spawn_clock = 999
	run.sword_clock = 999
	run.fire_clock = 999
	return run

func advance(run, seconds):
	for _i in range(int(seconds*60)):
		run.tick_visual(1.0/60)
		run.step(1.0/60,Vector2.ZERO)
		run.sounds.clear()

func ready_run():
	var run = quiet_run()
	run.player = Vector2(300,205)
	for x in [340,365,390]:
		var enemy = run.spawn_enemy(0,Vector2(x,218))
		enemy.hp = 1000
		enemy.speed = 0
	run.velocity = Vector2(500,0)
	run.grapple.state = "flying"
	run._move_player(.22,run.stats())
	run.grapple.release(run)
	return run

func test():
	var run = quiet_run()
	for _i in range(3):
		run.grapple.fire(run,Vector2.RIGHT)
		advance(run,.5)
	check(run.grapple.energy == 0 and run.grapple.bursts == 0,"safe empty-wall chains never generate a reward")

	run = quiet_run()
	var enemy = run.spawn_enemy(0,Vector2(350,218))
	enemy.speed = 0
	enemy.hp = 1000
	advance(run,.35)
	check(run.grapple.energy == 0,"standing near enemies generates no chain energy")
	run.velocity = Vector2(85,0)
	run._move_player(.65,run.stats())
	check(run.grapple.energy == 0,"walking past an enemy cannot farm chain energy")

	run = quiet_run()
	run.player = Vector2(300,205)
	enemy = run.spawn_enemy(0,Vector2(350,218))
	enemy.speed = 0
	enemy.hp = 1000
	run.grapple.state = "flying"
	run.velocity = Vector2(500,0)
	run._move_player(.22,run.stats())
	check(run.grapple.energy == 1 and run.hp == 100,"a fast near-pass earns energy without changing contact damage")
	check(enemy.hp == 1000 and run.invulnerable == 0,"a near-pass rewards danger without inventing a hit or invincibility")
	run.velocity = Vector2(-500,0)
	run._move_player(.22,run.stats())
	check(run.grapple.energy == 1,"the same surviving enemy cannot be farmed by swinging back and forth")

	run = quiet_run()
	enemy = run.spawn_enemy(0,Vector2(350,205))
	run.velocity = Vector2(500,0)
	run.grapple.state = "flying"
	run._move_player(.12,run.stats())
	check(not enemy.alive and run.grapple.energy == 1,"an enemy killed during a real rush still yields its one reward")

	run = quiet_run()
	enemy = run.spawn_enemy(1,Vector2(450,205))
	enemy.speed = 0
	enemy.hp = 1000
	run.grapple.fire(run,Vector2.RIGHT)
	advance(run,.8)
	check(run.grapple.arrival_rewards == 1 and run.grapple.energy >= 2,"actually arriving at a masked anchor earns the larger reward")
	run.grapple.fire(run,Geometry.ground(enemy.p-run.player).normalized())
	advance(run,.4)
	check(run.grapple.arrival_rewards == 1,"the same guardian cannot give repeated arrival rewards")

	run = ready_run()
	check(run.grapple.energy == 3 and run.grapple.bursts == 0,"three distinct fast near-passes arm the next chain, not a passive attack")
	check(run.stats().sword_damage == 26 and run.stats().fire_damage == 20,"earned chain energy changes no permanent weapon stats")
	var wide_target = run.spawn_enemy(0,Vector2(460,225))
	wide_target.speed = 0
	var guardian = run.spawn_enemy(1,Vector2(510,205))
	guardian.speed = 0
	run.grapple.fire(run,Vector2.RIGHT)
	check(run.grapple.energy == 3 and run.grapple.bursts == 0,"firing alone does not consume a reward before the hook connects")
	advance(run,.31)
	check(run.grapple.bursts == 1 and run.grapple.energy == 0,"a successful follow-up chain spends the full gauge once")
	check(not wide_target.alive,"the golden dash reaches enemies outside the ordinary body-contact width")
	check(not guardian.alive and run.heavy_shatters >= 2,"the earned attack shatters a real guardian and nearby crowd")
	check(run.grapple.cuts.size() > 0 and run.grapple.cuts.size() <= 24,"the real swept strike produces a bounded visible wake")
	advance(run,1)
	check(run.grapple.burst_left == 0 and run.grapple.cuts.is_empty(),"attack and wake both end instead of becoming a permanent aura")

	run = quiet_run()
	enemy = run.spawn_enemy(0,Vector2(350,205))
	enemy.hp = 1000
	enemy.speed = 0
	run.grapple.state = "flying"
	run.grapple.burst_left = .6
	run.velocity = Vector2(500,0)
	run._move_player(.16,run.stats())
	run.grapple.hit_ids.clear()
	run.velocity = Vector2(-500,0)
	run._move_player(.16,run.stats())
	check(enemy.hp == 910 and run.grapple.burst_hits.size() == 1,"retargeting within one golden attack cannot deal repeated damage to the same enemy")

	run = ready_run()
	enemy = run.spawn_enemy(1,Vector2(550,205))
	enemy.speed = 0
	run.grapple.fire(run,Vector2.RIGHT)
	advance(run,1.0/60)
	run._hurt_enemy(enemy,1000,Vector2.RIGHT,"sword",true)
	advance(run,1.0/60)
	check(run.grapple.energy == 3 and run.grapple.bursts == 0,"an anchor that dies before attachment does not waste the ready attack")

	run = ready_run()
	run.invulnerable = 0
	run.hurt_player(8,Vector2.RIGHT)
	check(run.hp == 92 and run.grapple.energy == 0 and run.grapple.energy_lost == 3,"actual damage costs HP and all accumulated chain energy")
	check(run.invulnerable == .78 and run.grapple.loss_reason == "被弾で消失","damage still grants the usual recovery window and a readable loss reason")

	run = ready_run()
	run.velocity = Vector2.ZERO
	run.grapple.release(run,false)
	advance(run,4.2)
	check(run.grapple.energy == 0 and run.grapple.bursts == 0,"standing still lets the earned gauge expire without automatic detonation")
	check(run.grapple.loss_reason == "鎖が途切れた","a broken chain has its own feedback")

	run = ready_run()
	run.grapple.energy = 1
	run.grapple.energy_left = .5
	run.grapple.fire(run,Vector2.RIGHT)
	advance(run,.15)
	check(run.grapple.energy == 1 and run.grapple.energy_left > 3.7,"another successful chain preserves partial energy for the next risk")
	var saved_energy = run.grapple.energy
	var saved_time = run.grapple.energy_left
	run.level_up()
	advance(run,1)
	check(run.grapple.energy == saved_energy and run.grapple.energy_left == saved_time,"an upgrade overlay neither consumes nor expires earned energy")
	run.choose(run.offers[0])
	check(run.phase == "playing" and run.grapple.energy == saved_energy,"the selected upgrade resumes with earned energy intact")

	run = ready_run()
	run.grapple.burst_left = .6
	run.invulnerable = 0
	run.hurt_player(13,Vector2.RIGHT)
	check(run.grapple.burst_left == 0 and run.hp == 87,"the earned attack is not full invincibility and ends on actual damage")

	run = quiet_run()
	run.player = Vector2(219,205)
	enemy = run.spawn_enemy(0,Vector2(219,124))
	enemy.speed = 0
	run.grapple.burst_left = .6
	run.grapple.state = "flying"
	run.velocity = Vector2(0,-700)
	run._move_player(.3,run.stats())
	check(enemy.alive and run.grapple.energy == 0,"blocked movement neither attacks nor earns rewards from enemies beyond masonry")

	print("CHAIN RISK CHECKS ",checks-failures,"/",checks," passed")
	quit(1 if failures > 0 else 0)
