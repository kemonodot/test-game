extends Control

const FONT = preload("res://assets/fonts/OborobiUI.otf")
const FIRE = preload("res://assets/art/soul_fire.png")
const RONIN = preload("res://assets/art/ronin.png")
const GOLD = Color("d1b78a")
const WHITE = Color("e1e0d7")
const MUTED = Color("93999e")
const BLUE = Color("8ac2d0")

var driver
var run
var modal: Control
var hp_text: Label
var timer_text: Label
var kills_text: Label
var level_text: Label
var weapon_text: Label
var xp_text: Label
var chapter_text: Label
var chain_text: Label
var pause_button: Button
var sound_button: Button
var choice_buttons = []
var current_panel = ""

func setup(owner_game):
	driver = owner_game
	run = driver.run
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme_asset = Theme.new()
	theme_asset.default_font = FONT
	theme_asset.default_font_size = 22
	theme = theme_asset
	hp_text = label("100 / 100",20,Rect2(350,25,160,32),WHITE)
	timer_text = label("03:00",34,Rect2(540,18,200,50),GOLD,HORIZONTAL_ALIGNMENT_CENTER)
	kills_text = label("討伐  000",19,Rect2(969,56,190,32),WHITE,HORIZONTAL_ALIGNMENT_RIGHT)
	level_text = label("Lv. 1",26,Rect2(999,18,160,38),GOLD,HORIZONTAL_ALIGNMENT_RIGHT)
	weapon_text = label("一閃 I     魂火 I",17,Rect2(94,57,350,30),BLUE)
	xp_text = label("灯  0 / 9",17,Rect2(1010,670,230,30),MUTED,HORIZONTAL_ALIGNMENT_RIGHT)
	chapter_text = label("第一刻 / 影が集う",16,Rect2(470,70,340,32),MUTED,HORIZONTAL_ALIGNMENT_CENTER)
	chain_text = label("ドラッグで狙う → 離して射出 / タップで解除",17,Rect2(347,658,590,34),BLUE,HORIZONTAL_ALIGNMENT_CENTER)
	pause_button = button("II",Rect2(1172,12,92,84),driver.toggle_pause)
	sound_button = button("音",Rect2(1172,106,92,74),driver.toggle_sound)
	var portrait = AtlasTexture.new()
	portrait.atlas = RONIN
	portrait.region = Rect2(0,0,32,32)
	var face = TextureRect.new()
	face.texture = portrait
	face.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	face.position = Vector2(22,19)
	face.size = Vector2(58,58)
	face.mouse_filter = MOUSE_FILTER_IGNORE
	add_child(face)
	modal = Control.new()
	modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal.mouse_filter = MOUSE_FILTER_IGNORE
	add_child(modal)
	show_intro()

func style(fill, border):
	var box = StyleBoxFlat.new()
	box.bg_color = fill
	box.border_color = border
	box.set_border_width_all(1)
	box.content_margin_left = 16
	box.content_margin_right = 16
	box.content_margin_top = 8
	box.content_margin_bottom = 8
	return box

func label(text_value, font_size, rect, color = WHITE, align = HORIZONTAL_ALIGNMENT_LEFT, parent = null):
	var control = Label.new()
	control.text = text_value
	control.position = rect.position
	control.size = rect.size
	control.add_theme_font_size_override("font_size",font_size)
	control.add_theme_color_override("font_color",color)
	control.add_theme_color_override("font_outline_color",Color("101621"))
	control.add_theme_constant_override("outline_size",2)
	control.horizontal_alignment = align
	control.mouse_filter = MOUSE_FILTER_IGNORE
	(parent if parent != null else self).add_child(control)
	return control

func button(text_value, rect, callback, parent = null):
	var control = Button.new()
	control.text = text_value
	control.position = rect.position
	control.size = rect.size
	control.add_theme_stylebox_override("normal",style(Color("151d29"),Color("77654e")))
	control.add_theme_stylebox_override("hover",style(Color("25313e"),GOLD))
	control.add_theme_stylebox_override("pressed",style(Color("314353"),BLUE))
	control.add_theme_stylebox_override("focus",style(Color(0,0,0,0),BLUE))
	control.add_theme_color_override("font_color",WHITE)
	control.pressed.connect(callback)
	(parent if parent != null else self).add_child(control)
	return control

func panel(rect, color):
	var control = Panel.new()
	control.position = rect.position
	control.size = rect.size
	control.add_theme_stylebox_override("panel",style(color,Color("695b4d")))
	control.mouse_filter = MOUSE_FILTER_IGNORE
	modal.add_child(control)
	return control

func clear_panel():
	choice_buttons.clear()
	for child in modal.get_children():
		# A button can be clearing its own panel from inside a GUI signal. Keep
		# it in the tree until deferred deletion, so Godot can finish that event.
		child.hide()
		child.queue_free()
	current_panel = ""

func dim(opacity = .68):
	var shade = ColorRect.new()
	shade.color = Color(.025,.037,.062,opacity)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = MOUSE_FILTER_STOP
	modal.add_child(shade)

func show_intro():
	clear_panel()
	current_panel = "menu"
	panel(Rect2(74,206,453,369),Color(.045,.069,.107,.94))
	label("OBOROBI / CHAIN PROTOTYPE 0.2",15,Rect2(108,229,380,30),GOLD,0,modal)
	label("朧 火",56,Rect2(105,268,330,90),WHITE,0,modal)
	label("夜明けまで、三分。",24,Rect2(110,367,350,42),GOLD,0,modal)
	label("鎖を放ち、刃と魂火で群れを砕く。\n敵と石垣を渡り、三分生き残る。",20,Rect2(110,416,366,64),WHITE,0,modal)
	button("境内へ入る",Rect2(108,504,382,54),driver.start_run,modal)
	label("ドラッグで狙う → 指を離すと鎖を射出",20,Rect2(76,618,770,40),WHITE,0,modal)
	label("タップで解除。攻撃は自動。魂を集めて強化。",17,Rect2(76,657,770,32),MUTED,0,modal)

func show_choices():
	clear_panel()
	current_panel = "upgrade"
	dim(.67)
	label("灯 を 継 ぐ",38,Rect2(290,137,700,60),GOLD,HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("LEVEL %02d  /  ひとつ選ぶと戦闘を再開" % run.level,18,Rect2(290,204,700,38),WHITE,HORIZONTAL_ALIGNMENT_CENTER,modal)
	for i in range(run.offers.size()):
		var id = run.offers[i]
		var upgrade = run.get_upgrade(id)
		var rect = Rect2(141+i*339,276,320,285)
		var card = button("",rect,driver.select_upgrade.bind(id),modal)
		card.set_meta("upgrade_id",id)
		choice_buttons.append(card)
		var color = BLUE if upgrade.tag.begins_with("魂火") else GOLD
		label(upgrade.tag,17,Rect2(23,20,275,31),color,0,card)
		label(upgrade.name,29,Rect2(22,72,280,58),WHITE,0,card)
		label(upgrade.desc,20,Rect2(23,143,277,75),MUTED,0,card)
		label("%d / %d  →  %d / %d" % [run.count(id),upgrade.max,run.count(id)+1,upgrade.max],17,Rect2(23,235,274,30),color,0,card)
		card.focus_mode = Control.FOCUS_ALL
	label("強化中は時間が止まります。",16,Rect2(390,589,500,40),MUTED,HORIZONTAL_ALIGNMENT_CENTER,modal)
	if not choice_buttons.is_empty(): choice_buttons[0].grab_focus()

func show_pause():
	clear_panel()
	current_panel = "paused"
	dim(.60)
	panel(Rect2(410,228,460,254),Color("121d2a"))
	label("ひと息",37,Rect2(450,254,380,62),GOLD,HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("画面を離れている間も、戦闘は停止します。",17,Rect2(420,333,440,40),MUTED,HORIZONTAL_ALIGNMENT_CENTER,modal)
	button("戦闘へ戻る",Rect2(450,398,380,60),driver.toggle_pause,modal).grab_focus()

func show_result():
	clear_panel()
	current_panel = run.phase
	dim(.72)
	panel(Rect2(379,149,522,427),Color("121b28"))
	var cleared = run.phase == "won"
	label("DAWN / CLEAR" if cleared else "FALLEN / RETRY",16,Rect2(430,174,420,32),BLUE if cleared else Color("cb8b79"),HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("夜 明 け" if cleared else "落 命",43,Rect2(430,224,420,70),GOLD,HORIZONTAL_ALIGNMENT_CENTER,modal)
	var seconds = int(run.time)
	label("生存  %02d:%02d     /     Lv. %d" % [seconds/60,seconds%60,run.level],23,Rect2(427,319,426,45),WHITE,HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("討伐  %d 体       回収した魂  %d" % [run.kills,run.souls_taken],21,Rect2(427,369,426,45),MUTED,HORIZONTAL_ALIGNMENT_CENTER,modal)
	var sword = run.count("edge")+run.count("reach")+run.count("cadence")
	var fire = run.count("ember")+run.count("barrage")+run.count("pierce")
	label("鎖 %d 射 / 接続 %d / 強襲 %d" % [run.grapple.shots,run.grapple.catches,run.grapple.rush_hits],18,Rect2(425,416,430,35),BLUE,HORIZONTAL_ALIGNMENT_CENTER,modal)
	label("刀の強化 %d / 魂火の強化 %d" % [sword,fire],16,Rect2(425,452,430,28),MUTED,HORIZONTAL_ALIGNMENT_CENTER,modal)
	button("もう一度、境内へ",Rect2(426,488,428,62),driver.start_run,modal).grab_focus()

func update_hud():
	run = driver.run
	hp_text.text = "%d / %d" % [ceil(run.hp),run.max_hp]
	var remaining = maxi(0,int(ceil(180-run.time)))
	timer_text.text = "%02d:%02d" % [remaining/60,remaining%60]
	kills_text.text = "討伐  %03d" % run.kills
	level_text.text = "Lv. %d" % run.level
	xp_text.text = "灯  %d / %d" % [run.xp,run.xp_needed]
	weapon_text.text = "一閃 %d     魂火 %d" % [1+run.count("edge")+run.count("reach")+run.count("cadence"),1+run.count("ember")+run.count("barrage")+run.count("pierce")]
	var chapter = mini(3,1+int(run.time/60))
	chapter_text.text = ["第一刻 / 影が集う","第二刻 / 鬼面が迫る","第三刻 / 夜明けは近い"][chapter-1]
	chapter_text.modulate.a = .85 if fmod(run.time,60) < 7 else .40
	sound_button.text = "音" if not driver.muted else "静"
	pause_button.disabled = run.phase != "playing"
	chain_text.visible = current_panel == "" and run.phase == "playing"
	if run.grapple.aiming:
		chain_text.text = "敵へ接続 / 離すと射出" if run.grapple.preview.kind == "enemy" else ("石垣へ接続 / 離すと射出" if run.grapple.preview.kind == "wall" else "射程外 / 方向を変える")
	elif run.grapple.state == "flying": chain_text.text = "鎖を射出中"
	elif run.grapple.state == "pulling": chain_text.text = "高速移動 / タップで鎖を外す"
	elif run.grapple.drift > 0 and run.velocity.length() > 25: chain_text.text = "慣性で滑走 / 次の鎖を狙える"
	else: chain_text.text = "ドラッグで狙う → 離して射出 / タップで解除"
	queue_redraw()

func _draw():
	if driver == null: return
	run = driver.run
	# Separate small panels preserve the torii lintel and the distant composition.
	draw_rect(Rect2(0,0,518,94),Color(.035,.052,.082,.89))
	draw_rect(Rect2(527,8,226,82),Color(.035,.052,.082,.73))
	draw_rect(Rect2(998,0,282,101),Color(.035,.052,.082,.78))
	draw_line(Vector2(18,92),Vector2(500,92),Color("76624d"),1)
	draw_rect(Rect2(18,16,67,67),Color("142336"))
	draw_rect(Rect2(18,16,67,67),Color("b19465"),false,1)
	draw_rect(Rect2(95,29,239,19),Color("302a32"))
	draw_rect(Rect2(97,31,235*clampf(run.hp/run.max_hp,0,1),15),Color("963f43"))
	draw_rect(Rect2(97,31,235*clampf(run.hp/run.max_hp,0,1),3),Color("c17465"))
	draw_rect(Rect2(95,29,239,19),Color("ac9269"),false,1)
	draw_rect(Rect2(0,708,1280,12),Color("172536"))
	draw_rect(Rect2(0,710,1280*clampf(float(run.xp)/run.xp_needed,0,1),8),Color("5293ab"))
	draw_rect(Rect2(0,709,1280*clampf(float(run.xp)/run.xp_needed,0,1),1),Color("a7d9da"))
	if current_panel == "" and run.phase == "playing":
		_draw_stick()

func _draw_stick():
	var origin = driver.stick_origin if driver.stick_active else Vector2(135,566)
	var center = driver.stick_pos if driver.stick_active else origin
	var opacity = .72 if driver.stick_active else .26
	var points = PackedVector2Array()
	for i in range(9):
		points.append(origin+Vector2.from_angle(i*TAU/8+PI/8)*65)
	draw_polyline(points,Color(.69,.76,.73,opacity),2,false)
	for offset in [Vector2(-7,-7),Vector2(7,-7),Vector2(7,7),Vector2(-7,7)]:
		draw_rect(Rect2(center+offset-Vector2(2,2),Vector2(4,4)),Color(.68,.82,.83,opacity))
	draw_line(origin,center,Color(.65,.8,.81,opacity),2,false)
	draw_rect(Rect2(center-Vector2(4,4),Vector2(8,8)),Color(.65,.8,.81,opacity),false,2)
