extends SceneTree
const Core = preload("res://scripts/combat.gd")
const Geometry = preload("res://scripts/arena_geometry.gd")
var checks = 0
var failures = 0

func _initialize():
	call_deferred("test")

func check(condition, description):
	checks += 1
	if condition: print("PASS ",description)
	else:
		failures += 1
		push_error("FAIL "+description)

func quiet_run():
	var run = Core.new(924)
	run.start()
	run.spawn_clock = 999
	run.sword_clock = 999
	run.fire_clock = 999
	return run

func advance(run, seconds):
	for _i in range(int(seconds*60)):
		run.tick_visual(1.0/60)
		run.step(1.0/60,Vector2.ZERO)

func test():
	var run = quiet_run()
	var target = run.grapple.acquire(run,Vector2.UP)
	check(target.kind == "wall" and absf(target.p.y-93) < .01,"aim finds the actual outer wall")
	run.grapple.fire(run,Vector2.UP)
	var origin = run.player
	var peak_speed = 0.0
	for _i in range(60):
		run.step(1.0/60,Vector2.ZERO)
		peak_speed = maxf(peak_speed,Core.ground_vector(run.velocity).length())
	check(run.grapple.wall_catches == 1 and run.player.y < origin.y-70,"chain connects and reels the player to the wall")
	check(peak_speed > 250,"grapple reaches a clearly higher speed than walking")
	check(run.player.y >= 93+6*.72-.03,"pull and drift preserve the player's boundary clearance")

	run = quiet_run()
	var enemy = run.spawn_enemy(1,Vector2(445,220))
	enemy.speed = 0
	enemy.hp = 1000
	target = run.grapple.acquire(run,Vector2.RIGHT)
	check(target.kind == "enemy" and target.enemy.id == enemy.id,"aim assist selects a slightly off-axis enemy")
	run.grapple.fire(run,Vector2.RIGHT)
	advance(run,.05)
	enemy.p += Vector2(13,6)
	advance(run,.05)
	check(run.grapple.target.p.distance_to(enemy.p) < .01,"the flying hook tracks its moving enemy anchor")
	advance(run,.17)
	check(run.grapple.enemy_catches == 1 and run.grapple.state == "pulling","the enemy anchor starts a pull")
	var velocity = run.velocity
	var position = run.player
	run.grapple.release(run)
	advance(run,.06)
	check(run.grapple.state == "idle" and run.player.distance_to(position) > 1,"manual release retains useful momentum")
	check(run.velocity.length() > 10 and run.velocity.length() < velocity.length(),"released momentum gradually decelerates")
	advance(run,.8)
	check(run.velocity.length() < 1,"drift ends instead of leaving perpetual sliding")

	run = quiet_run()
	enemy = run.spawn_enemy(1,Vector2(490,205))
	enemy.speed = 0
	run.grapple.fire(run,Vector2.RIGHT)
	advance(run,.32)
	run._hurt_enemy(enemy,10000,Vector2.RIGHT,"sword",true)
	advance(run,.02)
	check(run.grapple.state == "idle" and run.grapple.target.is_empty(),"dead enemy anchors immediately detach without stale references")

	run = quiet_run()
	run.player = Vector2(219,210)
	enemy = run.spawn_enemy(1,Vector2(219,120))
	target = run.grapple.acquire(run,Vector2.UP)
	check(target.kind == "wall" and absf(target.p.y-162) < .01,"masonry blocks aim assist from selecting an enemy behind it")
	var result = Geometry.move_slide(run.player,Vector2(0,-300))
	check(result.blocked and result.p.y >= 162+6*.72,"a very large step cannot tunnel through a thin wall")
	result = Geometry.move_slide(Vector2(320,205),Vector2(2000,0))
	check(result.blocked and result.p.x <= 582.01,"a very large step cannot escape the outer boundary")
	result = Geometry.move_slide(Vector2(150,200),Vector2(120,-70))
	check(not Geometry.ground_rect(Geometry.WALLS[0]).grow(5.99).has_point(Geometry.ground(result.p)),"diagonal sliding does not penetrate a wall corner")

	run = quiet_run()
	enemy = run.spawn_enemy(1,Vector2(385,205))
	enemy.hp = 1000
	enemy.speed = 0
	run.velocity = Vector2(2000,0)
	run.grapple.state = "pulling"
	run._move_player(.08,run.stats())
	check(run.player.x < 370 and enemy.hp < 1000 and run.grapple.rush_hits == 1,"a fast sweep hits a surviving enemy and stops before passing through it")
	check(run.grapple.state == "idle","a surviving blocking enemy releases the pull")
	run = quiet_run()
	run.spawn_enemy(1,run.player)
	var trapped_start = run.player
	run.velocity = Vector2(100,0)
	run._move_player(.05,run.stats())
	check(run.player.x > trapped_start.x+3,"an overlapping enemy never traps the player against every escape direction")

	run = quiet_run()
	var near = run.spawn_enemy(1,Vector2(390,205))
	var far = run.spawn_enemy(1,Vector2(490,205))
	near.speed = 0
	far.speed = 0
	check(run.grapple.acquire(run,Vector2.RIGHT).enemy.id == near.id,"an assisted shot selects the first enemy body along its path")
	run = quiet_run()
	run.spawn_enemy(1,Vector2(400,210))
	run.spawn_enemy(1,Vector2(500,205))
	var first_body = run.spawn_enemy(1,Vector2(370,211))
	check(run.grapple.acquire(run,Vector2.RIGHT).enemy.id == first_body.id,"interception order stays correct when targets have different off-axis angles")
	run = quiet_run()
	run.grapple.fire(run,Vector2.RIGHT)
	advance(run,.05)
	enemy = run.spawn_enemy(1,Vector2(406,205))
	enemy.speed = 0
	advance(run,.07)
	check(run.grapple.enemy_catches == 1 and run.grapple.target.enemy.id == enemy.id,"an enemy moving into a flying wall shot intercepts the hook")

	run = quiet_run()
	enemy = run.spawn_enemy(1,Vector2(608,205))
	check(run.grapple.acquire(run,Vector2.RIGHT).kind == "wall","the outer boundary blocks an enemy anchor outside the playable floor")

	run = quiet_run()
	run.player = Vector2(219,180)
	enemy = run.spawn_enemy(0,Vector2(219,140))
	run.sword_attack()
	check(enemy.hp == enemy.max_hp,"automatic sword cannot damage through masonry")

	run = quiet_run()
	run.player = Vector2(219,205)
	enemy = run.spawn_enemy(1,Vector2(219,124))
	advance(run,5)
	check(enemy.p.y > 166 and Core.ground_vector(enemy.p-run.player).length() < 50,"pursuing enemies route around a wall instead of getting stuck")

	# Same 180-second combat, HP and upgrades as the player. No invulnerability.
	var summaries = []
	for seed_value in [7319,23,81]:
		run = Core.new(seed_value)
		run.start()
		var shot_clock = 0.0
		var course = 0
		var destinations = [Vector2(95,292),Vector2(551,292),Vector2(551,116),Vector2(95,116)]
		for _i in range(260*60):
			run.tick_visual(1.0/60)
			if run.phase == "upgrade":
				var priorities = ["reach","edge","barrage","cadence","ward","ember","mending","stride","pierce","magnet"]
				if run.hp < run.max_hp*.6: priorities = ["ward","mending"]+priorities
				for id in priorities:
					if run.offers.has(id):
						run.choose(id)
						break
			if run.phase in ["won","lost"]: break
			if run.phase != "playing": continue
			shot_clock -= 1.0/60
			if shot_clock <= 0:
				if Core.ground_vector(destinations[course%4]-run.player).length() < 68: course += 1
				run.grapple.fire(run,Core.ground_vector(destinations[course%4]-run.player).normalized())
				shot_clock = 1.0
			run.step(1.0/60,Vector2.ZERO)
			run.sounds.clear()
		check(run.phase in ["won","lost"] and run.grapple.catches > 15 and run.level >= 3,"grapple combat finishes a full run with growth, seed "+str(seed_value))
		check(run.peak_enemies <= Core.MAX_ENEMIES and run.peak_particles <= Core.MAX_PARTICLES and run.grapple.trail.size() <= 9,"grapple combat respects mobile object budgets, seed "+str(seed_value))
		summaries.append({"seed":seed_value,"result":run.phase,"seconds":run.time,"kills":run.kills,"level":run.level,"shots":run.grapple.shots,"enemy_catches":run.grapple.enemy_catches,"wall_catches":run.grapple.wall_catches,"rush_hits":run.grapple.rush_hits,"peak_enemies":run.peak_enemies,"peak_particles":run.peak_particles})
	print("GRAPPLE RUNS ",JSON.stringify(summaries))
	print("GRAPPLE CHECKS ",checks-failures,"/",checks," passed")
	quit(1 if failures > 0 else 0)
