extends SceneTree
## Capture actual gameplay. --demo only supplies normal gestures and card choices.
const Scene = preload("res://main.tscn")
var game
var frames = 0
var finishing = false

func _initialize():
	root.size = Vector2i(1280,720)
	call_deferred("begin")

func begin():
	game = Scene.instantiate()
	root.add_child(game)
	process_frame.connect(record_frame)

func record_frame():
	frames += 1
	if not finishing and (frames >= 1800 or game.run.phase in ["won","lost"]):
		finishing = true
		game._save_metrics()
		game._quit_cleanly()
