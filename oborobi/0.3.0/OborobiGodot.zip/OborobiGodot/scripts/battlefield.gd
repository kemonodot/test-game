extends Node2D
## Everything in this viewport is 640x360, nearest-filtered and pixel-snapped.
## Enemies/projectiles/particles are data, not hundreds of scene-tree nodes.

const ARENA = preload("res://assets/art/arena.png")
const RONIN = preload("res://assets/art/ronin.png")
const RONIN_FLASH = preload("res://assets/art/ronin_flash.png")
const ASHIGARU = preload("res://assets/art/ashigaru.png")
const ASHIGARU_FLASH = preload("res://assets/art/ashigaru_flash.png")
const GUARDIAN = preload("res://assets/art/guardian.png")
const GUARDIAN_FLASH = preload("res://assets/art/guardian_flash.png")
const FIRE = preload("res://assets/art/soul_fire.png")
const Geometry = preload("res://scripts/arena_geometry.gd")
const DIGITS = ["111101101101111","010110010010111","111001111100111","111001111001111","101101111001001","111100111001111","111100111101111","111001001001001","111101111101111","111101111001111"]

var run

func _process(_dt):
	if run == null: return
	position = Vector2(sin(run.visual_time*103),cos(run.visual_time*87))*run.shake
	position = position.round()
	queue_redraw()

func _draw():
	if run == null: return
	draw_texture(ARENA,Vector2.ZERO)
	_draw_boundary()
	for lamp in [Vector2(83,177),Vector2(393,81),Vector2(547,154),Vector2(565,287)]:
		if int(run.visual_time*6+lamp.x)%3 == 0:
			draw_rect(Rect2(lamp+Vector2(-2,0),Vector2(2,4)),Color("ffe0a0"))
	for stain in run.stains:
		var c = Color("4f303b") if stain.kind == 0 else Color("3a3545")
		var seed_value = stain.seed
		for i in range(5):
			var offset = Vector2((seed_value+i*7)%17-8,(seed_value+i*3)%7-3)
			draw_rect(Rect2((stain.p+offset).round(),Vector2(2+(i%3),1)),c)
	for soul in run.souls:
		var p = (soul.p-Vector2(0,3+sin(soul.age*4)*1.2)).round()
		draw_rect(Rect2(p+Vector2(-3,-1),Vector2(7,3)),Color("1e3a55"))
		draw_rect(Rect2(p+Vector2(-1,-3),Vector2(3,7)),Color("477f9e"))
		draw_rect(Rect2(p+Vector2(-2,-1),Vector2(5,3)),Color("65b2c4"))
		draw_rect(Rect2(p,Vector2.ONE),Color("cef1e5"))
		if soul.value >= 3:
			draw_rect(Rect2(p+Vector2(-1,-5),Vector2(2,1)),Color("b6e9df"))
	for ring in run.rings:
		var progress = 1-ring.life/ring.total
		var radius = 6+ring.size*progress
		for i in range(24):
			if progress > .6 and i%2 == 0: continue
			var p = ring.p+Vector2(cos(i*TAU/24)*radius,sin(i*TAU/24)*radius*.72)
			var color = ring.color
			color.a = minf(1,ring.life/ring.total*1.7)
			draw_rect(Rect2(p.round(),Vector2(2,1)),color)
	_draw_burning_trail()
	var actors = []
	for wall in Geometry.WALLS:
		actors.append({"p":Vector2(wall.get_center().x,wall.end.y),"wall":wall})
	for point in run.grapple.trail:
		var direction = run._direction(point.direction)
		draw_texture_rect_region(RONIN_FLASH,Rect2(point.p-Vector2(16,29),Vector2(32,32)),Rect2(64,direction*32,32,32),Color(.35,.67,.76,point.life*1.5))
	for e in run.enemies:
		if e.alive: actors.append({"p":e.p,"e":e,"hero":false})
	if run.phase not in ["dying","lost"]:
		actors.append({"p":run.player,"hero":true})
	actors.sort_custom(func(a,b): return a.p.y < b.p.y)
	for actor in actors:
		if actor.has("wall"):
			_draw_wall(actor.wall)
			continue
		var p = actor.p.round()
		# Pixelated contact shadow, with feet exactly at actor.p.
		draw_rect(Rect2(p+Vector2(-10,-2),Vector2(20,3)),Color(0.04,.07,.11,.65))
		draw_rect(Rect2(p+Vector2(-7,-3),Vector2(14,5)),Color(0.04,.07,.11,.55))
		var texture
		var frame = 0
		var direction = 0
		if actor.hero:
			direction = run._direction(run.facing)
			frame = int(run.time*9)%4 if run.velocity.length_squared() > 10 else 0
			texture = RONIN_FLASH if run.invulnerable > .67 else RONIN
			if run.grapple.state == "pulling": frame = 2
			if run.invulnerable > 0 and int(run.visual_time*16)%3 == 0: continue
			# A very small four-point marker makes the dark coat easy to locate.
			for offset in [Vector2(-12,0),Vector2(12,0),Vector2(0,4)]:
				draw_rect(Rect2(p+offset,Vector2(2,1)),Color("79b5bb"))
		else:
			var e = actor.e
			direction = e.direction
			frame = int(e.walk)%4
			if e.kind == 0: texture = ASHIGARU_FLASH if e.flash > 0 else ASHIGARU
			else: texture = GUARDIAN_FLASH if e.flash > 0 else GUARDIAN
			if e.kind == 1 and Geometry.FLOOR.has_point(e.p):
				# Only the large masked enemies bear the hookable bronze seal.
				var seal = p-Vector2(0,33)
				draw_rect(Rect2(seal-Vector2(3,2),Vector2(7,5)),Color("192630"))
				draw_rect(Rect2(seal-Vector2(2,1),Vector2(5,3)),Color("d1b787"),false,1)
		var lean = run.facing.x*.14 if actor.hero and run.velocity.length() > 145 else 0.0
		draw_set_transform(p,lean)
		draw_texture_rect_region(texture,Rect2(Vector2(-16,-29),Vector2(32,32)),Rect2(frame*32,direction*32,32,32))
		draw_set_transform(Vector2.ZERO)
	_draw_chain()
	_draw_arts()
	for slash in run.slashes:
		_draw_slash(slash)
	for b in run.bullets:
		for i in range(b.trail.size()):
			var c = Color("67bad0") if i < 2 else Color("285777")
			c.a = .9-i*.13
			draw_rect(Rect2((b.trail[i]+Vector2(-1,-2)).round(),Vector2(3 if i < 2 else 2,2)),c)
		var frame = int(run.visual_time*12)%4
		draw_texture_rect_region(FIRE,Rect2(b.p.round()-Vector2(8,12),Vector2(16,16)),Rect2(frame*16,0,16,16))
	for p in run.particles:
		var c = p.color
		var fraction = p.life/p.total
		c.a = 1.0 if fraction > .35 else (0.66 if fraction > .15 else .3)
		var size_px = p.size if fraction > .25 else 1
		draw_rect(Rect2(p.p.round(),Vector2(size_px,size_px)),c)
	for n in run.numbers:
		_draw_number(n)
	# A handful of square petals at the borders; never a particle curtain.
	for i in range(12):
		var x = fmod(i*53.0+run.visual_time*(3+i%3),640)
		var y = 57+sin(run.visual_time*.65+i*2.1)*6 if i%2 == 0 else 334+sin(run.visual_time*.5+i)*5
		draw_rect(Rect2(Vector2(x,y).round(),Vector2(2,1)),Color("91556a"))

func _draw_burning_trail():
	for burn in run.skills.burns:
		var p = burn.p.round()
		var fresh = burn.life > .24
		var phase = (int(run.visual_time*15)+burn.seed)%4
		var height = 5+phase+(burn.seed%3)
		draw_rect(Rect2(p+Vector2(-5,-2),Vector2(11,4)),Color(.12,.28,.42,.55 if fresh else .28))
		draw_rect(Rect2(p+Vector2(-3,-height+2),Vector2(6,height)),Color("376d95") if fresh else Color("29485f"))
		draw_rect(Rect2(p+Vector2(-1,-height),Vector2(3,height+1)),Color("78c9dc") if fresh else Color("477f96"))
		draw_rect(Rect2(p+Vector2(-1,-4),Vector2(2,4)),Color("d8f4df") if fresh else Color("639aab"))
		if phase%2 == 0 and fresh:
			draw_rect(Rect2(p+Vector2(2,-height-3),Vector2.ONE),Color("8bd6e1"))

func _draw_arts():
	if run.count("orbit_blades") > 0 and run.phase not in ["dying","lost"]:
		for i in range(3):
			var angle = run.skills.orbit_angle+i*TAU/3
			for j in range(4):
				var p = run.player+Geometry.project(Vector2.from_angle(angle-j*.13)*40)-Vector2(0,10)
				draw_rect(Rect2(p.round(),Vector2(2,1)),Color(.45,.70,.76,.72-j*.14))
			var center = run.player+Geometry.project(Vector2.from_angle(angle)*40)-Vector2(0,10)
			var tangent = Geometry.project(Vector2.from_angle(angle+PI/2)).normalized()
			var side = Vector2(-tangent.y,tangent.x)
			var hilt = center-tangent*7
			var point = center+tangent*9
			draw_line(hilt.round(),point.round(),Color("1b344a"),5,false)
			draw_line(center.round(),point.round(),Color("78c3d3"),3,false)
			draw_line((center+side).round(),point.round(),Color("edf1d4"),1,false)
			draw_line(hilt.round(),(center-tangent*2).round(),Color("9b785d"),2,false)
			draw_line((center-tangent*2-side*3).round(),(center-tangent*2+side*3).round(),Color("d3b77f"),1,false)
	for effect in run.skills.effects:
		var progress = 1-effect.life/effect.total
		if effect.kind == "lightning":
			for segment in range(effect.points.size()-1):
				var start = effect.points[segment]-Vector2(0,12)
				var end = effect.points[segment+1]-Vector2(0,12)
				var side = (end-start).orthogonal().normalized()
				var points = PackedVector2Array([start.round()])
				var steps = maxi(3,int(start.distance_to(end)/7))
				for j in range(1,steps):
					var kink = sin(j*2.1+effect.seed*1.7+segment)*4
					points.append((start.lerp(end,float(j)/steps)+side*kink).round())
				points.append(end.round())
				draw_polyline(points,Color("356884") if progress < .6 else Color("264457"),3,false)
				draw_polyline(points,Color("e5f5dc") if progress < .6 else Color("83c9d4"),1,false)
				for direction in [Vector2.RIGHT,Vector2.DOWN]:
					draw_line((end-direction*3).round(),(end+direction*3).round(),Color("e6d498"),1,false)
		elif effect.kind == "petals":
			var radius = 12+82*progress
			var center = effect.p-Vector2(0,10)
			for i in range(8):
				var angle = i*TAU/8+progress*.2
				var leading = center+Geometry.project(Vector2.from_angle(angle)*radius)
				var left = center+Geometry.project(Vector2.from_angle(angle-.14)*(radius-15))
				var inner = center+Geometry.project(Vector2.from_angle(angle)*(radius-28))
				var right = center+Geometry.project(Vector2.from_angle(angle+.14)*(radius-15))
				var outline = PackedVector2Array([inner.round(),left.round(),leading.round(),right.round(),inner.round()])
				draw_polyline(outline,Color("cc95ad") if progress < .72 else Color("83647d"),2,false)
				draw_line(left.round(),leading.round(),Color("f2ddcc") if progress < .72 else Color("b391a5"),1,false)
				draw_rect(Rect2(leading.round(),Vector2(2,2)),Color("e0c58e"))
				if progress < .7:
					var mote = center+Geometry.project(Vector2.from_angle(angle+.10)*(radius+6))
					draw_rect(Rect2(mote.round(),Vector2(2,1)),Color("d2a7bb"))

func _draw_slash(slash):
	var progress = 1-slash.life/slash.total
	var start = slash.angle-1.04+maxf(0,progress-.55)*1.5
	var end = slash.angle-1.04+2.08*minf(1,progress*3.6)
	if end <= start: return
	var radius = slash.radius
	var width = 7.0+radius*.045
	var ribbon = PackedVector2Array()
	for i in range(25):
		var angle = lerpf(start,end,i/24.0)
		var middle = (slash.p+Vector2(cos(angle)*(radius-width*.5),sin(angle)*(radius-width*.5)*.72)-Vector2(0,10)).round()
		if ribbon.is_empty() or ribbon[-1] != middle: ribbon.append(middle)
	# Thick pixel-snapped strips avoid degenerate concave polygons at the first
	# and final frames of the slash. The white boundary is the real attack range.
	if ribbon.size() >= 2:
		draw_polyline(ribbon,Color("284868") if progress < .65 else Color("20394f"),width,false)
	var previous = Vector2.ZERO
	for i in range(37):
		var angle = lerpf(start,end,i/36.0)
		var point = (slash.p+Vector2(cos(angle)*radius,sin(angle)*radius*.72)-Vector2(0,10)).round()
		if i > 0:
			draw_line(previous,point,Color("63acc8"),3,false)
			draw_line(previous,point,Color("e1edda") if progress < .68 else Color("88b8c5"),1,false)
		previous = point
	var tip = (slash.p+Vector2(cos(end)*radius,sin(end)*radius*.72)-Vector2(0,10)).round()
	var tip_back = (slash.p+Vector2(cos(end)*(radius-12),sin(end)*(radius-12)*.72)-Vector2(0,10)).round()
	draw_line(tip_back,tip,Color("f8efd2"),2,false)

func _draw_number(n):
	var origin = n.p.round()-Vector2(n.text.length()*2,0)
	var color = Color("ead6a3") if n.strong else Color("e0ddd0")
	color.a = minf(1,n.life*4)
	for i in range(n.text.length()):
		var digit = int(n.text[i])
		for y in range(5):
			for x in range(3):
				if DIGITS[digit][y*3+x] == "1":
					var at = origin+Vector2(i*4+x,y)
					draw_rect(Rect2(at+Vector2(1,1),Vector2.ONE),Color("151c2a"))
					draw_rect(Rect2(at,Vector2.ONE),color)

func _draw_boundary():
	var bounds = Geometry.FLOOR
	# Low, chipped curb stones, with bronze attachment pins. No debug outline.
	for i in range(25):
		for y in [bounds.position.y,bounds.end.y]:
			var x = bounds.position.x+i*22
			var width = minf(20,bounds.end.x-x)
			if width < 1: continue
			draw_rect(Rect2(x,y-2,width,4),Color("2b343a"))
			draw_rect(Rect2(x+1,y-3,width-1,2),Color("48464a"))
			draw_rect(Rect2(x+3,y-3,4,1),Color("626055"))
	for i in range(15):
		for x in [bounds.position.x,bounds.end.x]:
			var y = bounds.position.y+i*16
			var height = minf(14,bounds.end.y-y)
			if height < 1: continue
			draw_rect(Rect2(x-2,y,4,height),Color("303a3e"))
			draw_rect(Rect2(x-2,y+1,1,height-1),Color("565453"))
	for i in range(9):
		for y in [bounds.position.y,bounds.end.y]:
			var p = Vector2(bounds.position.x+i*bounds.size.x/8,y).round()
			draw_rect(Rect2(p-Vector2(3,3),Vector2(7,4)),Color("263338"))
			draw_rect(Rect2(p-Vector2(2,3),Vector2(5,1)),Color("796e54"))
			draw_rect(Rect2(p-Vector2(0,2),Vector2(1,2)),Color("8ba8a8"))
	for i in range(1,5):
		for x in [bounds.position.x,bounds.end.x]:
			var p = Vector2(x,bounds.position.y+i*bounds.size.y/5).round()
			draw_rect(Rect2(p-Vector2(2,3),Vector2(5,6)),Color("303b3d"))
			draw_rect(Rect2(p-Vector2(1,2),Vector2(1,4)),Color("7dacae"))

func _draw_wall(rect):
	# Two courses of chipped stone, a projecting cap and inset chain rings.
	draw_rect(Rect2(rect.position+Vector2(-3,rect.size.y-2),Vector2(rect.size.x+6,5)),Color(0.02,.035,.06,.60))
	draw_rect(Rect2(rect.position-Vector2(0,12),rect.size),Color("424449"))
	for row in range(3):
		for i in range(8):
			var x = rect.position.x+i*10+(3 if row%2 else 0)
			var width = minf(9,rect.end.x-x)
			if width < 1: continue
			var y = rect.position.y-11+row*4
			draw_rect(Rect2(x,y,width,3),Color("4b494d") if (row+i)%3 else Color("555054"))
			draw_rect(Rect2(x+1,y,width-1,1),Color("635b52"))
	draw_rect(Rect2(Vector2(rect.position.x,rect.end.y-12),Vector2(rect.size.x,12)),Color("272f37"))
	for row in range(3):
		var offset = 5 if row%2 == 1 else 0
		for i in range(7):
			var x = rect.position.x+i*12-offset
			var width = minf(11,rect.end.x-x)
			if x < rect.position.x:
				width -= rect.position.x-x
				x = rect.position.x
			if width < 1: continue
			var y = rect.end.y-11+row*4
			draw_rect(Rect2(x,y,width,3),Color("3b3f44") if (i+row)%3 != 0 else Color("454347"))
			draw_rect(Rect2(x+1,y,width-1,1),Color("57514d") if row == 0 else Color("44444a"))
	draw_line(rect.position-Vector2(1,12),Vector2(rect.end.x+1,rect.position.y-12),Color("736958"),1,false)
	for x in [rect.position.x+8,rect.end.x-9]:
		var p = Vector2(x,rect.end.y-8)
		draw_rect(Rect2(p-Vector2(2,2),Vector2(5,5)),Color("152731"))
		draw_rect(Rect2(p-Vector2(1,1),Vector2(3,3)),Color("74adb3"),false,1)
	draw_rect(Rect2(rect.position+Vector2(5,-10),Vector2(14,1)),Color("4d5861"))

func _draw_chain():
	var chain = run.grapple
	var hand = run.player-Vector2(0,12)+Geometry.project(run.facing*5)
	if chain.aiming and not chain.preview.is_empty():
		var target = chain.preview.p-Vector2(0,10)
		var color = Color("dec087") if chain.preview.kind == "enemy" else Color("91cbd1")
		if chain.preview.kind == "miss": color = Color("77838b")
		var count = maxi(1,int(hand.distance_to(target)/8))
		for i in range(count):
			if i%2 == 0:
				var p = hand.lerp(target,float(i)/count).round()
				draw_rect(Rect2(p,Vector2(2,1)),Color(color,.68))
		var corners = PackedVector2Array([target+Vector2(0,-7),target+Vector2(7,0),target+Vector2(0,7),target+Vector2(-7,0),target+Vector2(0,-7)])
		draw_polyline(corners,color,1,false)
		draw_rect(Rect2(target-Vector2(1,1),Vector2(3,3)),color)
	if chain.state not in ["flying","pulling"]: return
	var tip = chain.tip-Vector2(0,10)
	var direction = (tip-hand).normalized()
	var side = Vector2(-direction.y,direction.x)
	var links = maxi(1,int(hand.distance_to(tip)/5))
	for i in range(links+1):
		var p = hand.lerp(tip,float(i)/links).round()
		var segment = direction*2.5 if i%2 == 0 else side*1.2
		draw_line((p-segment+Vector2(0,1)).round(),(p+segment+Vector2(0,1)).round(),Color("172631"),3,false)
		draw_line((p-segment).round(),(p+segment).round(),Color("b9bba6") if i%3 else Color("8ec3ca"),1,false)
	var back = tip-direction*6
	draw_line(back.round(),tip.round(),Color("e0dcc2"),2,false)
	draw_line(tip.round(),(tip-direction*3+side*3).round(),Color("96cbd2"),1,false)
	draw_line(tip.round(),(tip-direction*3-side*3).round(),Color("96cbd2"),1,false)
	if chain.state == "pulling":
		var pulse = 3+int(run.visual_time*12)%3
		draw_rect(Rect2(tip-Vector2(pulse,pulse),Vector2(pulse*2+1,pulse*2+1)),Color(.58,.83,.84,.72),false,1)
