extends RefCounted
## Collision is evaluated in floor space, then projected back to the pixel view.
const FLOOR = Rect2(56,93,532,228)
const WALLS = [Rect2(181,149,76,13), Rect2(405,242,76,13)]

static func ground(p):
	return Vector2(p.x,p.y/.72)

static func project(p):
	return Vector2(p.x,p.y*.72)

static func ground_rect(rect):
	return Rect2(ground(rect.position),Vector2(rect.size.x,rect.size.y/.72))

static func segment_rect(origin, delta, rect):
	var entry = 0.0
	var exit_time = 1.0
	var normal = Vector2.ZERO
	for axis in range(2):
		if absf(delta[axis]) < .00001:
			if origin[axis] < rect.position[axis] or origin[axis] > rect.end[axis]: return {}
			continue
		var a = (rect.position[axis]-origin[axis])/delta[axis]
		var b = (rect.end[axis]-origin[axis])/delta[axis]
		var near_time = minf(a,b)
		if near_time >= entry:
			entry = near_time
			normal = Vector2.ZERO
			normal[axis] = -1.0 if delta[axis] > 0 else 1.0
		exit_time = minf(exit_time,maxf(a,b))
		if entry > exit_time: return {}
	if exit_time < 0 or entry > 1: return {}
	return {"t":maxf(0,entry),"normal":normal}

static func first_wall(start, finish, radius = 0.0, boundary = true):
	var origin = ground(start)
	var delta = ground(finish-start)
	var best = {"hit":false,"t":1.0,"p":finish,"normal":Vector2.ZERO,"wall":-1}
	for i in range(WALLS.size()):
		var hit = segment_rect(origin,delta,ground_rect(WALLS[i]).grow(radius))
		if not hit.is_empty() and hit.t <= best.t:
			best = {"hit":true,"t":hit.t,"p":project(origin+delta*hit.t),"normal":hit.normal,"wall":i}
	if boundary:
		var bounds = ground_rect(FLOOR).grow(-radius)
		for axis in range(2):
			if absf(delta[axis]) < .00001: continue
			var edge = bounds.end[axis] if delta[axis] > 0 else bounds.position[axis]
			var t = (edge-origin[axis])/delta[axis]
			if t >= -.00001 and t <= best.t:
				var normal = Vector2.ZERO
				normal[axis] = -1.0 if delta[axis] > 0 else 1.0
				best = {"hit":true,"t":maxf(0,t),"p":project(origin+delta*maxf(0,t)),"normal":normal,"wall":-1}
	return best

static func clear_line(start, finish, radius = 0.0):
	var hit = first_wall(start,finish,radius,false)
	return not hit.hit or hit.t > .995

static func resolve(start, radius, boundary):
	var p = ground(start)
	if boundary:
		var bounds = ground_rect(FLOOR).grow(-radius)
		p = p.clamp(bounds.position,bounds.end)
	for wall in WALLS:
		var rect = ground_rect(wall).grow(radius)
		if not rect.has_point(p): continue
		var distances = [p.x-rect.position.x,rect.end.x-p.x,p.y-rect.position.y,rect.end.y-p.y]
		var closest = distances.find(distances.min())
		if closest == 0: p.x = rect.position.x-.02
		elif closest == 1: p.x = rect.end.x+.02
		elif closest == 2: p.y = rect.position.y-.02
		else: p.y = rect.end.y+.02
	return project(p)

static func move_slide(start, displacement, radius = 6.0, boundary = true):
	var p = resolve(start,radius,boundary)
	var remaining = ground(displacement)
	var normals = []
	for _i in range(3):
		if remaining.length_squared() < .000001: break
		var hit = first_wall(p,p+project(remaining),radius,boundary)
		if not hit.hit:
			p += project(remaining)
			break
		var safe_time = maxf(0,hit.t-.025/maxf(.025,remaining.length()))
		p += project(remaining*safe_time)
		remaining *= 1.0-hit.t
		var into = remaining.dot(hit.normal)
		if into < 0: remaining -= hit.normal*into
		normals.append(hit.normal)
	return {"p":resolve(p,radius,boundary),"normals":normals,"blocked":not normals.is_empty()}

static func waypoint(start, finish, radius = 7.0):
	var hit = first_wall(start,finish,radius,false)
	if not hit.hit: return finish
	var rect = WALLS[hit.wall]
	var corners = ground_rect(rect).grow(radius+3.0)
	var best = finish
	var score = INF
	for corner in [corners.position,Vector2(corners.end.x,corners.position.y),corners.end,Vector2(corners.position.x,corners.end.y)]:
		var point = project(corner)
		if not clear_line(start,point,radius): continue
		var cost = ground(point-start).length()+ground(finish-point).length()
		if not clear_line(point,finish,radius): cost += 35
		if cost < score:
			score = cost
			best = point
	return best

static func segment_circle(start, finish, center, radius):
	var origin = ground(start-center)
	var delta = ground(finish-start)
	var a = delta.length_squared()
	if origin.length_squared() <= radius*radius: return 0.0
	if a < .000001: return -1.0
	var b = 2*origin.dot(delta)
	var c = origin.length_squared()-radius*radius
	var discriminant = b*b-4*a*c
	if discriminant < 0: return -1.0
	var t = (-b-sqrt(discriminant))/(2*a)
	return t if t >= 0 and t <= 1 else -1.0
