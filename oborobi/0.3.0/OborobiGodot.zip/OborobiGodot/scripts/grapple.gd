extends RefCounted
## One chain. No rigid-body rope simulation or per-link scene nodes.
const Geometry = preload("res://scripts/arena_geometry.gd")
const RANGE = 620.0
const SPEED = 510.0
const SHOT_SPEED = 2100.0
const ASSIST_ANGLE = .32

var state = "idle"
var target = {}
var tip = Vector2.ZERO
var preview = {}
var aiming = false
var aim_direction = Vector2.RIGHT
var flight = 0.0
var clock = 0.0
var cooldown = 0.0
var drift = 0.0
var trail = []
var trail_clock = 0.0
var hit_ids = []
var shots = 0
var catches = 0
var enemy_catches = 0
var wall_catches = 0
var rush_hits = 0
var releases = 0
var flow = 0
var flow_grace = 0.0
var best_flow = 0

func can_anchor(enemy):
	return enemy.alive and enemy.kind == 1 and Geometry.FLOOR.has_point(enemy.p)

func acquire(run, direction):
	var forward = direction.normalized()
	var finish = run.player+Geometry.project(forward*RANGE)
	var wall = Geometry.first_wall(run.player,finish)
	var selection = {"kind":"wall" if wall.hit else "miss","p":wall.p,"enemy":null,"wall":wall.wall}
	var best_score = INF
	for enemy in run.enemies:
		if not can_anchor(enemy): continue
		var diff = Geometry.ground(enemy.p-run.player)
		var distance = diff.length()
		if distance < 23 or distance > RANGE: continue
		var angle = absf(angle_difference(forward.angle(),diff.angle()))
		if angle > ASSIST_ANGLE: continue
		var obstruction = Geometry.first_wall(run.player,enemy.p)
		if obstruction.hit and obstruction.t < .995: continue
		var score = angle*330+distance*.15
		if score < best_score:
			best_score = score
			selection = {"kind":"enemy","p":enemy.p,"enemy":enemy,"wall":-1}
	# Small enemies never catch or interrupt the chain.
	var closest = 1.01
	var shot_end = selection.p
	for enemy in run.enemies:
		if not can_anchor(enemy): continue
		if Geometry.ground(enemy.p-run.player).dot(Geometry.ground(shot_end-run.player)) <= 0: continue
		var t = Geometry.segment_circle(run.player,shot_end,enemy.p,8.0 if enemy.kind == 0 else 10.0)
		if t >= 0 and t < closest:
			closest = t
			selection = {"kind":"enemy","p":enemy.p,"enemy":enemy,"wall":-1}
	return selection

func set_aim(run, direction):
	aiming = true
	aim_direction = direction.normalized()
	preview = acquire(run,aim_direction)

func fire(run, direction):
	if run.phase != "playing" or cooldown > 0: return false
	if state != "idle": release(run)
	target = acquire(run,direction)
	tip = run.player
	flight = 0
	clock = 0
	state = "flying"
	cooldown = .055
	drift = .65
	hit_ids.clear()
	shots += 1
	run.facing = Geometry.ground(target.p-run.player).normalized()
	run._sound("chain_throw")
	return true

func release(run, preserve_velocity = true):
	if state != "idle": releases += 1
	state = "idle"
	target = {}
	drift = .62 if preserve_velocity else 0.0
	if not preserve_velocity: run.velocity = Vector2.ZERO

func cancel(run):
	aiming = false
	preview = {}
	release(run,false)
	trail.clear()
	flow = 0
	flow_grace = 0

func advance(run, dt, movement):
	cooldown = maxf(0,cooldown-dt)
	drift = maxf(0,drift-dt)
	flow_grace = maxf(0,flow_grace-dt)
	if flow_grace <= 0: flow = 0
	clock += dt
	if aiming: preview = acquire(run,aim_direction)
	if state in ["flying","pulling"]:
		if target.kind == "enemy":
			if not target.enemy.alive:
				release(run)
			else:
				target.p = target.enemy.p
		var obstruction = Geometry.first_wall(run.player,target.p) if state != "idle" else {}
		if state != "idle" and obstruction.hit and obstruction.t < .995:
			# A moving anchor crossed behind masonry. Never pull through the wall.
			release(run)
	if state == "flying":
		var old_tip = tip
		flight += SHOT_SPEED*dt
		var offset = Geometry.ground(target.p-run.player)
		tip = run.player+Geometry.project(offset.normalized()*minf(offset.length(),flight))
		var wall = Geometry.first_wall(old_tip,tip)
		var closest = wall.t if wall.hit else 1.01
		var intercepted = null
		for enemy in run.enemies:
			if not can_anchor(enemy): continue
			var t = Geometry.segment_circle(old_tip,tip,enemy.p,8.0 if enemy.kind == 0 else 10.0)
			if t >= 0 and t <= closest:
				closest = t
				intercepted = enemy
		if intercepted != null:
			target = {"kind":"enemy","p":intercepted.p,"enemy":intercepted,"wall":-1}
			_attach(run,offset.normalized())
		elif wall.hit:
			target = {"kind":"wall","p":wall.p,"enemy":null,"wall":wall.wall}
			_attach(run,offset.normalized())
		elif flight >= offset.length():
			if target.kind == "miss": release(run)
			else: _attach(run,offset.normalized())
	if state == "pulling":
		tip = target.p
		var diff = Geometry.ground(target.p-run.player)
		var stop = 27.0 if target.kind == "enemy" else 10.0
		if diff.length() <= stop+3 or clock > 2.2:
			if target.kind == "enemy":
				run.facing = diff.normalized()
				run.sword_attack(1.35)
				run.sword_clock = run.stats().sword_interval
				run.invulnerable = maxf(run.invulnerable,.16)
			run.velocity *= .65
			release(run)
		else:
			var maximum = SPEED*(1+.07*run.count("stride"))
			var speed = minf(maximum,maxf(110,sqrt(2*1600*maxf(0,diff.length()-stop))))
			var velocity = Geometry.ground(run.velocity).move_toward(diff.normalized()*speed,2700*dt)
			run.velocity = Geometry.project(velocity)
			run.facing = diff.normalized()
	if state != "pulling":
		var desired = movement.limit_length()*run.stats().speed
		var slowing = 150.0 if state == "flying" else (520.0 if drift > 0 else 640.0)
		run.velocity = Geometry.project(Geometry.ground(run.velocity).move_toward(desired,slowing*dt))
	trail_clock -= dt
	if Geometry.ground(run.velocity).length() > 145 and trail_clock <= 0:
		trail_clock = .025
		trail.append({"p":run.player,"life":.20,"direction":run.facing})
		if trail.size() > 9: trail.pop_front()
	for point in trail: point.life -= dt
	trail = trail.filter(func(point): return point.life > 0)

func _attach(run, direction):
	state = "pulling"
	clock = 0
	tip = target.p
	catches += 1
	flow = mini(6,flow+1) if flow_grace > 0 else 1
	flow_grace = 1.35
	best_flow = maxi(best_flow,flow)
	if target.kind == "enemy": enemy_catches += 1
	else: wall_catches += 1
	run._sound("chain_lock")
	run._spark(target.p-Vector2(0,10),[Color("eef0d9"),Color("83cdd9")],7,direction,.7)
