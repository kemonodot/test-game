extends SceneTree
## Screenshots only. No movie writer, video encoding or recording.
const Scene = preload("res://main.tscn")

func _initialize():
	root.size = Vector2i(1280,720)
	call_deferred("inspect")

func inspect():
	var game = Scene.instantiate()
	root.add_child(game)
	await process_frame
	await process_frame
	game.set_process(false)
	await game._save_shot("11-swipe-intro")
	game.start_run()
	game.run.level_up()
	game.hud.show_choices()
	game.hud.update_hud()
	await game._save_shot("12-new-arts-choice")
	game.start_run()
	# A controlled rendering check with all four unlocks; not a default loadout.
	game.run.time = 35.0
	game.run.level = 5
	for id in game.run.Arts.IDS: game.run.upgrades[id] = 1
	game.run.spawn_clock = 999
	game.run.sword_clock = 999
	game.run.fire_clock = 999
	var positions = [Vector2(350,216),Vector2(382,213),Vector2(401,208),Vector2(440,202),Vector2(497,205),Vector2(326,263),Vector2(296,261),Vector2(285,210),Vector2(280,236),Vector2(359,272),Vector2(440,271),Vector2(479,274),Vector2(500,170),Vector2(377,136),Vector2(337,131),Vector2(289,130)]
	for i in range(positions.size()):
		var foe = game.run.spawn_enemy(1 if i in [4,8,10,14] else 0,positions[i])
		foe.speed *= .6
	game._begin_stick(Vector2(180,550),0)
	game._move_stick(Vector2(222,550))
	game._finish_aim()
	for i in range(25):
		game._process(1.0/60)
		await process_frame
	game.hud.update_hud()
	await game._save_shot("13-swipe-and-arts")
	assert(game.run.skills.active_count(game.run) == 4)
	assert(game.run.skills.casts.cinder_trail > 0 and game.run.skills.casts.chain_lightning > 0 and game.run.skills.casts.petal_wave > 0)
	print("PASS all four arts render during an actual native Godot chain dash")
	print("VISUAL COUNTS ",game.run.skills.casts," enemies=",game.run.enemies.size()," particles=",game.run.particles.size())
	game._quit_cleanly()
