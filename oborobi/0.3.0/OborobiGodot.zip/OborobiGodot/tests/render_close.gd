extends SceneTree
const Scene = preload("res://main.tscn")

func _initialize():
	call_deferred("test_close")

func test_close():
	var game = Scene.instantiate()
	root.add_child(game)
	await process_frame
	game.start_run()
	game.run._sound("level")
	await create_timer(.3).timeout
	print("PASS actual window close signal stops active audio and exits")
	root.close_requested.emit()
