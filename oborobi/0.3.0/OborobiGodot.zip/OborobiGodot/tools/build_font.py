"""Optional art-tool dependency: fontTools. Gameplay has no Python dependency."""
from pathlib import Path
from fontTools import subset
from fontTools.ttLib import TTFont
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--source', default='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
parser.add_argument('--license', default='/usr/share/doc/fonts-noto-cjk/copyright')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
text = ''.join(p.read_text() for p in root.rglob('*.gd'))
text += ''.join(chr(i) for i in range(32, 127))
text += ''.join(chr(i) for i in range(0x3040, 0x3100))
font = TTFont(args.source, fontNumber=0)
options = subset.Options()
options.layout_features = ['*']
subsetter = subset.Subsetter(options=options)
subsetter.populate(text=text)
subsetter.subset(font)
for record in font['name'].names:
    if record.nameID in [1, 3, 4, 6]:
        value = 'OborobiUI-Regular' if record.nameID in [3, 6] else 'Oborobi UI'
        record.string = value.encode(record.getEncoding(), errors='replace')
font.save(root / 'assets/fonts/OborobiUI.otf')
(root / 'assets/fonts/LICENSE.txt').write_text(Path(args.license).read_text())
print('UI font regenerated with all in-game Japanese characters.')
