"""Draw the original pixel launcher icon; Pillow is only a development tool."""
from pathlib import Path
from PIL import Image, ImageDraw

art = Path(__file__).resolve().parents[1] / 'assets' / 'art'
foreground = Image.new('RGBA', (48, 48))
d = ImageDraw.Draw(foreground)
# Small ronin, warm straw hat, a sharp blade and cold blue soul fire.
d.polygon([(18, 27), (29, 27), (32, 37), (25, 35), (21, 39), (15, 37)], fill='#121a26')
d.polygon([(18, 28), (24, 30), (29, 28), (29, 32), (22, 33), (17, 31)], fill='#54899e')
d.rectangle((20, 21, 27, 27), fill='#b9ab88')
d.rectangle((22, 24, 29, 27), fill='#273442')
d.polygon([(12, 22), (24, 12), (35, 22)], fill='#978158')
d.polygon([(15, 21), (24, 15), (32, 21)], fill='#c4b17c')
d.rectangle((11, 22, 35, 23), fill='#6d6047')
d.rectangle((17, 19, 29, 20), fill='#dfc99b')
d.line([(28, 33), (39, 27)], fill='#d1e0de', width=1)
d.line([(27, 34), (31, 32)], fill='#7895a5', width=2)
d.polygon([(37, 15), (40, 10), (40, 14), (43, 17), (41, 22), (37, 21), (35, 18)], fill='#386888')
d.polygon([(39, 14), (41, 17), (40, 20), (37, 19)], fill='#77c5de')
d.rectangle((38, 17, 39, 18), fill='#dbf0e7')
d.rectangle((32, 25, 33, 26), fill='#71b6ce')
background = Image.new('RGBA', (48, 48), '#111b29')
bd = ImageDraw.Draw(background)
bd.rectangle((3, 3, 44, 44), outline='#6d614d')
bd.rectangle((5, 5, 42, 42), outline='#273342')
icon = Image.alpha_composite(background, foreground)
icon.resize((192, 192), Image.Resampling.NEAREST).save(art / 'launcher.png')
foreground.resize((432, 432), Image.Resampling.NEAREST).save(art / 'launcher-foreground.png')
Image.new('RGB', (432, 432), '#111b29').save(art / 'launcher-background.png')
print('Original pixel launcher icons generated')
