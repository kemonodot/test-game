"""Generate two original short chain cues. Only needed to recreate assets."""
from pathlib import Path
import math
import random
import struct
import wave

ROOT = Path(__file__).resolve().parents[1] / "assets/audio"
RATE = 22050

def write(name, duration, lock):
    rng = random.Random(924 if lock else 331)
    samples = []
    previous = 0.0
    for i in range(int(duration * RATE)):
        t = i / RATE
        noise = rng.uniform(-1, 1)
        high = noise - previous * .65
        previous = noise
        if lock:
            envelope = math.exp(-t * 30)
            value = (.24 * high + .20 * math.sin(t * 2 * math.pi * 1830)
                     + .12 * math.sin(t * 2 * math.pi * 2713)) * envelope
        else:
            pulse = sum(math.exp(-max(0, t - click) * 85) if t >= click else 0
                        for click in (0, .032, .063, .104))
            value = (.15 * high + .08 * math.sin(t * 2 * math.pi * 1447)) * pulse
            value += .06 * high * math.exp(-t * 9)
        value *= min(1, t / .0015) * min(1, (duration-t) / .012)
        samples.append(struct.pack('<h', round(max(-.8, min(.8, value)) * 32767)))
    with wave.open(str(ROOT / name), 'wb') as out:
        out.setnchannels(1)
        out.setsampwidth(2)
        out.setframerate(RATE)
        out.writeframes(b''.join(samples))

write('chain_throw.wav', .24, False)
write('chain_lock.wav', .16, True)
print('Generated original chain launch and impact audio.')
