"""Original, deterministic pixel art and sound for Oborobi; no reference-image copying.
Runtime needs neither Python nor Pillow. Regenerate: python3 tools/build_assets.py.
"""
from pathlib import Path
import math
import random
import wave
import struct
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / 'assets/art'
AUDIO = ROOT / 'assets/audio'
ART.mkdir(parents=True, exist_ok=True)
AUDIO.mkdir(parents=True, exist_ok=True)
rng = random.Random(7319)

# Shared palette: ink, slate, old lacquer, copper, pale straw and cold soul fire.
INK = '#10131e'
SLATE = ['#252630', '#2c2d36', '#32323a', '#38363d', '#3e3940', '#292c35']
PINK = ['#382132', '#532738', '#743347', '#a44d60', '#c27779']
image = Image.new('RGB', (640, 360), '#101720')
d = ImageDraw.Draw(image)

# Broken isometric paving: crisp one-pixel joints, restrained contrast in the arena.
for row in range(-25, 27):
    for col in range(-24, 25):
        x, y = 320 + (col - row) * 24, 190 + (col + row) * 12
        if -48 < x < 688 and 10 < y < 410:
            tile = [(x, y - 12), (x + 23, y), (x, y + 11), (x - 23, y)]
            color = rng.choice(SLATE)
            d.polygon(tile, fill=color)
            d.line([tile[3], tile[0], tile[1]], fill='#46414a', width=1)
            d.line([tile[1], tile[2], tile[3]], fill='#1c2029', width=1)
            for _ in range(rng.randrange(3, 8)):
                px, py = x + rng.randrange(-14, 15), y + rng.randrange(-4, 5)
                d.rectangle((px, py, px + rng.randrange(0, 3), py), fill=rng.choice(['#3e3940', '#242731', '#414047']))
            if rng.random() < .12:
                d.line([(x - 8, y + 1), (x - 3, y + 1), (x - 1, y + 4)], fill='#1e252b')
            if rng.random() < .10:
                d.rectangle((x + 7, y + 4, x + 10, y + 5), fill='#38403b')

def rock(x, y, size=16):
    d.polygon([(x-size, y), (x-size+4, y-size//2), (x+size//2, y-size//2-3), (x+size, y-1), (x+size-4, y+7), (x-9, y+8)], fill='#181f28')
    d.polygon([(x-size+4, y-size//2), (x+size//2, y-size//2-3), (x+size, y-1), (x, y+1), (x-size, y)], fill='#30303a')
    d.line([(x-size+4, y-size//2), (x+size//2, y-size//2-3)], fill='#48404a')
    d.line([(x, y+1), (x+1, y+6)], fill='#111923')

# Dark tree line and rubble occupy only the edges.
for _ in range(230):
    x, y = rng.randrange(640), rng.choice([rng.randrange(10, 62), rng.randrange(338, 360)])
    rock(x, y, rng.randrange(5, 16))
for _ in range(100):
    x, y = rng.choice([rng.randrange(0, 37), rng.randrange(608, 640)]), rng.randrange(70, 340)
    rock(x, y, rng.randrange(7, 17))

def wall(x, y, length):
    for i in range(length):
        bx, by = x + i * 18, y - i * 9
        d.polygon([(bx, by), (bx+18, by-9), (bx+18, by+6), (bx, by+15)], fill='#232632')
        d.polygon([(bx, by), (bx+18, by-9), (bx+11, by-14), (bx-7, by-5)], fill='#47404a')
        d.line([(bx, by+7), (bx+18, by-2)], fill='#121924')
        d.line([(bx-7, by-5), (bx+11, by-14)], fill='#65545a')

wall(50, 123, 8)
wall(421, 342, 8)
wall(573, 219, 3)

def lantern(x, y):
    # A tiled, stepped spill rather than a smooth bloom.
    for radius, color in [(28, '#383039'), (19, '#4c3738'), (11, '#69413b')]:
        d.polygon([(x-radius*2, y), (x, y-radius), (x+radius*2, y), (x, y+radius)], fill=color)
    for _ in range(26):
        px, py = x+rng.randrange(-28, 28), y+rng.randrange(-8, 15)
        d.rectangle((px, py, px+2, py), fill=rng.choice(['#7a4f3c', '#a66b42', '#4b3738']))
    for off, width, height in [(0, 14, 8), (-7, 11, 6), (-12, 8, 14)]:
        d.rectangle((x-width, y+off-height, x+width, y+off), fill='#262532')
        d.line((x-width, y+off-height, x+width, y+off-height), fill='#635052')
        d.line((x, y+off-height+1, x, y+off), fill='#171f2b')
    d.rectangle((x-10, y-48, x+10, y-26), fill='#3b262c')
    d.rectangle((x-7, y-45, x+7, y-30), fill='#c36838')
    d.rectangle((x-5, y-43, x+5, y-32), fill='#efaf61')
    d.rectangle((x-2, y-42, x+2, y-32), fill='#ffe1a2')
    for bx in [-7, 0, 7]:
        d.line((x+bx, y-46, x+bx, y-29), fill='#573139', width=2)
    d.polygon([(x-17, y-48), (x-9, y-56), (x+9, y-56), (x+17, y-48)], fill='#24212d')
    d.line((x-17, y-48, x+17, y-48), fill='#956153', width=2)
    d.rectangle((x-2, y-61, x+2, y-57), fill='#72605d')

# Torii: aged lacquer, shaded uprights, long lintels and stone stairs.
for step in range(4):
    y = 107 + step * 6
    d.polygon([(416-step*5, y), (518+step*5, y-9), (535+step*5, y+1), (432-step*5, y+12)], fill=SLATE[step])
    d.line([(432-step*5, y+12), (535+step*5, y+1)], fill='#66606a')
    d.line([(433-step*5, y+13), (535+step*5, y+2)], fill='#181e29')
for x, y in [(426, 104), (510, 94)]:
    d.rectangle((x-9, y-9, x+9, y+2), fill='#272b35')
    d.line((x-9, y-9, x+9, y-9), fill='#5c525b')
    d.rectangle((x-6, y-76, x+6, y-9), fill='#542e3c')
    d.rectangle((x-6, y-76, x-2, y-9), fill='#8e494c')
    d.line((x+4, y-73, x+4, y-12), fill='#322435', width=2)
    for yy in range(y-70, y-10, 10):
        d.rectangle((x-3, yy, x-1, yy+3), fill='#b2665b')
d.polygon([(400, 27), (536, 14), (549, 20), (549, 29), (404, 43)], fill='#181c2b')
d.polygon([(397, 29), (537, 16), (545, 21), (403, 36)], fill='#824044')
d.line((401, 37, 549, 23), fill='#bf6659', width=2)
d.polygon([(413, 57), (529, 46), (531, 54), (415, 66)], fill='#7b3b44')
d.line((415, 66, 530, 54), fill='#42283a', width=2)
d.rectangle((465, 36, 478, 55), fill='#201f2c')
d.rectangle((468, 39, 475, 51), outline='#967259')
# Small shimenawa and folded paper.
d.line([(431, 70), (465, 75), (510, 62)], fill='#b09365')
for x, y in [(441, 72), (461, 76), (484, 70), (499, 66)]:
    d.line([(x, y), (x-2, y+3), (x+1, y+5), (x-1, y+8)], fill='#cabfa0', width=2)
lantern(393, 121)
lantern(547, 194)
lantern(83, 217)
lantern(565, 327)

def cherry(x, y, reach):
    d.line([(x, y), (x-7, y-40), (x+3, y-80)], fill='#151522', width=11)
    d.line([(x-1, y), (x-5, y-42), (x+7, y-82)], fill='#45303b', width=3)
    for _ in range(16):
        ex, ey = x+rng.randrange(-reach, reach), y-rng.randrange(45, 110)
        d.line([(x-5, y-40), (ex, ey)], fill='#281e2d', width=rng.randrange(2, 5))
        for _ in range(18):
            px, py = ex+rng.randrange(-15, 16), ey+rng.randrange(-8, 10)
            color = rng.choice(PINK)
            d.rectangle((px-1, py-2, px, py+2), fill=color)
            d.rectangle((px-3, py-1, px+2, py), fill=color)
            if rng.random() < .28:
                d.point((px, py), fill='#c18a89')
cherry(35, 148, 70)
cherry(132, 79, 64)
cherry(606, 115, 61)
cherry(14, 368, 65)
cherry(617, 398, 57)
# Sparse fallen petals, concentrated near edges and lamps.
for _ in range(175):
    x, y = rng.randrange(45, 599), rng.randrange(81, 341)
    if 150 < x < 500 and 140 < y < 290 and rng.random() < .84:
        continue
    d.rectangle((x, y, x+1, y), fill=rng.choice(PINK[1:4]))
image.save(ART / 'arena.png')

def sprite(kind, direction, frame, flash=False):
    im = Image.new('RGBA', (32, 32))
    p = ImageDraw.Draw(im)
    bob = [0, -1, 0, -1][frame]
    stride = [0, 2, 0, -2][frame]
    if kind == 0:  # The protagonist: kasa, dark robe, blue sash and thin katana.
        p.polygon([(10,17+bob),(19,16+bob),(24,23+bob),(19,26),(17,22),(10,26),(7,22)], fill='#0d1423')
        p.polygon([(10,18+bob),(15,17+bob),(15,24),(9,26),(8,23)], fill='#24445a')
        p.polygon([(17,17+bob),(20,19+bob),(22,24+bob),(18,23)], fill='#375f72')
        p.rectangle((11-stride//2,24,13-stride//2,28), fill='#172431')
        p.rectangle((18+stride//2,24,20+stride//2,28), fill='#182230')
        p.rectangle((9-stride//2,28,13-stride//2,29), fill='#080f1b')
        p.rectangle((17+stride//2,28,21+stride//2,29), fill='#080f1b')
        p.rectangle((12,13+bob,18,18+bob), fill='#152434')
        p.rectangle((13,11+bob,17,15+bob), fill='#b4a184')
        p.rectangle((12,13+bob,18,14+bob), fill='#1b2230')
        p.line((11,20+bob,20,19+bob), fill='#74adbd', width=2)
        p.polygon([(12,20+bob),(10,23+bob),(6,24+bob),(3,23+bob),(7,21+bob)], fill='#327a95')
        p.line((4,23+bob,8,22+bob), fill='#7cc8d9')
        p.line((20,19+bob,29,12+bob), fill='#121d2e', width=3)
        p.line((20,18+bob,28,12+bob), fill='#c5d5d6')
        p.point((28,11+bob), fill='#f1e9ce')
        p.line((19,19+bob,21,21+bob), fill='#d7ae6d')
        p.polygon([(6,10+bob),(14,4+bob),(18,4+bob),(25,10+bob),(23,12+bob),(8,12+bob)], fill='#39313c')
        p.polygon([(7,9+bob),(15,3+bob),(23,9+bob),(20,11+bob),(10,11+bob)], fill='#a18457')
        p.line((7,10+bob,24,10+bob), fill='#dac08a')
        p.line((15,4+bob,12,9+bob), fill='#d4b581')
        p.line((16,4+bob,20,9+bob), fill='#6c5a49')
        p.rectangle((13,5+bob,17,5+bob), fill='#cab081')
        if direction == 2:
            p.rectangle((12,12+bob,19,18+bob), fill='#142235')
            p.line((15,13+bob,15,18+bob), fill='#38657a')
        elif direction == 1:
            p.rectangle((17,13+bob,19,15+bob), fill='#bcaa8b')
    elif kind == 1:  # Rust-clad cursed ashigaru.
        p.line((11-stride//2,23,8-stride//2,29), fill='#1a1c27', width=3)
        p.line((18+stride//2,23,21+stride//2,28), fill='#22222c', width=3)
        p.rectangle((6-stride//2,28,10-stride//2,29), fill='#0b1220')
        p.rectangle((19+stride//2,28,23+stride//2,29), fill='#0b1220')
        p.polygon([(10,13+bob),(19,12+bob),(22,20+bob),(18,24),(15,22),(9,24),(6,20+bob)], fill='#352a36')
        p.polygon([(10,14+bob),(14,14+bob),(13,20+bob),(8,22)], fill='#724548')
        p.line((17,15+bob,20,21+bob), fill='#a06458', width=2)
        p.rectangle((12,9+bob,18,15+bob), fill='#976a58')
        p.rectangle((12,11+bob,18,13+bob), fill='#482b38')
        p.point((13,11+bob), fill='#eeb58a')
        p.point((17,11+bob), fill='#eeb58a')
        p.polygon([(5,9+bob),(14,3+bob),(22,7+bob),(24,10+bob),(11,12+bob)], fill='#80624c')
        p.line((6,9+bob,22,9+bob), fill='#b79965')
        p.line((14,4+bob,11,9+bob), fill='#cab180')
        p.line((14,4+bob,19,8+bob), fill='#4b4040')
        p.line((21,18+bob,28,13+bob), fill='#6c7380', width=2)
        p.point((28,12+bob), fill='#bdc3ba')
        p.rectangle((9,19+bob,15,20+bob), fill='#b29771')
    else:  # Larger horned guardian with heavy purple-grey robes.
        p.rectangle((7-stride//2,25,12-stride//2,29), fill='#101724')
        p.rectangle((19+stride//2,25,24+stride//2,29), fill='#101724')
        p.polygon([(9,11+bob),(23,11+bob),(27,23+bob),(21,27),(15,25),(8,27),(5,22+bob)], fill='#262838')
        p.polygon([(9,13+bob),(14,14+bob),(12,24),(8,24),(7,20)], fill='#57506a')
        p.polygon([(18,14+bob),(22,13+bob),(25,23),(20,24)], fill='#46435d')
        p.line((10,16+bob,21,16+bob), fill='#89787b', width=2)
        p.rectangle((11,6+bob,21,13+bob), fill='#a4a5a1')
        p.rectangle((13,9+bob,19,12+bob), fill='#3d3d52')
        p.rectangle((12,8+bob,14,9+bob), fill='#e5af77')
        p.rectangle((18,8+bob,20,9+bob), fill='#e5af77')
        p.polygon([(10,7+bob),(8,2+bob),(12,4+bob),(13,7+bob)], fill='#c4b89c')
        p.polygon([(19,7+bob),(23,2+bob),(23,6+bob),(21,8+bob)], fill='#c4b89c')
        p.rectangle((15,11+bob,17,13+bob), fill='#ccbfac')
        p.line((23,18+bob,28,28), fill='#79624f', width=3)
        p.rectangle((25,23,30,27), fill='#433e4e')
        p.line((25,23,30,23), fill='#8d7a74')
        p.line((11,20+bob,21,20+bob), fill='#b5956e')
    if direction == 3:
        im = im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    if flash:
        pixels = im.load()
        for y in range(32):
            for x in range(32):
                if pixels[x, y][3]: pixels[x, y] = (239, 231, 210, 255)
    return im

for kind, name in enumerate(['ronin', 'ashigaru', 'guardian']):
    for flash in [False, True]:
        atlas = Image.new('RGBA', (128, 128))
        for direction in range(4):
            for frame in range(4):
                atlas.paste(sprite(kind, direction, frame, flash), (frame*32, direction*32))
        atlas.save(ART / (name + ('_flash' if flash else '') + '.png'))

flames = Image.new('RGBA', (64, 16))
for frame in range(4):
    p = ImageDraw.Draw(flames)
    x = frame * 16
    flicker = [0, 1, -1, 0][frame]
    p.polygon([(x+7,1),(x+9+flicker,4),(x+8,6),(x+12,9),(x+11,13),(x+8,15),(x+4,13),(x+3,10),(x+5,7)], fill='#245174')
    p.polygon([(x+7,4),(x+9,7),(x+10,10),(x+9,13),(x+6,13),(x+5,10)], fill='#358cb4')
    p.rectangle((x+6,9,x+8,12), fill='#8eddea')
    p.rectangle((x+7,10,x+7,11), fill='#e1f4e9')
flames.save(ART / 'soul_fire.png')

def wav(name, seconds, sample):
    rate = 22050
    data = bytearray()
    for i in range(int(rate*seconds)):
        value = max(-1.0, min(1.0, sample(i/rate)))
        data.extend(struct.pack('<h', int(value*28000)))
    with wave.open(str(AUDIO / (name + '.wav')), 'wb') as out:
        out.setnchannels(1); out.setsampwidth(2); out.setframerate(rate); out.writeframes(data)

audio_rng = random.Random(499)
wav('slash', .16, lambda t: (audio_rng.uniform(-1,1)*.4 + math.sin(t*(1250-3000*t))*.1)*math.exp(-25*t))
wav('shatter', .20, lambda t: (audio_rng.uniform(-1,1)*.24 + math.sin(t*3300)*.14)*math.exp(-27*t))
wav('fire', .22, lambda t: (math.sin(2*math.pi*(660*t-240*t*t))*.20 + audio_rng.uniform(-1,1)*.06)*math.exp(-18*t))
wav('pickup', .12, lambda t: math.sin(2*math.pi*1400*t)*.11*math.exp(-38*t))
wav('level', .85, lambda t: sum(math.sin(2*math.pi*f*t)*.12*math.exp(-7*max(0,t-off)) if t>=off else 0 for f,off in [(440,0),(660,.08),(880,.16),(1100,.24)]))
wav('hurt', .26, lambda t: (math.sin(2*math.pi*(170*t-140*t*t))*.34+audio_rng.uniform(-1,1)*.09)*math.exp(-18*t))
wav('death', 1.2, lambda t: (math.sin(2*math.pi*(180*t-36*t*t))*.23+audio_rng.uniform(-1,1)*.08)*math.exp(-3.7*t))
wav('ambient', 16, lambda t: (sum(math.sin(2*math.pi*f*t)*.021 for f in [55,82.5,110])+math.sin(2*math.pi*330*t)*.018*math.exp(-2.1*(t%4))) * (.65+.25*math.sin(math.pi*t/8)**2))
print('Original art and sound generated:', len(list(ART.glob('*.png'))), 'textures,', len(list(AUDIO.glob('*.wav'))), 'sounds.')
